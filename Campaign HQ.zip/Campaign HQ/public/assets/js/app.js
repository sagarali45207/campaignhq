/**
 * CampaignHQ Main Application JavaScript
 */

const CampaignHQ = {
    baseUrl: document.body.dataset.baseUrl || '/campaignhq',
    csrfToken: document.querySelector('meta[name="csrf-token"]')?.content || '',
    user: null,
    
    /**
     * Initialize application
     */
    init() {
        this.setupAjax();
        this.setupEventListeners();
        this.loadNotifications();
        console.log('CampaignHQ initialized');
    },
    
    /**
     * Setup AJAX defaults
     */
    setupAjax() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-Token': this.csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            error: (xhr, status, error) => {
                this.handleAjaxError(xhr, status, error);
            }
        });
    },
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Sidebar toggle
        $('#sidebarToggle').on('click', () => {
            $('#sidebar').toggleClass('collapsed');
        });
        
        // Form submit handlers
        $(document).on('submit', 'form[data-ajax="true"]', (e) => {
            e.preventDefault();
            this.submitForm($(e.target));
        });
        
        // Auto-dismiss alerts
        $('[data-dismiss="alert"]').on('click', function() {
            $(this).closest('.alert').fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        // Confirm delete
        $(document).on('click', '[data-confirm]', (e) => {
            if (!confirm($(e.target).data('confirm'))) {
                e.preventDefault();
            }
        });
    },
    
    /**
     * Load notifications
     */
    loadNotifications() {
        $.ajax({
            url: this.baseUrl + '/api/notifications',
            method: 'GET',
            dataType: 'json',
            success: (response) => {
                if (response.success && response.data) {
                    this.renderNotifications(response.data);
                }
            }
        });
    },
    
    /**
     * Render notifications
     */
    renderNotifications(notifications) {
        const unreadCount = notifications.filter(n => !n.is_read).length;
        const menu = $('#notificationMenu');
        
        $('#notificationCount').text(unreadCount).toggle(unreadCount > 0);
        
        menu.empty();
        
        if (notifications.length === 0) {
            menu.append('<div class="dropdown-item text-muted">No notifications</div>');
            return;
        }
        
        notifications.slice(0, 5).forEach(notification => {
            const item = $(`
                <a href="${notification.action_url || '#'}" class="dropdown-item ${!notification.is_read ? 'unread' : ''}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="fw-bold">${this.escape(notification.title)}</div>
                            <small class="text-muted">${this.escape(notification.message)}</small>
                        </div>
                        ${!notification.is_read ? '<span class="badge bg-primary">New</span>' : ''}
                    </div>
                    <small class="text-muted">${this.timeAgo(notification.created_at)}</small>
                </a>
            `);
            menu.append(item);
        });
        
        if (notifications.length > 5) {
            menu.append(`
                <hr class="my-2">
                <a href="${this.baseUrl}/notifications" class="dropdown-item text-center small">View all notifications</a>
            `);
        }
    },
    
    /**
     * Submit form via AJAX
     */
    submitForm($form) {
        const url = $form.attr('action');
        const method = $form.attr('method') || 'POST';
        const data = new FormData($form[0]);
        
        $.ajax({
            url: url,
            method: method,
            data: data,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: (response) => {
                if ($form.data('callback')) {
                    window[$form.data('callback')](response);
                } else {
                    this.showSuccess(response.message);
                    if (response.data && response.data.redirect) {
                        setTimeout(() => {
                            window.location.href = response.data.redirect;
                        }, 1500);
                    }
                }
            }
        });
    },
    
    /**
     * Show success message
     */
    showSuccess(message) {
        this.showAlert(message, 'success');
    },
    
    /**
     * Show error message
     */
    showError(message) {
        this.showAlert(message, 'danger');
    },
    
    /**
     * Show alert
     */
    showAlert(message, type = 'info') {
        const icons = {
            success: 'fa-check-circle',
            danger: 'fa-exclamation-circle',
            warning: 'fa-warning',
            info: 'fa-info-circle'
        };
        
        const alert = $(`
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="fas ${icons[type]}"></i> ${this.escape(message)}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);
        
        $('main').prepend(alert);
        
        setTimeout(() => {
            alert.fadeOut(300, function() {
                $(this).remove();
            });
        }, 4000);
    },
    
    /**
     * Handle AJAX errors
     */
    handleAjaxError(xhr, status, error) {
        let message = 'An error occurred';
        
        if (xhr.status === 401) {
            message = 'Unauthorized. Please login again.';
            setTimeout(() => {
                window.location.href = this.baseUrl + '/login';
            }, 1500);
        } else if (xhr.status === 403) {
            message = 'Permission denied';
        } else if (xhr.status === 404) {
            message = 'Resource not found';
        } else if (xhr.status === 422) {
            message = 'Validation failed';
        } else if (xhr.status === 500) {
            message = 'Server error';
        } else if (xhr.responseJSON && xhr.responseJSON.message) {
            message = xhr.responseJSON.message;
        }
        
        console.error('AJAX Error:', { status: xhr.status, error, message });
        this.showError(message);
    },
    
    /**
     * Escape HTML
     */
    escape(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    },
    
    /**
     * Format time ago
     */
    timeAgo(datetime) {
        const now = new Date();
        const date = new Date(datetime);
        const seconds = Math.floor((now - date) / 1000);
        
        let interval = Math.floor(seconds / 31536000);
        if (interval > 1) return interval + ' years ago';
        
        interval = Math.floor(seconds / 2592000);
        if (interval > 1) return interval + ' months ago';
        
        interval = Math.floor(seconds / 86400);
        if (interval > 1) return interval + ' days ago';
        
        interval = Math.floor(seconds / 3600);
        if (interval > 1) return interval + ' hours ago';
        
        interval = Math.floor(seconds / 60);
        if (interval > 1) return interval + ' minutes ago';
        
        return Math.floor(seconds) + ' seconds ago';
    },
    
    /**
     * Format currency
     */
    formatCurrency(value, currency = '$', decimals = 2) {
        return currency + parseFloat(value).toFixed(decimals);
    },
    
    /**
     * Format percentage
     */
    formatPercent(value, decimals = 2) {
        return parseFloat(value).toFixed(decimals) + '%';
    },
    
    /**
     * Initialize DataTable
     */
    initDataTable(selector, options = {}) {
        const defaults = {
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            order: [[0, 'desc']],
            processing: true,
            serverSide: false,
            language: {
                search: 'Filter:',
                lengthMenu: 'Show _MENU_ entries',
                info: 'Showing _START_ to _END_ of _TOTAL_ entries',
                paginate: {
                    first: '« First',
                    last: 'Last »',
                    next: 'Next ›',
                    previous: '‹ Previous'
                }
            }
        };
        
        return $(selector).DataTable({...defaults, ...options});
    },
    
    /**
     * Show loading spinner
     */
    showLoading() {
        const spinner = $(`
            <div class="d-flex justify-content-center align-items-center" style="min-height: 300px;">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `);
        return spinner;
    },
    
    /**
     * Format date
     */
    formatDate(date, format = 'MM/DD/YYYY') {
        if (!date) return '';
        const d = new Date(date);
        const day = String(d.getDate()).padStart(2, '0');
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        
        return format
            .replace('DD', day)
            .replace('MM', month)
            .replace('YYYY', year);
    },
    
    /**
     * Make GET request
     */
    get(url) {
        return $.ajax({
            url: url,
            method: 'GET',
            dataType: 'json'
        });
    },
    
    /**
     * Make POST request
     */
    post(url, data = {}) {
        return $.ajax({
            url: url,
            method: 'POST',
            data: data,
            dataType: 'json'
        });
    },
    
    /**
     * Make PUT request
     */
    put(url, data = {}) {
        return $.ajax({
            url: url,
            method: 'PUT',
            data: JSON.stringify(data),
            contentType: 'application/json',
            dataType: 'json'
        });
    },
    
    /**
     * Make DELETE request
     */
    delete(url) {
        return $.ajax({
            url: url,
            method: 'DELETE',
            dataType: 'json'
        });
    }
};

// Initialize on document ready
$(document).ready(() => {
    CampaignHQ.init();
});
