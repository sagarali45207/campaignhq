<?php
/**
 * Security Helper Class
 * Handles authentication, CSRF, XSS protection, etc.
 */

class Security {
    /**
     * Hash password using bcrypt
     */
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_HASH_ALGORITHM, PASSWORD_HASH_OPTIONS);
    }
    
    /**
     * Verify password
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * Generate random token
     */
    public static function generateToken($length = CSRF_TOKEN_LENGTH) {
        return bin2hex(random_bytes($length / 2));
    }
    
    /**
     * Generate CSRF token
     */
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = self::generateToken();
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * Verify CSRF token
     */
    public static function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Sanitize input
     */
    public static function sanitize($data) {
        if (is_array($data)) {
            return array_map(function($item) {
                return self::sanitize($item);
            }, $data);
        }
        
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Escape HTML
     */
    public static function escape($data) {
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Escape JSON
     */
    public static function escapeJson($data) {
        return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    }
    
    /**
     * Generate random string
     */
    public static function randomString($length = 32) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $string = '';
        
        for ($i = 0; $i < $length; $i++) {
            $string .= $characters[random_int(0, strlen($characters) - 1)];
        }
        
        return $string;
    }
    
    /**
     * Check if email is valid
     */
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Validate URL
     */
    public static function isValidUrl($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
    
    /**
     * Validate IP
     */
    public static function isValidIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * Hash string with SHA256
     */
    public static function hash($data) {
        return hash('sha256', $data);
    }
    
    /**
     * Generate UUID v4
     */
    public static function generateUUID() {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}

/**
 * Validator Class
 * Handles data validation
 */

class Validator {
    private $errors = [];
    private $data = [];
    
    public function __construct($data = []) {
        $this->data = $data;
    }
    
    /**
     * Validate data
     */
    public function validate($rules) {
        foreach ($rules as $field => $fieldRules) {
            $rules_array = explode('|', $fieldRules);
            $value = $this->data[$field] ?? null;
            
            foreach ($rules_array as $rule) {
                $this->validateRule($field, $value, $rule);
            }
        }
        
        return empty($this->errors);
    }
    
    /**
     * Validate single rule
     */
    private function validateRule($field, $value, $rule) {
        $rule_parts = explode(':', $rule);
        $rule_name = $rule_parts[0];
        $rule_params = $rule_parts[1] ?? null;
        
        switch ($rule_name) {
            case 'required':
                if (empty($value)) {
                    $this->addError($field, "$field is required");
                }
                break;
                
            case 'email':
                if (!empty($value) && !Security::isValidEmail($value)) {
                    $this->addError($field, "$field must be a valid email");
                }
                break;
                
            case 'min':
                if (!empty($value) && strlen($value) < $rule_params) {
                    $this->addError($field, "$field must be at least $rule_params characters");
                }
                break;
                
            case 'max':
                if (!empty($value) && strlen($value) > $rule_params) {
                    $this->addError($field, "$field must not exceed $rule_params characters");
                }
                break;
                
            case 'numeric':
                if (!empty($value) && !is_numeric($value)) {
                    $this->addError($field, "$field must be numeric");
                }
                break;
                
            case 'unique':
                // TODO: Check against database
                break;
                
            case 'confirmed':
                $confirmed_field = $field . '_confirmation';
                if ($value !== ($this->data[$confirmed_field] ?? null)) {
                    $this->addError($field, "$field confirmation does not match");
                }
                break;
        }
    }
    
    /**
     * Add error
     */
    private function addError($field, $message) {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }
    
    /**
     * Get errors
     */
    public function errors() {
        return $this->errors;
    }
    
    /**
     * Get first error
     */
    public function firstError($field) {
        return $this->errors[$field][0] ?? null;
    }
    
    /**
     * Check if has errors
     */
    public function hasErrors() {
        return !empty($this->errors);
    }
}
