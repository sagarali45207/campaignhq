<?php
/**
 * Helper Functions
 */

/**
 * Escape output for HTML
 */
function e($data) {
    return Security::escape($data);
}

/**
 * Format date
 */
function formatDate($date, $format = DISPLAY_DATE_FORMAT) {
    if (empty($date)) {
        return '';
    }
    return date($format, strtotime($date));
}

/**
 * Format datetime
 */
function formatDateTime($datetime, $format = DISPLAY_DATETIME_FORMAT) {
    if (empty($datetime)) {
        return '';
    }
    return date($format, strtotime($datetime));
}

/**
 * Get time ago
 */
function timeAgo($datetime) {
    $time_ago = strtotime($datetime);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    $weeks = round($seconds / 604800);
    $months = round($seconds / 2419200);
    $years = round($seconds / 29030400);
    
    if ($seconds <= 60) {
        return 'just now';
    } elseif ($minutes <= 60) {
        return $minutes == 1 ? 'a minute ago' : $minutes . ' minutes ago';
    } elseif ($hours <= 24) {
        return $hours == 1 ? 'an hour ago' : $hours . ' hours ago';
    } elseif ($days <= 7) {
        return $days == 1 ? 'a day ago' : $days . ' days ago';
    } elseif ($weeks <= 4.3) {
        return $weeks == 1 ? 'a week ago' : $weeks . ' weeks ago';
    } elseif ($months <= 12) {
        return $months == 1 ? 'a month ago' : $months . ' months ago';
    } else {
        return $years == 1 ? 'a year ago' : $years . ' years ago';
    }
}

/**
 * Truncate text
 */
function truncate($text, $length = 100, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

/**
 * Convert bytes to human readable format
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
 * Format percentage
 */
function formatPercent($value, $precision = 2) {
    return number_format($value, $precision) . '%';
}

/**
 * Format currency
 */
function formatCurrency($value, $currency = '$', $precision = 2) {
    return $currency . number_format($value, $precision);
}

/**
 * Check if value is between
 */
function isBetween($value, $min, $max) {
    return $value >= $min && $value <= $max;
}

/**
 * Get array value safely
 */
function arrayGet($array, $key, $default = null) {
    return isset($array[$key]) ? $array[$key] : $default;
}

/**
 * Merge arrays recursively
 */
function array_merge_recursive_distinct(array $array1, array $array2) {
    $merged = $array1;
    
    foreach ($array2 as $key => &$value) {
        if (is_array($value) && isset($merged[$key]) && is_array($merged[$key])) {
            $merged[$key] = array_merge_recursive_distinct($merged[$key], $value);
        } else {
            $merged[$key] = $value;
        }
    }
    
    return $merged;
}

/**
 * Get gravatar URL
 */
function getGravatarUrl($email, $size = 128) {
    return 'https://www.gravatar.com/avatar/' . md5(strtolower($email)) . '?s=' . $size;
}

/**
 * Convert camelCase to snake_case
 */
function camelToSnake($camelCase) {
    $snakeCase = preg_replace_callback(
        '/[A-Z]/',
        function ($matches) {
            return '_' . strtolower($matches[0]);
        },
        $camelCase
    );
    return trim($snakeCase, '_');
}

/**
 * Convert snake_case to camelCase
 */
function snakeToCamel($snakeCase) {
    return lcfirst(implode('', array_map('ucfirst', explode('_', $snakeCase))));
}

/**
 * Get setting value
 */
function getSetting($key, $default = null) {
    static $cache = [];
    
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    
    try {
        $db = Database::getInstance();
        $db->query('SELECT setting_value FROM settings WHERE setting_key = :key');
        $db->bind(':key', $key);
        $result = $db->single();
        
        if ($result) {
            $cache[$key] = $result['setting_value'];
            return $result['setting_value'];
        }
    } catch (Exception $e) {
        Logger::error('Error getting setting: ' . $e->getMessage());
    }
    
    return $default;
}

/**
 * Set setting value
 */
function setSetting($key, $value) {
    try {
        $db = Database::getInstance();
        
        // Check if setting exists
        $db->query('SELECT id FROM settings WHERE setting_key = :key');
        $db->bind(':key', $key);
        $exists = $db->single();
        
        if ($exists) {
            // Update
            $db->query('UPDATE settings SET setting_value = :value, updated_at = NOW() WHERE setting_key = :key');
        } else {
            // Insert
            $db->query('INSERT INTO settings (setting_key, setting_value, created_at, updated_at) VALUES (:key, :value, NOW(), NOW())');
        }
        
        $db->bind(':key', $key);
        $db->bind(':value', $value);
        return $db->execute();
    } catch (Exception $e) {
        Logger::error('Error setting value: ' . $e->getMessage());
        return false;
    }
}

/**
 * Render view
 */
function view($path, $data = []) {
    $file = APP_ROOT . '/app/views/' . str_replace('.', '/', $path) . '.php';
    
    if (!file_exists($file)) {
        throw new Exception("View not found: $path");
    }
    
    extract($data);
    ob_start();
    include $file;
    return ob_get_clean();
}

/**
 * Check user has permission
 */
function canUser($permission) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    return isset($_SESSION['permissions']) && in_array($permission, $_SESSION['permissions']);
}

/**
 * Get authenticated user
 */
function auth() {
    return $_SESSION['user'] ?? null;
}

/**
 * Check if user is authenticated
 */
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}
