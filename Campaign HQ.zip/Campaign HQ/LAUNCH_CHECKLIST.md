# CampaignHQ - Pre-Launch Checklist

## 🎯 Pre-Launch Verification (Complete ALL before going live)

### ✅ Environment & Configuration

- [ ] **Copy .env file**
  ```bash
  cp .env.example .env
  ```
  
- [ ] **Update .env with production values**
  - [ ] APP_ENV=production
  - [ ] APP_DEBUG=false
  - [ ] DB_HOST (production database server)
  - [ ] DB_USER (production database user)
  - [ ] DB_PASS (strong password, 20+ characters)
  - [ ] DB_NAME (production database name)
  - [ ] BASE_URL (https://yourdomain.com/campaignhq)
  - [ ] SESSION_SECURE=true
  - [ ] SESSION_DOMAIN=yourdomain.com
  - [ ] SENDGRID_API_KEY (obtained from SendGrid)
  - [ ] SENDGRID_SENDER_EMAIL (verified in SendGrid)
  - [ ] TIMEZONE (correct timezone for business)

- [ ] **Secure .env file**
  ```bash
  chmod 600 .env
  chown www-data:www-data .env
  ```

- [ ] **Create directories**
  ```bash
  mkdir -p logs
  mkdir -p public/uploads/leads
  mkdir -p public/uploads/templates
  chmod 755 logs public/uploads
  ```

---

### ✅ Database Setup

- [ ] **Create production database**
  ```bash
  mysql -u root -p
  > CREATE DATABASE campaign_hq CHARACTER SET utf8mb4;
  > CREATE USER 'campaignhq_user'@'localhost' IDENTIFIED BY 'StrongPassword!';
  > GRANT ALL PRIVILEGES ON campaign_hq.* TO 'campaignhq_user'@'localhost';
  > FLUSH PRIVILEGES;
  ```

- [ ] **Import schema**
  ```bash
  mysql -u campaignhq_user -p campaign_hq < database.sql
  ```

- [ ] **Verify tables created**
  ```bash
  mysql -u campaignhq_user -p campaign_hq -e "SHOW TABLES;" | wc -l
  # Should show 28+ tables
  ```

- [ ] **Backup database**
  ```bash
  mysqldump -u campaignhq_user -p campaign_hq > /backups/campaign_hq_initial.sql
  ```

---

### ✅ Web Server Setup

#### For Apache:

- [ ] **Enable required modules**
  ```bash
  sudo a2enmod rewrite
  sudo a2enmod headers
  sudo a2enmod ssl
  ```

- [ ] **Create virtual host** (/etc/apache2/sites-available/campaignhq.conf)
  - [ ] Document root points to `/public` directory
  - [ ] Rewrite rules configured for clean URLs
  - [ ] SSL certificate configured
  - [ ] Error/access logs configured

- [ ] **Enable site**
  ```bash
  sudo a2ensite campaignhq.conf
  sudo systemctl reload apache2
  ```

- [ ] **Test configuration**
  ```bash
  apache2ctl configtest
  # Should return: Syntax OK
  ```

#### For Nginx:

- [ ] **Create server block** (/etc/nginx/sites-available/campaignhq)
  - [ ] Server name configured correctly
  - [ ] Root path set to `/public`
  - [ ] PHP-FPM upstream configured
  - [ ] SSL certificate paths set
  - [ ] Gzip compression enabled

- [ ] **Enable site**
  ```bash
  sudo ln -s /etc/nginx/sites-available/campaignhq /etc/nginx/sites-enabled/
  sudo systemctl reload nginx
  ```

- [ ] **Test configuration**
  ```bash
  sudo nginx -t
  # Should return: test successful
  ```

---

### ✅ SSL/HTTPS Setup

- [ ] **Install Let's Encrypt certificate**
  ```bash
  sudo certbot certonly --webroot -w /var/www/html/campaignhq/public -d yourdomain.com
  ```

- [ ] **Configure auto-renewal**
  ```bash
  sudo systemctl enable certbot.timer
  sudo systemctl start certbot.timer
  ```

- [ ] **Test SSL**
  ```bash
  openssl s_client -connect yourdomain.com:443
  # Should show certificate details
  ```

- [ ] **Update .env**
  - [ ] SESSION_SECURE=true
  - [ ] BASE_URL uses https://

---

### ✅ File Permissions

- [ ] **Set correct ownership**
  ```bash
  sudo chown -R www-data:www-data /var/www/html/campaignhq
  ```

- [ ] **Set directory permissions**
  ```bash
  sudo chmod 755 /var/www/html/campaignhq
  sudo chmod 755 /var/www/html/campaignhq/app
  sudo chmod 755 /var/www/html/campaignhq/config
  sudo chmod 755 /var/www/html/campaignhq/libraries
  sudo chmod 755 /var/www/html/campaignhq/helpers
  sudo chmod 755 /var/www/html/campaignhq/public
  ```

- [ ] **Set file permissions**
  ```bash
  sudo find /var/www/html/campaignhq -type f -exec chmod 644 {} \;
  ```

- [ ] **Allow write to logs and uploads**
  ```bash
  sudo chmod 777 /var/www/html/campaignhq/logs
  sudo chmod 777 /var/www/html/campaignhq/public/uploads
  ```

- [ ] **Protect .env**
  ```bash
  chmod 600 /var/www/html/campaignhq/.env
  ```

---

### ✅ PHP Configuration

- [ ] **Verify PHP version**
  ```bash
  php -v
  # Should be 8.3 or higher
  ```

- [ ] **Check required extensions**
  ```bash
  php -m | grep -E "pdo|mysql|curl|json|mbstring"
  ```

- [ ] **Update php.ini settings** (/etc/php/8.3/fpm/php.ini)
  - [ ] max_upload_size ≥ 50M
  - [ ] post_max_size ≥ 50M
  - [ ] memory_limit ≥ 256M
  - [ ] max_execution_time ≥ 60
  - [ ] error_log set to /var/log/php-fpm/error.log
  - [ ] display_errors = Off (production)
  - [ ] log_errors = On

- [ ] **Restart PHP-FPM**
  ```bash
  sudo systemctl restart php8.3-fpm
  ```

---

### ✅ Application Setup

- [ ] **Run installation script**
  ```bash
  php /var/www/html/campaignhq/install.php
  ```

- [ ] **Verify installation success**
  - [ ] Database connection successful
  - [ ] 28 tables created
  - [ ] Upload directories created
  - [ ] Admin user created

- [ ] **Change admin password**
  - [ ] Login to app
  - [ ] Go to Settings → Profile
  - [ ] Change password from Admin123!Change to secure password

---

### ✅ SendGrid Integration

- [ ] **Create SendGrid account**
  - [ ] Visit https://sendgrid.com
  - [ ] Sign up and verify email
  - [ ] Complete verification steps

- [ ] **Generate API Key**
  - [ ] Login to SendGrid
  - [ ] Settings → API Keys → Create API Key
  - [ ] Name: "CampaignHQ"
  - [ ] Access Level: Full Access
  - [ ] Copy the key (shown only once!)

- [ ] **Configure in CampaignHQ**
  ```env
  SENDGRID_API_KEY=SG.your_api_key_here
  SENDGRID_SENDER_EMAIL=noreply@yourdomain.com
  SENDGRID_SENDER_NAME=CampaignHQ
  ```

- [ ] **Verify sender email in SendGrid**
  - [ ] Settings → Sender Authentication
  - [ ] Add sender email
  - [ ] Complete verification (email or DNS)
  - [ ] DNS recommended for production

- [ ] **Test email sending**
  - [ ] Create test campaign
  - [ ] Add test lead
  - [ ] Send test email
  - [ ] Verify delivery in SendGrid Activity

- [ ] **Configure webhooks (optional but recommended)**
  - [ ] SendGrid → Settings → Webhook
  - [ ] Add endpoint: https://yourdomain.com/api/webhooks/sendgrid
  - [ ] Enable events: delivered, open, click, bounce, unsubscribe, spam_report

---

### ✅ Security Hardening

- [ ] **Update admin credentials**
  - [ ] Change admin password (12+ characters, mixed case, numbers, symbols)
  - [ ] Document credentials securely
  - [ ] Never use default password

- [ ] **Disable directory listing**
  ```apache
  # Apache .htaccess
  <Directory /var/www/html/campaignhq>
      Options -Indexes
  </Directory>
  ```

- [ ] **Configure firewall**
  ```bash
  sudo ufw allow 22/tcp   # SSH
  sudo ufw allow 80/tcp   # HTTP
  sudo ufw allow 443/tcp  # HTTPS
  sudo ufw enable
  ```

- [ ] **Set up fail2ban** (optional but recommended)
  ```bash
  sudo apt-get install fail2ban
  # Configure to block repeated login failures
  ```

- [ ] **Configure CORS** (in .env)
  - [ ] ALLOWED_ORIGINS set to your domain
  - [ ] Not * (wildcard) in production

- [ ] **Enable CSRF protection**
  - [ ] Verify CSRF token in meta tag
  - [ ] Check all forms have CSRF token

---

### ✅ Backups & Monitoring

- [ ] **Set up automated database backups**
  ```bash
  # Daily at 2 AM
  0 2 * * * mysqldump -u campaignhq_user -pPassword campaign_hq | gzip > /backups/campaign_hq_$(date +\%Y\%m\%d).sql.gz
  ```

- [ ] **Set up automated file backups**
  ```bash
  # Weekly on Sunday at 3 AM
  0 3 * * 0 tar -czf /backups/campaignhq_$(date +\%Y\%m\%d).tar.gz /var/www/html/campaignhq
  ```

- [ ] **Configure monitoring**
  - [ ] CPU usage alerts
  - [ ] Memory usage alerts
  - [ ] Disk space alerts
  - [ ] Application error alerts

- [ ] **Set up log rotation** (/etc/logrotate.d/campaignhq)
  ```
  /var/www/html/campaignhq/logs/*.log {
      daily
      rotate 30
      compress
      delaycompress
      notifempty
      create 0644 www-data www-data
      sharedscripts
  }
  ```

---

### ✅ Performance Optimization

- [ ] **Enable gzip compression** (Apache/Nginx)
  ```apache
  # Apache
  <IfModule mod_deflate.c>
      AddOutputFilterByType DEFLATE text/html text/css text/javascript
  </IfModule>
  ```

- [ ] **Set HTTP cache headers** (for static assets)
  ```apache
  <FilesMatch "\.css$|\.js$|\.jpg$|\.png$">
      Header set Cache-Control "max-age=31536000, public"
  </FilesMatch>
  ```

- [ ] **Enable database query cache** (MySQL)
  ```sql
  SET GLOBAL query_cache_size = 268435456;  # 256MB
  SET GLOBAL query_cache_type = 1;
  ```

- [ ] **Add database indexes** (if needed)
  ```sql
  CREATE INDEX idx_email ON leads(email);
  CREATE INDEX idx_created_at ON leads(created_at);
  ```

- [ ] **Consider caching layer** (Redis)
  - [ ] Install Redis
  - [ ] Configure session handler to Redis
  - [ ] Update config for cache

---

### ✅ Testing

- [ ] **Test application functionality**
  - [ ] [ ] Can access login page
  - [ ] [ ] Can login with admin account
  - [ ] [ ] Dashboard loads without errors
  - [ ] [ ] Can view leads
  - [ ] [ ] Can create new lead
  - [ ] [ ] Can create campaign
  - [ ] [ ] Can create email template
  - [ ] [ ] Can send test email

- [ ] **Test API endpoints**
  ```bash
  curl https://yourdomain.com/api/leads
  curl -X POST https://yourdomain.com/api/leads \
    -d '{"fullname":"Test","email":"test@example.com"}'
  ```

- [ ] **Test error handling**
  - [ ] Access non-existent page → 404
  - [ ] Access unauthorized resource → 403
  - [ ] Submit invalid data → validation error
  - [ ] Database down → graceful error

- [ ] **Test security**
  - [ ] HTTPS redirects HTTP
  - [ ] CSRF token required on forms
  - [ ] XSS attempts blocked
  - [ ] SQL injection attempts blocked
  - [ ] Session hijacking protected

---

### ✅ Documentation & Handoff

- [ ] **Create deployment documentation**
  - [ ] Server specs and credentials
  - [ ] Database backup schedule
  - [ ] Restore procedures
  - [ ] Emergency contacts

- [ ] **Create runbooks**
  - [ ] How to restart services
  - [ ] How to view logs
  - [ ] How to restore from backup
  - [ ] How to troubleshoot common issues

- [ ] **Document admin procedures**
  - [ ] How to create users
  - [ ] How to manage permissions
  - [ ] How to configure SendGrid
  - [ ] How to monitor analytics

- [ ] **Create maintenance schedule**
  - [ ] Weekly: Check logs
  - [ ] Monthly: Review database size
  - [ ] Quarterly: Update SSL certificate
  - [ ] Annually: Security audit

---

### ✅ Post-Launch Verification

- [ ] **Test login flow**
  - [ ] Login with admin account
  - [ ] Logout successfully
  - [ ] Password reset works
  - [ ] Session timeout works

- [ ] **Verify data integrity**
  - [ ] All 28 database tables present
  - [ ] No integrity constraint violations
  - [ ] Indexes created
  - [ ] Foreign keys working

- [ ] **Test email functionality**
  - [ ] Can create campaign
  - [ ] Can select recipients
  - [ ] Can send campaign
  - [ ] Email appears in SendGrid activity
  - [ ] Webhooks updating events

- [ ] **Monitor performance**
  - [ ] Response times acceptable (< 1s)
  - [ ] No error spikes in logs
  - [ ] Database queries optimized
  - [ ] Memory usage stable

- [ ] **Verify security**
  - [ ] HTTPS working
  - [ ] SSL certificate valid
  - [ ] No mixed content warnings
  - [ ] Security headers present

---

## 🚨 Critical Before Launch

- [ ] **Backup existing data** (if migrating from old system)
- [ ] **Test disaster recovery** (restore from backup works)
- [ ] **Change admin password** from default
- [ ] **Enable HTTPS** (not just HTTP)
- [ ] **Verify SendGrid API key** is correct and verified
- [ ] **Test with real email account** before launching to users
- [ ] **Set up monitoring and alerts**
- [ ] **Have rollback plan** in case of emergency

---

## 📋 Launch Day Checklist

**Before Opening to Users:**

- [ ] Database backup completed
- [ ] All tests passing
- [ ] Logs monitored
- [ ] Monitoring alerts configured
- [ ] Support team briefed
- [ ] Documentation reviewed

**After Launch:**

- [ ] Monitor error logs closely
- [ ] Watch for performance issues
- [ ] Check SendGrid integration
- [ ] Verify user signups/logins working
- [ ] Monitor database performance
- [ ] Respond to any user issues

---

## 📞 Emergency Contacts

| Role | Name | Phone | Email |
|------|------|-------|-------|
| DevOps | | | |
| DBA | | | |
| Support Lead | | | |
| Technical Lead | | | |

---

## 📚 Important Documents

- README.md - Project overview
- SETUP_GUIDE.md - Installation instructions
- API_DOCUMENTATION.md - API reference
- DEVELOPER_QUICK_REFERENCE.md - Dev guide
- PROJECT_SUMMARY.md - Architecture overview

---

## ✅ Sign-Off

- [ ] Project Manager: _________________ Date: _______
- [ ] Technical Lead: _________________ Date: _______
- [ ] DevOps/Sysadmin: ________________ Date: _______
- [ ] Security Team: __________________ Date: _______

---

**Ready to launch!** 🚀

If any item is unchecked, address before launching to production.
