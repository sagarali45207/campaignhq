<?php
/**
 * Authentication Middleware
 */

class AuthMiddleware {
    public static function handle($request, $response) {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            Logger::warning('Unauthorized access attempt from IP: ' . $request->ip());
            
            if ($request->isAjax()) {
                $response->error('Unauthorized', null, 401);
            } else {
                $response->redirect(BASE_URL . '/login?redirect=' . urlencode($request->path()));
            }
        }
        
        // Refresh session timeout
        if (isset($_SESSION['last_activity'])) {
            if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
                session_destroy();
                Logger::warning('Session timeout for user: ' . ($_SESSION['user_id'] ?? 'unknown'));
                $response->redirect(BASE_URL . '/login?expired=1');
            }
        }
        
        $_SESSION['last_activity'] = time();
    }
}

/**
 * RBAC Middleware
 */

class RBACMiddleware {
    public static function handle($request, $response, $requiredPermission = null) {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Check if user is authenticated
        if (!isset($_SESSION['user_id'])) {
            $response->error('Unauthorized', null, 401);
        }
        
        // Check permission if specified
        if ($requiredPermission && !in_array($requiredPermission, $_SESSION['permissions'] ?? [])) {
            Logger::warning('Permission denied for user ' . $_SESSION['user_id'] . ': ' . $requiredPermission);
            
            if ($request->isAjax()) {
                $response->error('Permission denied', null, 403);
            } else {
                $response->redirect(BASE_URL . '/error/403');
            }
        }
    }
}

/**
 * CSRF Protection Middleware
 */

class CSRFMiddleware {
    public static function handle($request, $response) {
        // Only check on POST, PUT, DELETE requests
        if (!in_array($request->method(), ['POST', 'PUT', 'DELETE'])) {
            return;
        }
        
        // Get CSRF token from request
        $token = $request->input('_csrf_token') ?? $request->header('X-CSRF-Token');
        
        // Verify token
        if (!Security::verifyCSRFToken($token)) {
            Logger::warning('CSRF token mismatch from IP: ' . $request->ip());
            $response->error('CSRF token validation failed', null, 419);
        }
    }
}

/**
 * Rate Limiting Middleware
 */

class RateLimitMiddleware {
    private static $cache = [];
    
    public static function handle($request, $response) {
        if (!RATE_LIMIT_ENABLED) {
            return;
        }
        
        $ip = $request->ip();
        $key = 'rate_limit_' . $ip;
        $now = time();
        
        // Initialize rate limit tracking
        if (!isset(self::$cache[$key])) {
            self::$cache[$key] = [
                'count' => 0,
                'first_request' => $now
            ];
        }
        
        $tracking = &self::$cache[$key];
        
        // Check if window has expired
        if ($now - $tracking['first_request'] > RATE_LIMIT_WINDOW) {
            $tracking = [
                'count' => 0,
                'first_request' => $now
            ];
        }
        
        // Increment request count
        $tracking['count']++;
        
        // Check if limit exceeded
        if ($tracking['count'] > RATE_LIMIT_REQUESTS) {
            Logger::warning('Rate limit exceeded for IP: ' . $ip);
            $response->error('Rate limit exceeded', null, 429);
        }
    }
}

/**
 * Logging Middleware
 */

class LoggingMiddleware {
    public static function handle($request, $response) {
        $method = $request->method();
        $path = $request->path();
        $ip = $request->ip();
        
        Logger::info("$method $path", [
            'ip' => $ip,
            'user_agent' => $request->userAgent(),
            'user_id' => $_SESSION['user_id'] ?? null
        ]);
    }
}

/**
 * CORS Middleware
 */

class CORSMiddleware {
    public static function handle($request, $response) {
        $origin = $request->header('Origin');
        
        if ($origin && in_array($origin, ALLOWED_ORIGINS)) {
            $response->header('Access-Control-Allow-Origin', $origin);
            $response->header('Access-Control-Allow-Credentials', 'true');
            $response->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-CSRF-Token');
            $response->header('Access-Control-Max-Age', '3600');
        }
        
        // Handle preflight requests
        if ($request->method() === 'OPTIONS') {
            exit;
        }
    }
}
