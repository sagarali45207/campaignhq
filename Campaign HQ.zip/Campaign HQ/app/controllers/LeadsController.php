<?php
/**
 * Lead Controller
 */

class LeadsController extends Controller {
    private $leadModel;
    
    public function __construct($request, $response) {
        parent::__construct($request, $response);
        $this->leadModel = new LeadModel();
    }
    
    /**
     * Show leads page
     */
    public function index() {
        $this->authorize('view_leads');
        $this->view('leads.index');
    }
    
    /**
     * Get leads with filters and pagination
     */
    public function getLeads() {
        $this->authorize('view_leads');
        
        $page = (int)$this->request->get('page', 1);
        $limit = (int)$this->request->get('limit', ITEMS_PER_PAGE);
        $filters = $this->request->get('filters', []);
        
        // Get leads
        $result = $this->leadModel->getLeadsWithFilters($page, $limit, $filters);
        
        $this->response->success('Leads retrieved', $result);
    }
    
    /**
     * Show single lead
     */
    public function show($params) {
        $this->authorize('view_leads');
        
        $leadId = (int)$params['id'];
        $lead = $this->leadModel->getWithCustomFields($leadId);
        
        if (!$lead) {
            $this->response->error('Lead not found', null, 404);
        }
        
        // Get tags
        $lead['tags'] = $this->leadModel->getTags($leadId);
        
        $this->response->success('Lead retrieved', $lead);
    }
    
    /**
     * Create new lead
     */
    public function store() {
        $this->authorize('edit_lead');
        
        // Verify CSRF
        if (!Security::verifyCSRFToken($this->request->post('_csrf_token'))) {
            $this->response->error('Invalid CSRF token', null, 419);
        }
        
        // Get and validate data
        $data = [
            'fullname' => Security::sanitize($this->request->post('fullname')),
            'firstname' => Security::sanitize($this->request->post('firstname')),
            'lastname' => Security::sanitize($this->request->post('lastname')),
            'email' => Security::sanitize($this->request->post('email')),
            'secondary_email' => Security::sanitize($this->request->post('secondary_email', '')),
            'company' => Security::sanitize($this->request->post('company', '')),
            'job_title' => Security::sanitize($this->request->post('job_title', '')),
            'department' => Security::sanitize($this->request->post('department', '')),
            'phone' => Security::sanitize($this->request->post('phone', '')),
            'mobile' => Security::sanitize($this->request->post('mobile', '')),
            'country_id' => $this->request->post('country_id') ?: null,
            'state' => Security::sanitize($this->request->post('state', '')),
            'city' => Security::sanitize($this->request->post('city', '')),
            'industry_id' => $this->request->post('industry_id') ?: null,
            'lead_source_id' => $this->request->post('lead_source_id') ?: null,
            'webinar_interest' => Security::sanitize($this->request->post('webinar_interest', '')),
            'lead_score' => (int)$this->request->post('lead_score', 0),
            'status_id' => $this->request->post('status_id') ?: 1,
            'remarks' => Security::sanitize($this->request->post('remarks', '')),
            'imported_by' => $_SESSION['user_id']
        ];
        
        // Validate required fields
        $errors = [];
        if (empty($data['fullname'])) $errors['fullname'] = 'Full name is required';
        if (empty($data['email'])) $errors['email'] = 'Email is required';
        if (!Security::isValidEmail($data['email'])) $errors['email'] = 'Invalid email format';
        
        if (!empty($errors)) {
            $this->response->error('Validation failed', $errors, 422);
        }
        
        // Check for duplicates
        if ($this->leadModel->emailExists($data['email'])) {
            $this->response->error('Lead with this email already exists', null, 409);
        }
        
        // Create lead
        $leadId = $this->leadModel->create($data);
        
        if (!$leadId) {
            $this->response->error('Failed to create lead', null, 500);
        }
        
        // Handle tags
        $tags = $this->request->post('tags', []);
        if (!empty($tags)) {
            $this->leadModel->addTags($leadId, $tags);
        }
        
        // Log audit
        $this->auditLog('create', 'leads', 'lead', $leadId, null, $data);
        
        // Add timeline event
        $this->addTimelineEvent($leadId, 'imported', 'Lead added', 'Lead manually created');
        
        Logger::info("Lead created: $leadId by user " . $_SESSION['user_id']);
        
        $this->response->success('Lead created successfully', ['id' => $leadId], 201);
    }
    
    /**
     * Update lead
     */
    public function update($params) {
        $this->authorize('edit_lead');
        
        $leadId = (int)$params['id'];
        
        // Check if lead exists
        $lead = $this->leadModel->find($leadId);
        if (!$lead) {
            $this->response->error('Lead not found', null, 404);
        }
        
        // Get POST data
        $input = $this->request->json() ?: $this->request->post();
        
        $data = [
            'fullname' => Security::sanitize($input['fullname'] ?? $lead['fullname']),
            'firstname' => Security::sanitize($input['firstname'] ?? $lead['firstname']),
            'lastname' => Security::sanitize($input['lastname'] ?? $lead['lastname']),
            'email' => Security::sanitize($input['email'] ?? $lead['email']),
            'secondary_email' => Security::sanitize($input['secondary_email'] ?? $lead['secondary_email']),
            'company' => Security::sanitize($input['company'] ?? $lead['company']),
            'job_title' => Security::sanitize($input['job_title'] ?? $lead['job_title']),
            'department' => Security::sanitize($input['department'] ?? $lead['department']),
            'phone' => Security::sanitize($input['phone'] ?? $lead['phone']),
            'mobile' => Security::sanitize($input['mobile'] ?? $lead['mobile']),
            'country_id' => $input['country_id'] ?? $lead['country_id'],
            'state' => Security::sanitize($input['state'] ?? $lead['state']),
            'city' => Security::sanitize($input['city'] ?? $lead['city']),
            'industry_id' => $input['industry_id'] ?? $lead['industry_id'],
            'lead_source_id' => $input['lead_source_id'] ?? $lead['lead_source_id'],
            'webinar_interest' => Security::sanitize($input['webinar_interest'] ?? $lead['webinar_interest']),
            'lead_score' => (int)($input['lead_score'] ?? $lead['lead_score']),
            'status_id' => $input['status_id'] ?? $lead['status_id'],
            'remarks' => Security::sanitize($input['remarks'] ?? $lead['remarks'])
        ];
        
        // Update lead
        if (!$this->leadModel->update($leadId, $data)) {
            $this->response->error('Failed to update lead', null, 500);
        }
        
        // Update tags if provided
        if (isset($input['tags'])) {
            $this->leadModel->removeTags($leadId);
            if (!empty($input['tags'])) {
                $this->leadModel->addTags($leadId, $input['tags']);
            }
        }
        
        // Track changes
        $changes = array_diff_assoc($data, $lead);
        if (!empty($changes)) {
            $this->auditLog('update', 'leads', 'lead', $leadId, $lead, $data);
        }
        
        Logger::info("Lead updated: $leadId by user " . $_SESSION['user_id']);
        
        $this->response->success('Lead updated successfully');
    }
    
    /**
     * Delete lead
     */
    public function delete($params) {
        $this->authorize('delete_lead');
        
        $leadId = (int)$params['id'];
        
        if (!$this->leadModel->find($leadId)) {
            $this->response->error('Lead not found', null, 404);
        }
        
        if (!$this->leadModel->delete($leadId)) {
            $this->response->error('Failed to delete lead', null, 500);
        }
        
        $this->auditLog('delete', 'leads', 'lead', $leadId);
        Logger::info("Lead deleted: $leadId by user " . $_SESSION['user_id']);
        
        $this->response->success('Lead deleted successfully');
    }
    
    /**
     * Show import form
     */
    public function importForm() {
        $this->authorize('import_leads');
        $this->view('leads.import');
    }
    
    /**
     * Handle lead import
     */
    public function handleImport() {
        $this->authorize('import_leads');
        
        // TODO: Implement file upload, parsing, and validation
        // Using PhpSpreadsheet library
        
        $this->response->error('Import not yet implemented', null, 501);
    }
    
    /**
     * Bulk action on leads
     */
    public function bulkAction() {
        $this->authorize('edit_lead');
        
        $input = $this->request->json();
        $leadIds = $input['lead_ids'] ?? [];
        $action = $input['action'] ?? '';
        
        if (empty($leadIds)) {
            $this->response->error('No leads selected', null, 400);
        }
        
        $success = 0;
        $placeholders = implode(',', array_fill(0, count($leadIds), '?'));
        
        switch ($action) {
            case 'change_status':
                $statusId = $input['status_id'] ?? null;
                if (!$statusId) {
                    $this->response->error('Status ID required', null, 400);
                }
                
                $this->db->query("UPDATE leads SET status_id = ? WHERE id IN ($placeholders)");
                $this->db->bind(1, $statusId);
                foreach ($leadIds as $i => $id) {
                    $this->db->bind($i + 2, $id);
                }
                $success = $this->db->rowCount() if $this->db->execute();
                break;
                
            case 'add_tags':
                $tags = $input['tags'] ?? [];
                foreach ($leadIds as $leadId) {
                    $this->leadModel->addTags($leadId, $tags);
                    $success++;
                }
                break;
                
            case 'send_email':
                // TODO: Implement bulk email sending
                break;
                
            case 'delete':
                foreach ($leadIds as $leadId) {
                    if ($this->leadModel->delete($leadId)) {
                        $success++;
                    }
                }
                break;
        }
        
        $this->response->success("Bulk action completed on $success leads");
    }
    
    /**
     * Export leads
     */
    public function export($params) {
        $this->authorize('export_leads');
        
        $format = $params['format'] ?? 'csv';
        
        if (!in_array($format, ['csv', 'excel', 'pdf'])) {
            $this->response->error('Invalid export format', null, 400);
        }
        
        // TODO: Implement export functionality
        $this->response->error('Export not yet implemented', null, 501);
    }
    
    /**
     * Add note to lead
     */
    public function addNote($params) {
        $leadId = (int)$params['id'];
        $input = $this->request->json();
        
        // Verify lead exists
        if (!$this->leadModel->find($leadId)) {
            $this->response->error('Lead not found', null, 404);
        }
        
        $note = [
            'lead_id' => $leadId,
            'note_type' => $input['type'] ?? 'internal_note',
            'content' => Security::sanitize($input['content'] ?? ''),
            'created_by' => $_SESSION['user_id'],
            'created_at' => date(DATETIME_FORMAT)
        ];
        
        $this->db->query('
            INSERT INTO lead_notes (lead_id, note_type, content, created_by, created_at)
            VALUES (:lead_id, :note_type, :content, :created_by, :created_at)
        ');
        
        foreach ($note as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        
        if ($this->db->execute()) {
            $this->addTimelineEvent($leadId, 'note_added', 'Note added', $input['content']);
            $this->response->success('Note added successfully', ['id' => $this->db->lastInsertId()], 201);
        } else {
            $this->response->error('Failed to add note', null, 500);
        }
    }
    
    /**
     * Get notes for lead
     */
    public function getNotes($params) {
        $leadId = (int)$params['id'];
        
        $this->db->query('
            SELECT ln.*, u.fullname as created_by_name
            FROM lead_notes ln
            JOIN users u ON ln.created_by = u.id
            WHERE ln.lead_id = :lead_id
            ORDER BY ln.created_at DESC
        ');
        $this->db->bind(':lead_id', $leadId);
        
        $notes = $this->db->resultSet();
        $this->response->success('Notes retrieved', $notes);
    }
    
    /**
     * Get lead timeline
     */
    public function getTimeline($params) {
        $leadId = (int)$params['id'];
        
        $this->db->query('
            SELECT lt.*, u.fullname as triggered_by_name
            FROM lead_timeline lt
            LEFT JOIN users u ON lt.triggered_by = u.id
            WHERE lt.lead_id = :lead_id
            ORDER BY lt.created_at DESC
        ');
        $this->db->bind(':lead_id', $leadId);
        
        $timeline = $this->db->resultSet();
        $this->response->success('Timeline retrieved', $timeline);
    }
    
    /**
     * Helper: Add timeline event
     */
    private function addTimelineEvent($leadId, $eventType, $title, $description = '', $metadata = null) {
        $this->db->query('
            INSERT INTO lead_timeline (lead_id, event_type, event_title, event_description, metadata, triggered_by, created_at)
            VALUES (:lead_id, :event_type, :title, :description, :metadata, :triggered_by, NOW())
        ');
        
        $this->db->bind(':lead_id', $leadId);
        $this->db->bind(':event_type', $eventType);
        $this->db->bind(':title', $title);
        $this->db->bind(':description', $description);
        $this->db->bind(':metadata', $metadata ? json_encode($metadata) : null);
        $this->db->bind(':triggered_by', $_SESSION['user_id'] ?? null);
        
        return $this->db->execute();
    }
}
