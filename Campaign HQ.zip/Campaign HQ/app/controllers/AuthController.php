<?php
/**
 * Auth Controller
 */

class AuthController extends Controller {
    private $userModel;
    
    public function __construct($request, $response) {
        parent::__construct($request, $response);
        $this->userModel = new UserModel();
    }
    
    /**
     * Show login page
     */
    public function login() {
        if (isset($_SESSION['user_id'])) {
            $this->response->redirect(BASE_URL . '/dashboard');
        }
        
        $error = '';
        $message = '';
        
        if ($this->request->isGet()) {
            if ($this->request->get('expired')) {
                $message = 'Your session has expired. Please login again.';
            }
            if ($this->request->get('redirect')) {
                $_SESSION['redirect_after_login'] = $this->request->get('redirect');
            }
        }
        
        $this->view('auth.login', [
            'error' => $error,
            'message' => $message
        ]);
    }
    
    /**
     * Handle login
     */
    public function handleLogin() {
        // Start session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Verify CSRF token
        if (!Security::verifyCSRFToken($this->request->post('_csrf_token'))) {
            Logger::warning('CSRF token validation failed on login');
            $this->response->error('Invalid request', null, 419);
        }
        
        // Validate input
        $email = Security::sanitize($this->request->post('email'));
        $password = $this->request->post('password');
        $rememberMe = $this->request->post('remember_me') === 'on';
        
        if (empty($email) || empty($password)) {
            $this->response->error('Email and password are required', null, 400);
        }
        
        // Authenticate user
        $user = $this->userModel->authenticate($email, $password);
        
        if (!$user) {
            $this->response->error('Invalid credentials', null, 401);
        }
        
        // Get user with permissions
        $userWithPermissions = $this->userModel->getUserWithPermissions($user['id']);
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user'] = $user;
        $_SESSION['role'] = $userWithPermissions['role_name'];
        $_SESSION['permissions'] = $userWithPermissions['permissions'] ? explode(',', $userWithPermissions['permissions']) : [];
        $_SESSION['last_activity'] = time();
        
        // Handle remember me
        if ($rememberMe) {
            $token = Security::generateToken();
            $_SESSION['remember_me_token'] = $token;
            
            setcookie('remember_me_token', $token, time() + REMEMBER_ME_DURATION, '/', SESSION_DOMAIN, SESSION_SECURE, SESSION_HTTPONLY);
            setcookie('remember_me_email', $email, time() + REMEMBER_ME_DURATION, '/', SESSION_DOMAIN, SESSION_SECURE, SESSION_HTTPONLY);
            
            // Save token to database
            $this->db->query('UPDATE users SET remember_me_token = :token WHERE id = :id');
            $this->db->bind(':token', $token);
            $this->db->bind(':id', $user['id']);
            $this->db->execute();
        }
        
        // Log audit
        $this->auditLog('login', 'auth', 'user', $user['id']);
        
        // Redirect
        $redirectUrl = $_SESSION['redirect_after_login'] ?? '/dashboard';
        unset($_SESSION['redirect_after_login']);
        
        $this->response->success('Login successful', ['redirect' => BASE_URL . $redirectUrl]);
    }
    
    /**
     * Show forgot password page
     */
    public function forgotPassword() {
        $error = '';
        $success = '';
        
        $this->view('auth.forgot-password', [
            'error' => $error,
            'success' => $success
        ]);
    }
    
    /**
     * Handle forgot password
     */
    public function handleForgotPassword() {
        // Verify CSRF token
        if (!Security::verifyCSRFToken($this->request->post('_csrf_token'))) {
            $this->response->error('Invalid request', null, 419);
        }
        
        $email = Security::sanitize($this->request->post('email'));
        
        if (!Security::isValidEmail($email)) {
            $this->response->error('Please enter a valid email address', null, 400);
        }
        
        // Create password reset token
        $resetToken = $this->userModel->createPasswordResetToken($email);
        
        if ($resetToken) {
            // TODO: Send email with reset link
            $resetLink = BASE_URL . '/reset-password?token=' . urlencode($resetToken);
            Logger::info("Password reset link: $resetLink");
            
            $this->response->success('Password reset link sent to your email');
        } else {
            // Don't reveal if email exists
            $this->response->success('If an account with this email exists, you will receive a password reset link');
        }
    }
    
    /**
     * Show reset password page
     */
    public function resetPassword() {
        $token = $this->request->get('token');
        
        if (!$token) {
            $this->response->redirect(BASE_URL . '/login');
        }
        
        // Verify token
        $userId = $this->userModel->verifyPasswordResetToken($token);
        
        if (!$userId) {
            $error = 'This password reset link has expired or is invalid.';
            $this->view('auth.reset-password', ['error' => $error, 'token' => null]);
            return;
        }
        
        $this->view('auth.reset-password', ['error' => '', 'token' => $token]);
    }
    
    /**
     * Handle reset password
     */
    public function handleResetPassword() {
        // Verify CSRF token
        if (!Security::verifyCSRFToken($this->request->post('_csrf_token'))) {
            $this->response->error('Invalid request', null, 419);
        }
        
        $token = $this->request->post('token');
        $password = $this->request->post('password');
        $confirmPassword = $this->request->post('password_confirmation');
        
        if (!$token) {
            $this->response->error('Invalid request', null, 400);
        }
        
        if ($password !== $confirmPassword) {
            $this->response->error('Passwords do not match', null, 400);
        }
        
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            $this->response->error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters', null, 400);
        }
        
        // Verify token and get user ID
        $userId = $this->userModel->verifyPasswordResetToken($token);
        
        if (!$userId) {
            $this->response->error('Invalid or expired reset token', null, 400);
        }
        
        // Reset password
        if ($this->userModel->resetPassword($userId, $password)) {
            Logger::info("Password reset successful for user ID: $userId");
            $this->response->success('Password reset successful', ['redirect' => BASE_URL . '/login']);
        } else {
            $this->response->error('Failed to reset password', null, 500);
        }
    }
    
    /**
     * Handle logout
     */
    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $userId = $_SESSION['user_id'] ?? null;
        
        // Log audit
        if ($userId) {
            $this->auditLog('logout', 'auth', 'user', $userId);
        }
        
        // Clear session
        session_destroy();
        
        // Clear remember me cookies
        setcookie('remember_me_token', '', time() - 3600, '/');
        setcookie('remember_me_email', '', time() - 3600, '/');
        
        Logger::info("User logged out: $userId");
        
        $this->response->redirect(BASE_URL . '/login?logged_out=1');
    }
    
    /**
     * Check if user is authenticated
     */
    public function status() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (isset($_SESSION['user_id'])) {
            $this->response->success('User is authenticated', [
                'user_id' => $_SESSION['user_id'],
                'user' => $_SESSION['user'],
                'role' => $_SESSION['role']
            ]);
        } else {
            $this->response->error('User is not authenticated', null, 401);
        }
    }
}
