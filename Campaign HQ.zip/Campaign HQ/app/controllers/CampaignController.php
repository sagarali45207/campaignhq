<?php
/**
 * Campaign Controller
 */

class CampaignController extends Controller {
    private $campaignModel;
    
    public function __construct() {
        parent::__construct();
        $this->campaignModel = new CampaignModel();
    }
    
    /**
     * List campaigns page
     */
    public function index() {
        $this->authorize('campaigns', 'view');
        return $this->view('campaigns/index', [
            'title' => 'Campaigns',
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Get campaigns with AJAX
     */
    public function getCampaigns() {
        $this->authorize('campaigns', 'view');
        
        $page = Request::get('page') ?? 1;
        $search = Request::get('search') ?? '';
        $status = Request::get('status') ?? '';
        $type = Request::get('campaign_type_id') ?? '';
        
        $filters = [];
        if ($search) $filters['search'] = $search;
        if ($status) $filters['status'] = $status;
        if ($type) $filters['campaign_type_id'] = $type;
        
        $result = $this->campaignModel->getCampaignsWithFilters($page, ITEMS_PER_PAGE, $filters);
        
        return Response::json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => [
                'current' => $result['page'],
                'total' => $result['pages'],
                'count' => count($result['data']),
                'total_items' => $result['total']
            ]
        ]);
    }
    
    /**
     * Show create campaign form
     */
    public function create() {
        $this->authorize('campaigns', 'create');
        
        return $this->view('campaigns/create', [
            'title' => 'Create Campaign',
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'url' => '/campaigns'],
                ['name' => 'Create', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Store campaign
     */
    public function store() {
        $this->authorize('campaigns', 'create');
        
        $validator = $this->validate([
            'name' => 'required|string|max:255',
            'campaign_type_id' => 'required|integer',
            'subject' => 'required|string|max:255',
            'template_id' => 'required|integer',
            'sender_name' => 'required|string|max:255',
            'sender_email' => 'required|email'
        ]);
        
        if (!$validator->passes()) {
            return Response::json([
                'success' => false,
                'errors' => $validator->errors
            ], 422);
        }
        
        $data = [
            'name' => Security::sanitize(Request::post('name')),
            'campaign_type_id' => (int)Request::post('campaign_type_id'),
            'subject' => Security::sanitize(Request::post('subject')),
            'template_id' => (int)Request::post('template_id'),
            'sender_name' => Security::sanitize(Request::post('sender_name')),
            'sender_email' => filter_var(Request::post('sender_email'), FILTER_SANITIZE_EMAIL),
            'notes' => Security::sanitize(Request::post('notes') ?? ''),
            'status' => 'draft'
        ];
        
        $id = $this->campaignModel->create($data);
        
        $this->auditLog('campaign_created', 'campaigns', $id, [
            'name' => $data['name'],
            'type' => $data['campaign_type_id']
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Campaign created successfully',
            'data' => [
                'id' => $id,
                'redirect' => '/campaigns/' . $id . '/edit'
            ]
        ]);
    }
    
    /**
     * Show campaign edit form
     */
    public function edit($id) {
        $this->authorize('campaigns', 'edit');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::status(404);
        }
        
        return $this->view('campaigns/edit', [
            'title' => 'Edit Campaign',
            'campaign' => $campaign,
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'url' => '/campaigns'],
                ['name' => $campaign['name'], 'active' => true]
            ]
        ]);
    }
    
    /**
     * Update campaign
     */
    public function update($id) {
        $this->authorize('campaigns', 'edit');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::json([
                'success' => false,
                'message' => 'Campaign not found'
            ], 404);
        }
        
        $validator = $this->validate([
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255'
        ]);
        
        if (!$validator->passes()) {
            return Response::json([
                'success' => false,
                'errors' => $validator->errors
            ], 422);
        }
        
        $data = [
            'name' => Security::sanitize(Request::input('name')),
            'subject' => Security::sanitize(Request::input('subject')),
            'notes' => Security::sanitize(Request::input('notes') ?? '')
        ];
        
        $this->campaignModel->update($id, $data);
        
        $this->auditLog('campaign_updated', 'campaigns', $id, $data);
        
        return Response::json([
            'success' => true,
            'message' => 'Campaign updated successfully'
        ]);
    }
    
    /**
     * Show campaign details
     */
    public function show($id) {
        $this->authorize('campaigns', 'view');
        
        $campaign = $this->campaignModel->getCampaignWithRecipients($id);
        
        if (!$campaign) {
            return Response::status(404);
        }
        
        $analytics = $this->campaignModel->getAnalytics($id);
        
        return $this->view('campaigns/show', [
            'title' => $campaign['name'],
            'campaign' => $campaign,
            'analytics' => $analytics,
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'url' => '/campaigns'],
                ['name' => $campaign['name'], 'active' => true]
            ]
        ]);
    }
    
    /**
     * Delete campaign
     */
    public function delete($id) {
        $this->authorize('campaigns', 'delete');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::json([
                'success' => false,
                'message' => 'Campaign not found'
            ], 404);
        }
        
        // Can't delete sent campaigns
        if ($campaign['status'] === 'completed' || $campaign['status'] === 'sending') {
            return Response::json([
                'success' => false,
                'message' => 'Cannot delete campaigns that have been sent'
            ], 400);
        }
        
        $this->campaignModel->delete($id);
        
        $this->auditLog('campaign_deleted', 'campaigns', $id, [
            'name' => $campaign['name']
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Campaign deleted successfully'
        ]);
    }
    
    /**
     * Get campaign details for AJAX
     */
    public function getCampaign($id) {
        $this->authorize('campaigns', 'view');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::json([
                'success' => false,
                'message' => 'Campaign not found'
            ], 404);
        }
        
        return Response::json([
            'success' => true,
            'data' => $campaign
        ]);
    }
    
    /**
     * Get campaign analytics
     */
    public function getAnalytics($id) {
        $this->authorize('campaigns', 'view');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::json([
                'success' => false,
                'message' => 'Campaign not found'
            ], 404);
        }
        
        $analytics = $this->campaignModel->getAnalytics($id);
        
        return Response::json([
            'success' => true,
            'data' => $analytics
        ]);
    }
    
    /**
     * Select recipients for campaign
     */
    public function selectRecipients($id) {
        $this->authorize('campaigns', 'edit');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::status(404);
        }
        
        return $this->view('campaigns/select-recipients', [
            'title' => 'Select Recipients - ' . $campaign['name'],
            'campaign' => $campaign,
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'url' => '/campaigns'],
                ['name' => $campaign['name'], 'url' => '/campaigns/' . $id],
                ['name' => 'Select Recipients', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Save recipients for campaign
     */
    public function saveRecipients($id) {
        $this->authorize('campaigns', 'edit');
        
        $leadIds = Request::post('lead_ids') ?? [];
        
        if (empty($leadIds)) {
            return Response::json([
                'success' => false,
                'message' => 'Please select at least one recipient'
            ], 400);
        }
        
        $db = Database::getInstance();
        
        // Delete existing recipients
        $db->query('DELETE FROM campaign_leads WHERE campaign_id = :campaign_id');
        $db->bind(':campaign_id', $id);
        $db->execute();
        
        // Insert new recipients
        foreach ($leadIds as $leadId) {
            $db->query('
                INSERT INTO campaign_leads (campaign_id, lead_id, status, created_at)
                VALUES (:campaign_id, :lead_id, "pending", NOW())
            ');
            $db->bind(':campaign_id', $id);
            $db->bind(':lead_id', (int)$leadId);
            $db->execute();
        }
        
        $this->auditLog('campaign_recipients_updated', 'campaigns', $id, [
            'recipient_count' => count($leadIds)
        ]);
        
        return Response::json([
            'success' => true,
            'message' => count($leadIds) . ' recipients added to campaign'
        ]);
    }
    
    /**
     * Show send campaign form
     */
    public function showSend($id) {
        $this->authorize('campaigns', 'edit');
        
        $campaign = $this->campaignModel->getCampaignWithRecipients($id);
        
        if (!$campaign) {
            return Response::status(404);
        }
        
        if (empty($campaign['recipients'])) {
            return Response::status(400);
        }
        
        return $this->view('campaigns/send', [
            'title' => 'Send Campaign',
            'campaign' => $campaign,
            'recipient_count' => count($campaign['recipients']),
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Campaigns', 'url' => '/campaigns'],
                ['name' => $campaign['name'], 'url' => '/campaigns/' . $id],
                ['name' => 'Send', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Send campaign
     */
    public function send($id) {
        $this->authorize('campaigns', 'edit');
        
        $campaign = $this->campaignModel->find($id);
        
        if (!$campaign) {
            return Response::json([
                'success' => false,
                'message' => 'Campaign not found'
            ], 404);
        }
        
        if ($campaign['status'] === 'completed' || $campaign['status'] === 'sending') {
            return Response::json([
                'success' => false,
                'message' => 'Campaign has already been sent'
            ], 400);
        }
        
        // Update campaign status to sending
        $this->campaignModel->update($id, ['status' => 'sending']);
        
        // Get recipients
        $campaign = $this->campaignModel->getCampaignWithRecipients($id);
        
        // TODO: Integrate with SendGrid to send emails
        // For now, just update status to completed
        
        $this->campaignModel->update($id, ['status' => 'completed']);
        
        $this->auditLog('campaign_sent', 'campaigns', $id, [
            'name' => $campaign['name'],
            'recipient_count' => count($campaign['recipients'])
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Campaign sent successfully'
        ]);
    }
}
