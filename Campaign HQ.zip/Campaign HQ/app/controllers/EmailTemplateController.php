<?php
/**
 * Email Template Controller
 */

class EmailTemplateController extends Controller {
    private $templateModel;
    
    public function __construct() {
        parent::__construct();
        $this->templateModel = new EmailTemplateModel();
    }
    
    /**
     * List templates
     */
    public function index() {
        $this->authorize('templates', 'view');
        
        $templates = $this->templateModel->all();
        
        return $this->view('templates/index', [
            'title' => 'Email Templates',
            'templates' => $templates,
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Email Templates', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Get templates via AJAX
     */
    public function getTemplates() {
        $this->authorize('templates', 'view');
        
        $page = Request::get('page') ?? 1;
        $search = Request::get('search') ?? '';
        $type = Request::get('type') ?? '';
        
        $db = Database::getInstance();
        
        $query = 'SELECT * FROM email_templates WHERE 1=1';
        $params = [];
        
        if ($search) {
            $query .= ' AND name LIKE :search';
            $params['search'] = '%' . $search . '%';
        }
        
        if ($type) {
            $query .= ' AND template_type = :type';
            $params['type'] = $type;
        }
        
        // Get total
        $countQuery = str_replace('SELECT *', 'SELECT COUNT(*) as total', $query);
        $db->query($countQuery);
        foreach ($params as $key => $value) {
            $db->bind(':' . $key, $value);
        }
        $db->execute();
        $totalResult = $db->single();
        $total = $totalResult['total'];
        
        // Get paginated
        $limit = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $limit;
        $query .= ' ORDER BY created_at DESC LIMIT :limit OFFSET :offset';
        
        $db->query($query);
        foreach ($params as $key => $value) {
            $db->bind(':' . $key, $value);
        }
        $db->bind(':limit', $limit, PDO::PARAM_INT);
        $db->bind(':offset', $offset, PDO::PARAM_INT);
        
        $data = $db->resultSet();
        
        return Response::json([
            'success' => true,
            'data' => $data,
            'pagination' => [
                'current' => $page,
                'total' => ceil($total / $limit),
                'count' => count($data),
                'total_items' => $total
            ]
        ]);
    }
    
    /**
     * Create template form
     */
    public function create() {
        $this->authorize('templates', 'create');
        
        return $this->view('templates/create', [
            'title' => 'Create Email Template',
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Email Templates', 'url' => '/templates'],
                ['name' => 'Create', 'active' => true]
            ]
        ]);
    }
    
    /**
     * Store template
     */
    public function store() {
        $this->authorize('templates', 'create');
        
        $validator = $this->validate([
            'name' => 'required|string|max:255',
            'template_type' => 'required|string',
            'subject' => 'required|string|max:255',
            'body' => 'required|string'
        ]);
        
        if (!$validator->passes()) {
            return Response::json([
                'success' => false,
                'errors' => $validator->errors
            ], 422);
        }
        
        $variables = $this->extractVariables(Request::post('body'));
        
        $data = [
            'name' => Security::sanitize(Request::post('name')),
            'template_type' => Security::sanitize(Request::post('template_type')),
            'subject' => Security::sanitize(Request::post('subject')),
            'body' => Request::post('body'),  // Store HTML body as-is
            'variables' => json_encode($variables),
            'status' => 'active'
        ];
        
        $id = $this->templateModel->create($data);
        
        $this->auditLog('template_created', 'email_templates', $id, [
            'name' => $data['name'],
            'type' => $data['template_type']
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Template created successfully',
            'data' => ['id' => $id]
        ]);
    }
    
    /**
     * Edit template form
     */
    public function edit($id) {
        $this->authorize('templates', 'edit');
        
        $template = $this->templateModel->find($id);
        
        if (!$template) {
            return Response::status(404);
        }
        
        return $this->view('templates/edit', [
            'title' => 'Edit Template',
            'template' => $template,
            'breadcrumbs' => [
                ['name' => 'Dashboard', 'url' => '/dashboard'],
                ['name' => 'Email Templates', 'url' => '/templates'],
                ['name' => $template['name'], 'active' => true]
            ]
        ]);
    }
    
    /**
     * Update template
     */
    public function update($id) {
        $this->authorize('templates', 'edit');
        
        $template = $this->templateModel->find($id);
        
        if (!$template) {
            return Response::json([
                'success' => false,
                'message' => 'Template not found'
            ], 404);
        }
        
        $validator = $this->validate([
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'body' => 'required|string'
        ]);
        
        if (!$validator->passes()) {
            return Response::json([
                'success' => false,
                'errors' => $validator->errors
            ], 422);
        }
        
        $variables = $this->extractVariables(Request::input('body'));
        
        $data = [
            'name' => Security::sanitize(Request::input('name')),
            'subject' => Security::sanitize(Request::input('subject')),
            'body' => Request::input('body'),
            'variables' => json_encode($variables)
        ];
        
        $this->templateModel->update($id, $data);
        
        $this->auditLog('template_updated', 'email_templates', $id, [
            'name' => $data['name']
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Template updated successfully'
        ]);
    }
    
    /**
     * Delete template
     */
    public function delete($id) {
        $this->authorize('templates', 'delete');
        
        $template = $this->templateModel->find($id);
        
        if (!$template) {
            return Response::json([
                'success' => false,
                'message' => 'Template not found'
            ], 404);
        }
        
        $this->templateModel->delete($id);
        
        $this->auditLog('template_deleted', 'email_templates', $id, [
            'name' => $template['name']
        ]);
        
        return Response::json([
            'success' => true,
            'message' => 'Template deleted successfully'
        ]);
    }
    
    /**
     * Preview template
     */
    public function preview($id) {
        $this->authorize('templates', 'view');
        
        $template = $this->templateModel->getForRender($id);
        
        if (!$template) {
            return Response::json([
                'success' => false,
                'message' => 'Template not found'
            ], 404);
        }
        
        // Create sample variables
        $sampleVars = [];
        foreach ($template['variables'] as $var) {
            $sampleVars[$var] = 'Sample ' . ucfirst(str_replace('_', ' ', $var));
        }
        
        $rendered = $this->templateModel->render($id, $sampleVars);
        
        return Response::json([
            'success' => true,
            'data' => $rendered
        ]);
    }
    
    /**
     * Extract variables from template
     */
    private function extractVariables($body) {
        $variables = [];
        preg_match_all('/\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}/', $body, $matches);
        
        if (!empty($matches[1])) {
            $variables = array_unique($matches[1]);
        }
        
        return array_values($variables);
    }
}
