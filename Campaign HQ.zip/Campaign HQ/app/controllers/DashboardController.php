<?php
/**
 * Dashboard Controller
 */

class DashboardController extends Controller {
    private $leadModel;
    
    public function __construct($request, $response) {
        parent::__construct($request, $response);
        $this->leadModel = new LeadModel();
    }
    
    /**
     * Show dashboard page
     */
    public function index() {
        $this->view('dashboard.index');
    }
    
    /**
     * Get dashboard statistics
     */
    public function getStats() {
        // Lead statistics
        $leadStats = $this->leadModel->getStatistics();
        
        // Campaign statistics
        $this->db->query('
            SELECT
                COUNT(*) as total_campaigns,
                SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as sent_campaigns,
                SUM(emails_sent) as total_emails_sent,
                SUM(emails_delivered) as total_emails_delivered,
                SUM(emails_opened) as total_emails_opened,
                SUM(emails_clicked) as total_emails_clicked,
                SUM(emails_bounced) as total_emails_bounced,
                SUM(emails_unsubscribed) as total_unsubscribed
            FROM campaigns
        ');
        $this->db->execute();
        $campaignStats = $this->db->single();
        
        // Calculate rates
        $emailDelivered = (int)$campaignStats['total_emails_delivered'];
        $emailSent = (int)$campaignStats['total_emails_sent'] ?: 1;
        $deliveryRate = ($emailDelivered / $emailSent) * 100;
        
        $emailOpened = (int)$campaignStats['total_emails_opened'];
        $openRate = ($emailOpened / $emailSent) * 100;
        
        $emailClicked = (int)$campaignStats['total_emails_clicked'];
        $clickRate = ($emailClicked / $emailSent) * 100;
        
        $emailBounced = (int)$campaignStats['total_emails_bounced'];
        $bounceRate = ($emailBounced / $emailSent) * 100;
        
        $emailUnsubscribed = (int)$campaignStats['total_unsubscribed'];
        $unsubscribeRate = ($emailUnsubscribed / $emailSent) * 100;
        
        // Follow-ups statistics
        $this->db->query('
            SELECT
                COUNT(*) as total_followups,
                SUM(CASE WHEN status = "pending" THEN 1 ELSE 0 END) as pending_followups,
                SUM(CASE WHEN status = "overdue" THEN 1 ELSE 0 END) as overdue_followups,
                SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as completed_followups
            FROM followups
        ');
        $this->db->execute();
        $followupStats = $this->db->single();
        
        $stats = [
            'leads' => [
                'total' => $leadStats['total_leads'] ?? 0,
                'new' => $leadStats['new_leads'] ?? 0,
                'won' => $leadStats['won_leads'] ?? 0,
                'lost' => $leadStats['lost_leads'] ?? 0,
                'unsubscribed' => $leadStats['unsubscribed_leads'] ?? 0,
                'avg_score' => round($leadStats['avg_lead_score'] ?? 0, 2)
            ],
            'campaigns' => [
                'total' => $campaignStats['total_campaigns'] ?? 0,
                'sent' => $campaignStats['sent_campaigns'] ?? 0,
                'total_emails_sent' => $campaignStats['total_emails_sent'] ?? 0,
                'delivery_rate' => round($deliveryRate, 2),
                'open_rate' => round($openRate, 2),
                'click_rate' => round($clickRate, 2),
                'bounce_rate' => round($bounceRate, 2),
                'unsubscribe_rate' => round($unsubscribeRate, 2)
            ],
            'followups' => [
                'total' => $followupStats['total_followups'] ?? 0,
                'pending' => $followupStats['pending_followups'] ?? 0,
                'overdue' => $followupStats['overdue_followups'] ?? 0,
                'completed' => $followupStats['completed_followups'] ?? 0
            ]
        ];
        
        $this->response->success('Dashboard statistics retrieved', $stats);
    }
    
    /**
     * Get chart data
     */
    public function getCharts() {
        $chartType = $this->request->get('type', 'all');
        $data = [];
        
        if (in_array($chartType, ['all', 'lead_sources'])) {
            // Lead sources distribution
            $this->db->query('
                SELECT ls.name, COUNT(l.id) as count
                FROM leads l
                LEFT JOIN lead_sources ls ON l.lead_source_id = ls.id
                GROUP BY l.lead_source_id
                ORDER BY count DESC
                LIMIT 10
            ');
            $this->db->execute();
            $data['lead_sources'] = $this->db->resultSet();
        }
        
        if (in_array($chartType, ['all', 'lead_status'])) {
            // Lead status distribution
            $this->db->query('
                SELECT ls.name, COUNT(l.id) as count
                FROM leads l
                LEFT JOIN lead_statuses ls ON l.status_id = ls.id
                GROUP BY l.status_id
                ORDER BY count DESC
            ');
            $this->db->execute();
            $data['lead_status'] = $this->db->resultSet();
        }
        
        if (in_array($chartType, ['all', 'campaign_performance'])) {
            // Campaign performance
            $this->db->query('
                SELECT
                    DATE(created_at) as date,
                    COUNT(*) as total,
                    SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as completed,
                    SUM(emails_sent) as emails_sent,
                    SUM(emails_opened) as emails_opened
                FROM campaigns
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ');
            $this->db->execute();
            $data['campaign_performance'] = $this->db->resultSet();
        }
        
        if (in_array($chartType, ['all', 'email_metrics'])) {
            // Email metrics trend
            $this->db->query('
                SELECT
                    DATE(sent_at) as date,
                    COUNT(*) as sent,
                    SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as delivered,
                    SUM(CASE WHEN status IN ("opened") THEN 1 ELSE 0 END) as opened,
                    SUM(CASE WHEN status IN ("clicked") THEN 1 ELSE 0 END) as clicked
                FROM email_logs
                WHERE sent_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE(sent_at)
                ORDER BY date ASC
            ');
            $this->db->execute();
            $data['email_metrics'] = $this->db->resultSet();
        }
        
        if (in_array($chartType, ['all', 'top_countries'])) {
            // Top countries by leads
            $this->db->query('
                SELECT c.name, COUNT(l.id) as count
                FROM leads l
                LEFT JOIN countries c ON l.country_id = c.id
                GROUP BY l.country_id
                ORDER BY count DESC
                LIMIT 10
            ');
            $this->db->execute();
            $data['top_countries'] = $this->db->resultSet();
        }
        
        $this->response->success('Chart data retrieved', $data);
    }
}
