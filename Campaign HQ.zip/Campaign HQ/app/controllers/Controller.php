<?php
/**
 * Base Controller Class
 */

class Controller {
    protected $request;
    protected $response;
    protected $db;
    protected $user;
    
    public function __construct($request, $response) {
        $this->request = $request;
        $this->response = $response;
        $this->db = Database::getInstance();
        
        // Get authenticated user
        if (isset($_SESSION['user_id'])) {
            $this->user = $_SESSION['user'];
        }
    }
    
    /**
     * Check user permission
     */
    protected function authorize($permission) {
        if (!isset($_SESSION['permissions']) || !in_array($permission, $_SESSION['permissions'])) {
            Logger::warning('Authorization failed for user ' . $_SESSION['user_id'] . ': ' . $permission);
            $this->response->error('Permission denied', null, 403);
        }
    }
    
    /**
     * Render view
     */
    protected function view($path, $data = []) {
        $file = APP_ROOT . '/app/views/' . str_replace('.', '/', $path) . '.php';
        
        if (!file_exists($file)) {
            $this->response->status(404);
            Logger::error("View not found: $path");
            echo "View not found: $path";
            return;
        }
        
        // Add common data
        $data['user'] = $this->user;
        $data['csrf_token'] = Security::generateCSRFToken();
        $data['base_url'] = BASE_URL;
        $data['assets_url'] = ASSETS_URL;
        
        extract($data);
        ob_start();
        include $file;
        $content = ob_get_clean();
        
        $this->response->html($content);
    }
    
    /**
     * Validate input
     */
    protected function validate($data, $rules) {
        $validator = new Validator($data);
        
        if (!$validator->validate($rules)) {
            return $validator->errors();
        }
        
        return true;
    }
    
    /**
     * Log audit action
     */
    protected function auditLog($action, $module, $resourceType, $resourceId, $oldValues = null, $newValues = null) {
        $this->db->query('
            INSERT INTO audit_logs (user_id, action, module, resource_type, resource_id, old_values, new_values, ip_address, user_agent, created_at)
            VALUES (:user_id, :action, :module, :resource_type, :resource_id, :old_values, :new_values, :ip_address, :user_agent, NOW())
        ');
        
        $this->db->bind(':user_id', $_SESSION['user_id'] ?? null);
        $this->db->bind(':action', $action);
        $this->db->bind(':module', $module);
        $this->db->bind(':resource_type', $resourceType);
        $this->db->bind(':resource_id', $resourceId);
        $this->db->bind(':old_values', $oldValues ? json_encode($oldValues) : null);
        $this->db->bind(':new_values', $newValues ? json_encode($newValues) : null);
        $this->db->bind(':ip_address', $this->request->ip());
        $this->db->bind(':user_agent', $this->request->userAgent());
        
        return $this->db->execute();
    }
    
    /**
     * Create notification
     */
    protected function notify($userId, $type, $title, $message, $relatedType = null, $relatedId = null, $actionUrl = null) {
        $this->db->query('
            INSERT INTO notifications (user_id, notification_type, title, message, related_resource_type, related_resource_id, action_url, created_at)
            VALUES (:user_id, :type, :title, :message, :related_type, :related_id, :action_url, NOW())
        ');
        
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':type', $type);
        $this->db->bind(':title', $title);
        $this->db->bind(':message', $message);
        $this->db->bind(':related_type', $relatedType);
        $this->db->bind(':related_id', $relatedId);
        $this->db->bind(':action_url', $actionUrl);
        
        return $this->db->execute();
    }
}
