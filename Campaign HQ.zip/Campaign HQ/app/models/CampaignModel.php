<?php
/**
 * Campaign Model
 */

class CampaignModel extends Model {
    protected $table = 'campaigns';
    protected $fillable = [
        'name', 'campaign_type_id', 'subject', 'sender_name', 'sender_email',
        'template_id', 'audience_segment_filter', 'scheduled_date', 'scheduled_time',
        'status', 'notes'
    ];
    
    /**
     * Get campaigns with filters
     */
    public function getCampaignsWithFilters($page = 1, $limit = ITEMS_PER_PAGE, $filters = []) {
        $query = 'SELECT c.*, ct.name as type, et.name as template_name
                 FROM campaigns c
                 LEFT JOIN campaign_types ct ON c.campaign_type_id = ct.id
                 LEFT JOIN email_templates et ON c.template_id = et.id
                 WHERE 1=1';
        
        $params = [];
        
        // Apply filters
        if (!empty($filters['search'])) {
            $query .= ' AND (c.name LIKE :search OR c.subject LIKE :search)';
            $params['search'] = '%' . $filters['search'] . '%';
        }
        
        if (!empty($filters['status'])) {
            $query .= ' AND c.status = :status';
            $params['status'] = $filters['status'];
        }
        
        if (!empty($filters['campaign_type_id'])) {
            $query .= ' AND c.campaign_type_id = :campaign_type_id';
            $params['campaign_type_id'] = $filters['campaign_type_id'];
        }
        
        // Get total count
        $countQuery = str_replace('SELECT c.*,', 'SELECT COUNT(*) as total', $query);
        $this->db->query($countQuery);
        foreach ($params as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        $this->db->execute();
        $totalResult = $this->db->single();
        $total = $totalResult['total'];
        
        // Get paginated results
        $offset = ($page - 1) * $limit;
        $query .= ' ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset';
        
        $this->db->query($query);
        foreach ($params as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        
        $data = $this->db->resultSet();
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }
    
    /**
     * Get campaign with recipients
     */
    public function getCampaignWithRecipients($campaignId) {
        $this->db->query('SELECT * FROM campaigns WHERE id = :id');
        $this->db->bind(':id', $campaignId);
        $campaign = $this->db->single();
        
        if (!$campaign) {
            return null;
        }
        
        // Get recipients
        $this->db->query('
            SELECT cl.*, l.email, l.fullname
            FROM campaign_leads cl
            JOIN leads l ON cl.lead_id = l.id
            WHERE cl.campaign_id = :campaign_id
            ORDER BY cl.created_at DESC
        ');
        $this->db->bind(':campaign_id', $campaignId);
        $campaign['recipients'] = $this->db->resultSet();
        
        return $campaign;
    }
    
    /**
     * Get campaign analytics
     */
    public function getAnalytics($campaignId) {
        $this->db->query('
            SELECT
                COUNT(*) as total_recipients,
                SUM(CASE WHEN status IN ("delivered", "opened", "clicked") THEN 1 ELSE 0 END) as delivered,
                SUM(CASE WHEN status IN ("opened", "clicked") THEN 1 ELSE 0 END) as opened,
                SUM(CASE WHEN status = "clicked" THEN 1 ELSE 0 END) as clicked,
                SUM(CASE WHEN status = "bounced" THEN 1 ELSE 0 END) as bounced,
                SUM(CASE WHEN status = "unsubscribed" THEN 1 ELSE 0 END) as unsubscribed
            FROM campaign_leads
            WHERE campaign_id = :campaign_id
        ');
        $this->db->bind(':campaign_id', $campaignId);
        $result = $this->db->single();
        
        // Calculate rates
        $total = (int)$result['total_recipients'] ?: 1;
        
        return [
            'total_recipients' => $result['total_recipients'],
            'delivered' => $result['delivered'],
            'opened' => $result['opened'],
            'clicked' => $result['clicked'],
            'bounced' => $result['bounced'],
            'unsubscribed' => $result['unsubscribed'],
            'delivery_rate' => round(($result['delivered'] / $total) * 100, 2),
            'open_rate' => round(($result['opened'] / $total) * 100, 2),
            'click_rate' => round(($result['clicked'] / $total) * 100, 2),
            'bounce_rate' => round(($result['bounced'] / $total) * 100, 2),
            'unsubscribe_rate' => round(($result['unsubscribed'] / $total) * 100, 2)
        ];
    }
}
