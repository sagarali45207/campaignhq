<?php
/**
 * Email Template Model
 */

class EmailTemplateModel extends Model {
    protected $table = 'email_templates';
    protected $fillable = [
        'name', 'template_type', 'subject', 'body', 'variables', 'status'
    ];
    
    /**
     * Get all active templates
     */
    public function getActive() {
        $this->db->query('SELECT * FROM email_templates WHERE status = "active" ORDER BY name');
        return $this->db->resultSet();
    }
    
    /**
     * Get templates by type
     */
    public function getByType($type) {
        $this->db->query('
            SELECT * FROM email_templates
            WHERE template_type = :type AND status = "active"
            ORDER BY name
        ');
        $this->db->bind(':type', $type);
        return $this->db->resultSet();
    }
    
    /**
     * Get template with rendering
     */
    public function getForRender($id) {
        $template = $this->find($id);
        
        if (!$template) {
            return null;
        }
        
        return [
            'name' => $template['name'],
            'subject' => $template['subject'],
            'body' => $template['body'],
            'variables' => json_decode($template['variables'], true) ?? []
        ];
    }
    
    /**
     * Render template with variables
     */
    public function render($id, $variables = []) {
        $template = $this->getForRender($id);
        
        if (!$template) {
            return null;
        }
        
        $subject = $template['subject'];
        $body = $template['body'];
        
        // Replace variables
        foreach ($variables as $key => $value) {
            $placeholder = '{{' . $key . '}}';
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }
        
        return [
            'subject' => $subject,
            'body' => $body
        ];
    }
}
