<?php
/**
 * User Model
 */

class UserModel extends Model {
    protected $table = 'users';
    protected $fillable = ['fullname', 'email', 'password', 'role_id', 'status'];
    protected $hidden = ['password', 'remember_me_token', 'password_reset_token'];
    
    /**
     * Find user by email
     */
    public function findByEmail($email) {
        $this->db->query('SELECT * FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        return $this->db->single();
    }
    
    /**
     * Authenticate user
     */
    public function authenticate($email, $password) {
        $user = $this->findByEmail($email);
        
        if (!$user) {
            Logger::warning("Login attempt with non-existent email: $email");
            return false;
        }
        
        if ($user['status'] !== 'active') {
            Logger::warning("Login attempt with inactive user: $email");
            return false;
        }
        
        if (!Security::verifyPassword($password, $user['password'])) {
            Logger::warning("Failed login attempt for user: $email");
            return false;
        }
        
        // Update last login
        $this->db->query('UPDATE users SET last_login = NOW() WHERE id = :id');
        $this->db->bind(':id', $user['id']);
        $this->db->execute();
        
        Logger::info("User logged in: $email");
        
        return $user;
    }
    
    /**
     * Get user with permissions
     */
    public function getUserWithPermissions($userId) {
        $this->db->query('
            SELECT u.*, r.name as role_name, GROUP_CONCAT(p.name) as permissions
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN role_permissions rp ON r.id = rp.role_id
            LEFT JOIN permissions p ON rp.permission_id = p.id
            WHERE u.id = :id
            GROUP BY u.id
        ');
        $this->db->bind(':id', $userId);
        return $this->db->single();
    }
    
    /**
     * Create password reset token
     */
    public function createPasswordResetToken($email) {
        $user = $this->findByEmail($email);
        
        if (!$user) {
            return false;
        }
        
        $token = Security::generateToken();
        $expires = date('Y-m-d H:i:s', time() + 3600); // 1 hour
        
        $this->db->query('UPDATE users SET password_reset_token = :token, password_reset_expires = :expires WHERE id = :id');
        $this->db->bind(':token', Security::hash($token));
        $this->db->bind(':expires', $expires);
        $this->db->bind(':id', $user['id']);
        
        if ($this->db->execute()) {
            Logger::info("Password reset token created for user: $email");
            return $token; // Return unhashed token to send in email
        }
        
        return false;
    }
    
    /**
     * Verify password reset token
     */
    public function verifyPasswordResetToken($token) {
        $hashedToken = Security::hash($token);
        
        $this->db->query('
            SELECT id FROM users
            WHERE password_reset_token = :token
            AND password_reset_expires > NOW()
        ');
        $this->db->bind(':token', $hashedToken);
        $result = $this->db->single();
        
        return $result ? $result['id'] : false;
    }
    
    /**
     * Reset password
     */
    public function resetPassword($userId, $newPassword) {
        $hashedPassword = Security::hashPassword($newPassword);
        
        $this->db->query('
            UPDATE users
            SET password = :password,
                password_reset_token = NULL,
                password_reset_expires = NULL
            WHERE id = :id
        ');
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':id', $userId);
        
        if ($this->db->execute()) {
            Logger::info("Password reset for user ID: $userId");
            return true;
        }
        
        return false;
    }
    
    /**
     * Get all users with roles
     */
    public function getAllWithRoles() {
        $this->db->query('
            SELECT u.*, r.name as role_name
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            ORDER BY u.created_at DESC
        ');
        return $this->db->resultSet();
    }
}
