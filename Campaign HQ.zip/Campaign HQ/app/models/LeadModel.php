<?php
/**
 * Lead Model
 */

class LeadModel extends Model {
    protected $table = 'leads';
    protected $fillable = [
        'fullname', 'firstname', 'lastname', 'email', 'secondary_email',
        'company', 'job_title', 'department', 'phone', 'mobile',
        'country_id', 'state', 'city', 'industry_id', 'lead_source_id',
        'webinar_interest', 'lead_score', 'status_id', 'remarks'
    ];
    
    /**
     * Get leads with pagination
     */
    public function getLeadsWithFilters($page = 1, $limit = ITEMS_PER_PAGE, $filters = []) {
        $query = 'SELECT l.*, s.name as status, ls.name as source, i.name as industry, c.name as country
                 FROM leads l
                 LEFT JOIN lead_statuses s ON l.status_id = s.id
                 LEFT JOIN lead_sources ls ON l.lead_source_id = ls.id
                 LEFT JOIN industries i ON l.industry_id = i.id
                 LEFT JOIN countries c ON l.country_id = c.id
                 WHERE 1=1';
        
        $params = [];
        
        // Apply filters
        if (!empty($filters['search'])) {
            $query .= ' AND (l.fullname LIKE :search OR l.email LIKE :search OR l.company LIKE :search)';
            $params['search'] = '%' . $filters['search'] . '%';
        }
        
        if (!empty($filters['status_id'])) {
            $query .= ' AND l.status_id = :status_id';
            $params['status_id'] = $filters['status_id'];
        }
        
        if (!empty($filters['country_id'])) {
            $query .= ' AND l.country_id = :country_id';
            $params['country_id'] = $filters['country_id'];
        }
        
        if (!empty($filters['industry_id'])) {
            $query .= ' AND l.industry_id = :industry_id';
            $params['industry_id'] = $filters['industry_id'];
        }
        
        if (!empty($filters['lead_source_id'])) {
            $query .= ' AND l.lead_source_id = :lead_source_id';
            $params['lead_source_id'] = $filters['lead_source_id'];
        }
        
        if (!empty($filters['lead_score_min'])) {
            $query .= ' AND l.lead_score >= :lead_score_min';
            $params['lead_score_min'] = $filters['lead_score_min'];
        }
        
        if (!empty($filters['lead_score_max'])) {
            $query .= ' AND l.lead_score <= :lead_score_max';
            $params['lead_score_max'] = $filters['lead_score_max'];
        }
        
        // Get total count
        $countQuery = str_replace('SELECT l.*,', 'SELECT COUNT(*) as total', $query);
        $this->db->query($countQuery);
        foreach ($params as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        $this->db->execute();
        $totalResult = $this->db->single();
        $total = $totalResult['total'];
        
        // Get paginated results
        $offset = ($page - 1) * $limit;
        $query .= ' ORDER BY l.created_at DESC LIMIT :limit OFFSET :offset';
        
        $this->db->query($query);
        foreach ($params as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        
        $data = $this->db->resultSet();
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }
    
    /**
     * Check if email already exists
     */
    public function emailExists($email, $exceptId = null) {
        $query = 'SELECT id FROM leads WHERE email = :email';
        
        if ($exceptId) {
            $query .= ' AND id != :id';
        }
        
        $this->db->query($query);
        $this->db->bind(':email', $email);
        
        if ($exceptId) {
            $this->db->bind(':id', $exceptId);
        }
        
        return $this->db->single() ? true : false;
    }
    
    /**
     * Get lead with custom fields
     */
    public function getWithCustomFields($leadId) {
        $this->db->query('SELECT * FROM leads WHERE id = :id');
        $this->db->bind(':id', $leadId);
        $lead = $this->db->single();
        
        if (!$lead) {
            return null;
        }
        
        // Get custom field values
        $this->db->query('
            SELECT lcf.id, lcf.field_name, lcf.field_type, lcfv.field_value
            FROM lead_custom_field_values lcfv
            JOIN lead_custom_fields lcf ON lcfv.custom_field_id = lcf.id
            WHERE lcfv.lead_id = :id
        ');
        $this->db->bind(':id', $leadId);
        $customFields = $this->db->resultSet();
        
        $lead['custom_fields'] = $customFields;
        
        return $lead;
    }
    
    /**
     * Get lead tags
     */
    public function getTags($leadId) {
        $this->db->query('
            SELECT t.* FROM lead_tags t
            JOIN lead_lead_tags llt ON t.id = llt.tag_id
            WHERE llt.lead_id = :lead_id
        ');
        $this->db->bind(':lead_id', $leadId);
        return $this->db->resultSet();
    }
    
    /**
     * Add tags to lead
     */
    public function addTags($leadId, $tagIds) {
        foreach ($tagIds as $tagId) {
            $this->db->query('
                INSERT IGNORE INTO lead_lead_tags (lead_id, tag_id, created_at)
                VALUES (:lead_id, :tag_id, NOW())
            ');
            $this->db->bind(':lead_id', $leadId);
            $this->db->bind(':tag_id', $tagId);
            $this->db->execute();
        }
    }
    
    /**
     * Remove tags from lead
     */
    public function removeTags($leadId, $tagIds = null) {
        if ($tagIds === null) {
            $this->db->query('DELETE FROM lead_lead_tags WHERE lead_id = :lead_id');
            $this->db->bind(':lead_id', $leadId);
        } else {
            $placeholders = implode(',', array_fill(0, count($tagIds), '?'));
            $this->db->query("DELETE FROM lead_lead_tags WHERE lead_id = ? AND tag_id IN ($placeholders)");
            // Note: Using positional parameters with PDO
            $this->db->bind(1, $leadId);
            foreach ($tagIds as $index => $tagId) {
                $this->db->bind($index + 2, $tagId);
            }
        }
        return $this->db->execute();
    }
    
    /**
     * Get lead statistics
     */
    public function getStatistics() {
        $this->db->query('
            SELECT
                COUNT(*) as total_leads,
                SUM(CASE WHEN status_id = 1 THEN 1 ELSE 0 END) as new_leads,
                SUM(CASE WHEN status_id IN (7) THEN 1 ELSE 0 END) as won_leads,
                SUM(CASE WHEN status_id IN (8) THEN 1 ELSE 0 END) as lost_leads,
                SUM(CASE WHEN status_id = 9 THEN 1 ELSE 0 END) as unsubscribed_leads,
                AVG(lead_score) as avg_lead_score
            FROM leads
        ');
        $this->db->execute();
        return $this->db->single();
    }
}
