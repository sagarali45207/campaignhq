<?php
// Email Templates list view
$title = $title ?? 'Email Templates';
$breadcrumbs = $breadcrumbs ?? [];
?>

<?php view('layout', ['title' => $title, 'breadcrumbs' => $breadcrumbs]) ?>

<div class="container-fluid mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Email Templates</h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="/templates/create" class="btn btn-primary">
                <i class="fas fa-plus"></i> New Template
            </a>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <input type="text" id="searchFilter" class="form-control" placeholder="Search templates...">
                </div>
                <div class="col-md-3">
                    <select id="typeFilter" class="form-select">
                        <option value="">All Types</option>
                        <option value="webinar_invite">Webinar Invite</option>
                        <option value="reminder">Reminder</option>
                        <option value="follow_up">Follow Up</option>
                        <option value="thank_you">Thank You</option>
                        <option value="nurture">Nurture</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-outline-secondary w-100" onclick="clearFilters()">
                        <i class="fas fa-times"></i> Clear
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Templates Grid -->
    <div class="row" id="templatesGrid">
        <div class="col-12 text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    loadTemplates();
    
    $('#searchFilter').on('keyup', debounce(loadTemplates, 300));
    $('#typeFilter').on('change', loadTemplates);
});

function loadTemplates(page = 1) {
    const search = $('#searchFilter').val();
    const type = $('#typeFilter').val();
    
    $.ajax({
        url: '/api/templates',
        method: 'GET',
        data: {
            page: page,
            search: search,
            type: type
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                renderTemplates(response.data);
            }
        }
    });
}

function renderTemplates(templates) {
    const grid = $('#templatesGrid');
    
    if (templates.length === 0) {
        grid.html(`
            <div class="col-12 text-center py-5">
                <i class="fas fa-envelope text-muted" style="font-size: 2rem;"></i>
                <p class="text-muted mt-2">No templates found</p>
            </div>
        `);
        return;
    }
    
    const cards = templates.map(template => `
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100 template-card hover-shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title mb-1">${escapeHtml(template.name)}</h5>
                            <small class="badge bg-info">${getTypeLabel(template.template_type)}</small>
                        </div>
                        <div class="btn-group btn-group-sm" role="group">
                            <button class="btn btn-outline-secondary" onclick="previewTemplate(${template.id})" title="Preview">
                                <i class="fas fa-eye"></i>
                            </button>
                            <a href="/templates/${template.id}/edit" class="btn btn-outline-secondary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button class="btn btn-outline-danger" onclick="deleteTemplate(${template.id})" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    
                    <p class="card-text small text-muted">
                        <strong>Subject:</strong><br>
                        ${escapeHtml(template.subject.substring(0, 60))}...
                    </p>
                    
                    <div class="mt-3 pt-3 border-top">
                        <small class="text-muted">
                            Created: ${formatDate(template.created_at)}
                        </small>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
    
    grid.html(cards);
}

function previewTemplate(id) {
    $.ajax({
        url: '/api/templates/' + id + '/preview',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const data = response.data;
                const modal = `
                    <div class="modal fade" id="previewModal" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Template Preview</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <h6 class="text-muted">Subject:</h6>
                                        <p class="mb-0">${escapeHtml(data.subject)}</p>
                                    </div>
                                    <hr>
                                    <div>
                                        <h6 class="text-muted">Body:</h6>
                                        <div class="template-preview">${data.body}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // Remove existing modal if any
                $('#previewModal').remove();
                $('body').append(modal);
                
                const previewModal = new bootstrap.Modal(document.getElementById('previewModal'));
                previewModal.show();
            }
        }
    });
}

function deleteTemplate(id) {
    if (!confirm('Are you sure you want to delete this template?')) return;
    
    $.ajax({
        url: '/api/templates/' + id,
        method: 'DELETE',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                CampaignHQ.showSuccess('Template deleted successfully');
                loadTemplates();
            }
        }
    });
}

function clearFilters() {
    $('#searchFilter').val('');
    $('#typeFilter').val('');
    loadTemplates();
}

function getTypeLabel(type) {
    const labels = {
        'webinar_invite': 'Webinar Invite',
        'reminder': 'Reminder',
        'follow_up': 'Follow Up',
        'thank_you': 'Thank You',
        'nurture': 'Nurture'
    };
    return labels[type] || type;
}

function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add CSS for template preview
const style = document.createElement('style');
style.textContent = `
    .template-card {
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .template-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }
    
    .template-preview {
        background: #f8f9fa;
        border-radius: 4px;
        padding: 16px;
        border: 1px solid #dee2e6;
        max-height: 400px;
        overflow-y: auto;
    }
`;
document.head.appendChild(style);
</script>
