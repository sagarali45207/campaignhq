<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(APP_NAME); ?> - Marketing Automation Platform</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="<?php echo e($assets_url); ?>/css/main.css" rel="stylesheet">
    <link href="<?php echo e($assets_url); ?>/css/theme-dark.css" rel="stylesheet">
</head>
<body>
    <div id="app" class="d-flex min-vh-100">
        <!-- Sidebar Navigation -->
        <nav class="sidebar bg-dark" id="sidebar">
            <div class="sidebar-header">
                <h3 class="mb-0">
                    <i class="fas fa-rocket"></i> <?php echo e(APP_NAME); ?>
                </h3>
            </div>
            
            <div class="nav-menu">
                <a href="<?php echo e($base_url); ?>/dashboard" class="nav-link active">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/leads" class="nav-link">
                    <i class="fas fa-users"></i> <span>Leads</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/campaigns" class="nav-link">
                    <i class="fas fa-envelope"></i> <span>Campaigns</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/templates" class="nav-link">
                    <i class="fas fa-file-alt"></i> <span>Templates</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/followups" class="nav-link">
                    <i class="fas fa-tasks"></i> <span>Follow-ups</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/analytics" class="nav-link">
                    <i class="fas fa-bar-chart"></i> <span>Analytics</span>
                </a>
                
                <?php if ($user['role'] === 'admin'): ?>
                <hr class="my-3">
                <a href="<?php echo e($base_url); ?>/users" class="nav-link">
                    <i class="fas fa-user-tie"></i> <span>Users</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/settings" class="nav-link">
                    <i class="fas fa-cog"></i> <span>Settings</span>
                </a>
                
                <a href="<?php echo e($base_url); ?>/audit-logs" class="nav-link">
                    <i class="fas fa-history"></i> <span>Audit Logs</span>
                </a>
                <?php endif; ?>
            </div>
        </nav>
        
        <!-- Main Content -->
        <div class="main-content flex-grow-1">
            <!-- Top Bar -->
            <header class="topbar bg-dark border-bottom border-secondary">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center py-3">
                        <button class="btn btn-sm btn-outline-light" id="sidebarToggle">
                            <i class="fas fa-bars"></i>
                        </button>
                        
                        <div class="d-flex align-items-center gap-3">
                            <!-- Notifications -->
                            <div class="dropdown">
                                <button class="btn btn-link text-light position-relative" id="notificationDropdown" data-bs-toggle="dropdown">
                                    <i class="fas fa-bell"></i>
                                    <span class="badge bg-danger position-absolute top-0 start-100 translate-middle" id="notificationCount">0</span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end" id="notificationMenu">
                                    <!-- Loaded via JS -->
                                </div>
                            </div>
                            
                            <!-- User Profile -->
                            <div class="dropdown">
                                <button class="btn btn-link text-light d-flex align-items-center gap-2" id="userDropdown" data-bs-toggle="dropdown">
                                    <img src="<?php echo e(getGravatarUrl($user['email'])); ?>" alt="<?php echo e($user['fullname']); ?>" class="rounded-circle" width="32" height="32">
                                    <span><?php echo e($user['fullname']); ?></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="<?php echo e($base_url); ?>/profile">
                                        <i class="fas fa-user"></i> Profile
                                    </a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?php echo e($base_url); ?>/logout">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Content Area -->
            <main class="content-area p-4">
                <?php if (isset($error) && $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle"></i> <?php echo e($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <?php if (isset($message) && $message): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <i class="fas fa-info-circle"></i> <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <!-- Page Content -->
                <?php echo $content ?? ''; ?>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo e($assets_url); ?>/js/app.js"></script>
</body>
</html>
