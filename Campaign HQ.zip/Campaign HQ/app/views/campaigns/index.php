<?php
// Campaigns list view
$title = $title ?? 'Campaigns';
$breadcrumbs = $breadcrumbs ?? [];
?>

<?php view('layout', ['title' => $title, 'breadcrumbs' => $breadcrumbs]) ?>

<div class="container-fluid mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Campaigns</h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="/campaigns/create" class="btn btn-primary">
                <i class="fas fa-plus"></i> New Campaign
            </a>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <input type="text" id="searchFilter" class="form-control" placeholder="Search campaigns...">
                </div>
                <div class="col-md-3">
                    <select id="statusFilter" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="draft">Draft</option>
                        <option value="scheduled">Scheduled</option>
                        <option value="sending">Sending</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-outline-secondary w-100" onclick="clearFilters()">
                        <i class="fas fa-times"></i> Clear
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Campaigns Table -->
    <div class="card">
        <div class="table-responsive">
            <table id="campaignsTable" class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Recipients</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody id="campaignsBody">
                    <tr>
                        <td colspan="7" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    loadCampaigns();
    
    $('#searchFilter').on('keyup', debounce(loadCampaigns, 300));
    $('#statusFilter').on('change', loadCampaigns);
});

function loadCampaigns(page = 1) {
    const search = $('#searchFilter').val();
    const status = $('#statusFilter').val();
    
    $.ajax({
        url: '/api/campaigns',
        method: 'GET',
        data: {
            page: page,
            search: search,
            status: status
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                renderCampaigns(response.data);
            }
        }
    });
}

function renderCampaigns(campaigns) {
    const tbody = $('#campaignsBody');
    
    if (campaigns.length === 0) {
        tbody.html(`
            <tr>
                <td colspan="7" class="text-center py-4">
                    <i class="fas fa-inbox text-muted" style="font-size: 2rem;"></i>
                    <p class="text-muted mt-2">No campaigns found</p>
                </td>
            </tr>
        `);
        return;
    }
    
    const rows = campaigns.map(campaign => `
        <tr>
            <td class="fw-bold">${escapeHtml(campaign.name)}</td>
            <td><span class="badge bg-info">${campaign.type || 'N/A'}</span></td>
            <td>${escapeHtml(campaign.subject.substring(0, 50))}</td>
            <td><span class="badge bg-secondary">${campaign.recipient_count || 0}</span></td>
            <td>
                <span class="badge bg-${getStatusBadgeColor(campaign.status)}">
                    ${campaign.status}
                </span>
            </td>
            <td><small>${formatDate(campaign.created_at)}</small></td>
            <td class="text-end">
                <div class="btn-group btn-group-sm" role="group">
                    <a href="/campaigns/${campaign.id}" class="btn btn-outline-primary" title="View">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="/campaigns/${campaign.id}/edit" class="btn btn-outline-secondary" title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>
                    <button class="btn btn-outline-danger" onclick="deleteCampaign(${campaign.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
    
    tbody.html(rows);
}

function deleteCampaign(id) {
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    
    $.ajax({
        url: '/api/campaigns/' + id,
        method: 'DELETE',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                CampaignHQ.showSuccess('Campaign deleted successfully');
                loadCampaigns();
            }
        }
    });
}

function clearFilters() {
    $('#searchFilter').val('');
    $('#statusFilter').val('');
    loadCampaigns();
}

function getStatusBadgeColor(status) {
    const colors = {
        'draft': 'secondary',
        'scheduled': 'info',
        'sending': 'warning',
        'completed': 'success'
    };
    return colors[status] || 'secondary';
}

function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
</script>
