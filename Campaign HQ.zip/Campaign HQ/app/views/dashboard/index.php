<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-chart-line"></i> Dashboard</h1>
        <div>
            <button class="btn btn-outline-primary" id="refreshBtn">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>
    
    <!-- Statistics Cards Row -->
    <div class="row mb-4" id="statsContainer">
        <!-- Loaded via JavaScript -->
        <div class="col-12 text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div class="row mb-4">
        <div class="col-lg-6 mb-4">
            <div class="card bg-secondary border-0 h-100">
                <div class="card-header bg-dark border-bottom border-secondary">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-pie"></i> Lead Sources Distribution
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="leadSourcesChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6 mb-4">
            <div class="card bg-secondary border-0 h-100">
                <div class="card-header bg-dark border-bottom border-secondary">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-pie"></i> Lead Status Distribution
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="leadStatusChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-lg-12 mb-4">
            <div class="card bg-secondary border-0">
                <div class="card-header bg-dark border-bottom border-secondary">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-line"></i> Email Performance (Last 30 Days)
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="emailMetricsChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card bg-secondary border-0">
                <div class="card-header bg-dark border-bottom border-secondary">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-globe"></i> Top Countries by Leads
                    </h5>
                </div>
                <div class="card-body">
                    <canvas id="topCountriesChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .stat-card {
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
        border-left: 4px solid;
        border-radius: 10px;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }
    
    .stat-number {
        font-size: 2.5rem;
        font-weight: bold;
        background: linear-gradient(135deg, #667eea, #764ba2);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .stat-label {
        font-size: 0.9rem;
        color: #999;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
</style>

<script>
$(document).ready(function() {
    const baseUrl = '<?php echo e($base_url); ?>';
    let charts = {};
    
    // Load dashboard data
    function loadDashboard() {
        // Load statistics
        $.ajax({
            url: baseUrl + '/api/dashboard/stats',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderStats(response.data);
                }
            }
        });
        
        // Load charts
        $.ajax({
            url: baseUrl + '/api/dashboard/charts?type=all',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderCharts(response.data);
                }
            }
        });
    }
    
    function renderStats(stats) {
        let html = '';
        
        // Lead cards
        html += `
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #667eea;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.leads.total}</div>
                        <div class="stat-label">Total Leads</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #00cc99;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.leads.won}</div>
                        <div class="stat-label">Won Leads</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #ff6600;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.campaigns.sent}</div>
                        <div class="stat-label">Campaigns Sent</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #00dd88;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.campaigns.open_rate.toFixed(1)}%</div>
                        <div class="stat-label">Open Rate</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #6633ff;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.campaigns.click_rate.toFixed(1)}%</div>
                        <div class="stat-label">Click Rate</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-3">
                <div class="card stat-card bg-secondary border-0" style="border-left-color: #ff0000;">
                    <div class="card-body text-center">
                        <div class="stat-number">${stats.followups.pending}</div>
                        <div class="stat-label">Pending Follow-ups</div>
                    </div>
                </div>
            </div>
        `;
        
        $('#statsContainer').html(html);
    }
    
    function renderCharts(data) {
        // Lead sources chart
        if (data.lead_sources && data.lead_sources.length > 0) {
            const ctx1 = document.getElementById('leadSourcesChart');
            if (ctx1) {
                charts.leadSources = new Chart(ctx1, {
                    type: 'doughnut',
                    data: {
                        labels: data.lead_sources.map(item => item.name || 'Unknown'),
                        datasets: [{
                            data: data.lead_sources.map(item => item.count),
                            backgroundColor: [
                                '#667eea',
                                '#764ba2',
                                '#f093fb',
                                '#4facfe',
                                '#00f2fe',
                                '#43e97b',
                                '#fa709a',
                                '#fee140'
                            ],
                            borderColor: '#222',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: { color: '#fff' }
                            }
                        }
                    }
                });
            }
        }
        
        // Lead status chart
        if (data.lead_status && data.lead_status.length > 0) {
            const ctx2 = document.getElementById('leadStatusChart');
            if (ctx2) {
                charts.leadStatus = new Chart(ctx2, {
                    type: 'pie',
                    data: {
                        labels: data.lead_status.map(item => item.name || 'Unknown'),
                        datasets: [{
                            data: data.lead_status.map(item => item.count),
                            backgroundColor: [
                                '#0066ff',
                                '#00cc99',
                                '#ffaa00',
                                '#00dd88',
                                '#6633ff',
                                '#ff6600',
                                '#00ff00',
                                '#ff0000'
                            ],
                            borderColor: '#222',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: { color: '#fff' }
                            }
                        }
                    }
                });
            }
        }
        
        // Email metrics chart
        if (data.email_metrics && data.email_metrics.length > 0) {
            const ctx3 = document.getElementById('emailMetricsChart');
            if (ctx3) {
                charts.emailMetrics = new Chart(ctx3, {
                    type: 'line',
                    data: {
                        labels: data.email_metrics.map(item => item.date),
                        datasets: [
                            {
                                label: 'Sent',
                                data: data.email_metrics.map(item => item.sent || 0),
                                borderColor: '#667eea',
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                tension: 0.4
                            },
                            {
                                label: 'Delivered',
                                data: data.email_metrics.map(item => item.delivered || 0),
                                borderColor: '#00cc99',
                                backgroundColor: 'rgba(0, 204, 153, 0.1)',
                                tension: 0.4
                            },
                            {
                                label: 'Opened',
                                data: data.email_metrics.map(item => item.opened || 0),
                                borderColor: '#ffaa00',
                                backgroundColor: 'rgba(255, 170, 0, 0.1)',
                                tension: 0.4
                            },
                            {
                                label: 'Clicked',
                                data: data.email_metrics.map(item => item.clicked || 0),
                                borderColor: '#00dd88',
                                backgroundColor: 'rgba(0, 221, 136, 0.1)',
                                tension: 0.4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: { color: '#fff' }
                            }
                        },
                        scales: {
                            y: {
                                ticks: { color: '#999' },
                                grid: { color: 'rgba(255, 255, 255, 0.1)' }
                            },
                            x: {
                                ticks: { color: '#999' },
                                grid: { color: 'rgba(255, 255, 255, 0.1)' }
                            }
                        }
                    }
                });
            }
        }
        
        // Top countries chart
        if (data.top_countries && data.top_countries.length > 0) {
            const ctx4 = document.getElementById('topCountriesChart');
            if (ctx4) {
                charts.topCountries = new Chart(ctx4, {
                    type: 'bar',
                    data: {
                        labels: data.top_countries.map(item => item.name || 'Unknown'),
                        datasets: [{
                            label: 'Leads',
                            data: data.top_countries.map(item => item.count),
                            backgroundColor: 'rgba(102, 126, 234, 0.8)',
                            borderColor: '#667eea',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: { color: '#fff' }
                            }
                        },
                        scales: {
                            y: {
                                ticks: { color: '#fff' },
                                grid: { color: 'rgba(255, 255, 255, 0.1)' }
                            },
                            x: {
                                ticks: { color: '#999' },
                                grid: { color: 'rgba(255, 255, 255, 0.1)' }
                            }
                        }
                    }
                });
            }
        }
    }
    
    // Initial load
    loadDashboard();
    
    // Refresh button
    $('#refreshBtn').on('click', function() {
        $(this).find('i').addClass('fa-spin');
        loadDashboard();
        setTimeout(() => {
            $('#refreshBtn').find('i').removeClass('fa-spin');
        }, 1000);
    });
    
    // Auto-refresh every 5 minutes
    setInterval(loadDashboard, 300000);
});
</script>
