<?php
/**
 * CampaignHQ - Main Application Entry Point
 * PHP 8.3+
 */

// Load configuration
require_once __DIR__ . '/config/config.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize request and response
$request = new Request();
$response = new Response();

// Initialize router
$router = new Router();

// =====================================================
// PUBLIC ROUTES (No Auth Required)
// =====================================================

// Authentication Routes
$router->get('/login', 'auth@login');
$router->post('/login', 'auth@handleLogin');
$router->get('/forgot-password', 'auth@forgotPassword');
$router->post('/forgot-password', 'auth@handleForgotPassword');
$router->get('/reset-password', 'auth@resetPassword');
$router->post('/reset-password', 'auth@handleResetPassword');
$router->get('/auth/status', 'auth@status');
$router->get('/logout', 'auth@logout');

// Error pages
$router->get('/error/403', function($req, $res) {
    $res->status(403);
    include APP_ROOT . '/app/views/errors/403.php';
});

$router->get('/error/404', function($req, $res) {
    $res->status(404);
    include APP_ROOT . '/app/views/errors/404.php';
});

// =====================================================
// PROTECTED ROUTES (Auth Required)
// =====================================================

// Create middleware for auth protection
$authMiddleware = ['CampaignHQ\\Middleware\\AuthMiddleware', 'handle'];
$rbacMiddleware = ['CampaignHQ\\Middleware\\RBACMiddleware', 'handle'];

// Dashboard
$router->get('/dashboard', 'dashboard@index', [$authMiddleware]);
$router->get('/api/dashboard/stats', 'dashboard@getStats', [$authMiddleware]);
$router->get('/api/dashboard/charts', 'dashboard@getCharts', [$authMiddleware]);

// Lead Management
$router->get('/leads', 'leads@index', [$authMiddleware]);
$router->get('/api/leads', 'leads@getLeads', [$authMiddleware]);
$router->post('/api/leads', 'leads@store', [$authMiddleware]);
$router->get('/api/leads/:id', 'leads@show', [$authMiddleware]);
$router->put('/api/leads/:id', 'leads@update', [$authMiddleware]);
$router->delete('/api/leads/:id', 'leads@delete', [$authMiddleware]);
$router->get('/leads/import', 'leads@importForm', [$authMiddleware]);
$router->post('/leads/import', 'leads@handleImport', [$authMiddleware]);
$router->post('/api/leads/bulk-action', 'leads@bulkAction', [$authMiddleware]);
$router->get('/api/leads/export/:format', 'leads@export', [$authMiddleware]);

// Lead Notes and Remarks
$router->post('/api/leads/:id/notes', 'leads@addNote', [$authMiddleware]);
$router->get('/api/leads/:id/notes', 'leads@getNotes', [$authMiddleware]);
$router->post('/api/leads/:id/timeline', 'leads@getTimeline', [$authMiddleware]);

// Campaigns
$router->get('/campaigns', 'campaigns@index', [$authMiddleware]);
$router->get('/campaigns/create', 'campaigns@create', [$authMiddleware]);
$router->get('/campaigns/:id', 'campaigns@show', [$authMiddleware]);
$router->get('/campaigns/:id/edit', 'campaigns@edit', [$authMiddleware]);
$router->get('/campaigns/:id/recipients', 'campaigns@selectRecipients', [$authMiddleware]);
$router->get('/campaigns/:id/send', 'campaigns@showSend', [$authMiddleware]);
$router->get('/api/campaigns', 'campaigns@getCampaigns', [$authMiddleware]);
$router->post('/api/campaigns', 'campaigns@store', [$authMiddleware]);
$router->get('/api/campaigns/:id', 'campaigns@getCampaign', [$authMiddleware]);
$router->put('/api/campaigns/:id', 'campaigns@update', [$authMiddleware]);
$router->delete('/api/campaigns/:id', 'campaigns@delete', [$authMiddleware]);
$router->post('/api/campaigns/:id/recipients', 'campaigns@saveRecipients', [$authMiddleware]);
$router->post('/api/campaigns/:id/send', 'campaigns@send', [$authMiddleware]);
$router->get('/api/campaigns/:id/analytics', 'campaigns@getAnalytics', [$authMiddleware]);

// Email Templates
$router->get('/templates', 'templates@index', [$authMiddleware]);
$router->get('/templates/create', 'templates@create', [$authMiddleware]);
$router->get('/templates/:id/edit', 'templates@edit', [$authMiddleware]);
$router->get('/api/templates', 'templates@getTemplates', [$authMiddleware]);
$router->post('/api/templates', 'templates@store', [$authMiddleware]);
$router->get('/api/templates/:id', 'templates@show', [$authMiddleware]);
$router->get('/api/templates/:id/preview', 'templates@preview', [$authMiddleware]);
$router->put('/api/templates/:id', 'templates@update', [$authMiddleware]);
$router->delete('/api/templates/:id', 'templates@delete', [$authMiddleware]);

// Follow-ups
$router->get('/followups', 'followups@index', [$authMiddleware]);
$router->get('/api/followups', 'followups@getFollowups', [$authMiddleware]);
$router->post('/api/followups', 'followups@store', [$authMiddleware]);
$router->put('/api/followups/:id', 'followups@update', [$authMiddleware]);
$router->delete('/api/followups/:id', 'followups@delete', [$authMiddleware]);

// Analytics
$router->get('/analytics', 'analytics@index', [$authMiddleware]);
$router->get('/api/analytics/campaign/:id', 'analytics@campaignAnalytics', [$authMiddleware]);
$router->get('/api/analytics/leads', 'analytics@leadAnalytics', [$authMiddleware]);
$router->get('/api/analytics/email-performance', 'analytics@emailPerformance', [$authMiddleware]);

// Settings (Admin only)
$router->get('/settings', 'settings@index', [$authMiddleware, $rbacMiddleware]);
$router->post('/api/settings', 'settings@updateSettings', [$authMiddleware, $rbacMiddleware]);
$router->post('/api/settings/sendgrid', 'settings@updateSendGrid', [$authMiddleware, $rbacMiddleware]);

// User Management (Admin only)
$router->get('/users', 'users@index', [$authMiddleware, $rbacMiddleware]);
$router->get('/api/users', 'users@getUsers', [$authMiddleware, $rbacMiddleware]);
$router->post('/api/users', 'users@store', [$authMiddleware, $rbacMiddleware]);
$router->get('/api/users/:id', 'users@show', [$authMiddleware, $rbacMiddleware]);
$router->put('/api/users/:id', 'users@update', [$authMiddleware, $rbacMiddleware]);
$router->delete('/api/users/:id', 'users@delete', [$authMiddleware, $rbacMiddleware]);

// Audit Logs (Admin only)
$router->get('/audit-logs', 'auditLogs@index', [$authMiddleware, $rbacMiddleware]);
$router->get('/api/audit-logs', 'auditLogs@getLogs', [$authMiddleware, $rbacMiddleware]);

// Notifications
$router->get('/api/notifications', 'notifications@getNotifications', [$authMiddleware]);
$router->post('/api/notifications/:id/read', 'notifications@markAsRead', [$authMiddleware]);

// Profile
$router->get('/profile', 'profile@index', [$authMiddleware]);
$router->put('/api/profile', 'profile@update', [$authMiddleware]);
$router->post('/api/profile/change-password', 'profile@changePassword', [$authMiddleware]);

// Home/Root
$router->get('/', function($req, $res) {
    if (isset($_SESSION['user_id'])) {
        $res->redirect(BASE_URL . '/dashboard');
    } else {
        $res->redirect(BASE_URL . '/login');
    }
});

// =====================================================
// DISPATCH REQUEST
// =====================================================

$method = $request->method();
$path = $request->path();

try {
    // Apply global middleware
    LoggingMiddleware::handle($request, $response);
    CORSMiddleware::handle($request, $response);
    
    // Dispatch to router
    $router->dispatch($method, $path, $request, $response);
} catch (Exception $e) {
    Logger::error("Request failed: " . $e->getMessage());
    
    if (APP_DEBUG) {
        $response->error('Error: ' . $e->getMessage(), null, 500);
    } else {
        $response->error('An error occurred', null, 500);
    }
}
