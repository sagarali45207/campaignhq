<?php
/**
 * Database Class
 * Handles all database operations using PDO
 */

class Database {
    private static $instance = null;
    private $pdo;
    private $statement;
    
    private function __construct() {
        $this->connect();
    }
    
    /**
     * Get database instance (Singleton)
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Connect to database
     */
    private function connect() {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_PERSISTENT => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
            Logger::info('Database connection established');
        } catch (PDOException $e) {
            Logger::error('Database connection failed: ' . $e->getMessage());
            throw new Exception('Unable to connect to database: ' . $e->getMessage());
        }
    }
    
    /**
     * Execute a query with prepared statements
     */
    public function query($sql) {
        try {
            $this->statement = $this->pdo->prepare($sql);
            return $this;
        } catch (PDOException $e) {
            Logger::error('Query preparation failed: ' . $e->getMessage());
            throw new Exception('Query failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Bind values to prepared statement
     */
    public function bind($param, $value, $type = null) {
        if (is_null($type)) {
            $type = match (true) {
                is_int($value) => PDO::PARAM_INT,
                is_bool($value) => PDO::PARAM_BOOL,
                is_null($value) => PDO::PARAM_NULL,
                default => PDO::PARAM_STR
            };
        }
        
        $this->statement->bindValue($param, $value, $type);
        return $this;
    }
    
    /**
     * Execute prepared statement
     */
    public function execute() {
        try {
            return $this->statement->execute();
        } catch (PDOException $e) {
            Logger::error('Query execution failed: ' . $e->getMessage());
            throw new Exception('Query execution failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Get single row result
     */
    public function single() {
        $this->execute();
        return $this->statement->fetch();
    }
    
    /**
     * Get all results
     */
    public function resultSet() {
        $this->execute();
        return $this->statement->fetchAll();
    }
    
    /**
     * Get row count
     */
    public function rowCount() {
        return $this->statement->rowCount();
    }
    
    /**
     * Get last inserted ID
     */
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }
    
    /**
     * Begin transaction
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    public function commit() {
        return $this->pdo->commit();
    }
    
    /**
     * Rollback transaction
     */
    public function rollBack() {
        return $this->pdo->rollBack();
    }
    
    /**
     * Test database connection
     */
    public static function testConnection() {
        try {
            $db = self::getInstance();
            $db->query('SELECT 1');
            $db->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Close connection
     */
    public function close() {
        $this->pdo = null;
        self::$instance = null;
    }
}
