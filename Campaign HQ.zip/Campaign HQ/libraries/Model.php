<?php
/**
 * Base Model Class
 */

class Model {
    protected $db;
    protected $table;
    protected $fillable = [];
    protected $hidden = [];
    protected $casts = [];
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Find by ID
     */
    public function find($id) {
        $this->db->query("SELECT * FROM {$this->table} WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }
    
    /**
     * Get all
     */
    public function all() {
        $this->db->query("SELECT * FROM {$this->table}");
        return $this->db->resultSet();
    }
    
    /**
     * Get with pagination
     */
    public function paginate($page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        
        // Get total count
        $this->db->query("SELECT COUNT(*) as total FROM {$this->table}");
        $this->db->execute();
        $totalResult = $this->db->single();
        $total = $totalResult['total'];
        
        // Get paginated results
        $this->db->query("SELECT * FROM {$this->table} LIMIT :limit OFFSET :offset");
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        $data = $this->db->resultSet();
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }
    
    /**
     * Create new record
     */
    public function create($data) {
        $data = $this->filterFillable($data);
        $data['created_at'] = date(DATETIME_FORMAT);
        
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $query = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        
        $this->db->query($query);
        
        foreach ($data as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        
        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }
        
        return false;
    }
    
    /**
     * Update record
     */
    public function update($id, $data) {
        $data = $this->filterFillable($data);
        $data['updated_at'] = date(DATETIME_FORMAT);
        
        $setClause = implode(', ', array_map(fn($key) => "$key = :$key", array_keys($data)));
        
        $query = "UPDATE {$this->table} SET {$setClause} WHERE id = :id";
        
        $this->db->query($query);
        
        foreach ($data as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        
        $this->db->bind(':id', $id);
        
        return $this->db->execute();
    }
    
    /**
     * Delete record
     */
    public function delete($id) {
        $this->db->query("DELETE FROM {$this->table} WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }
    
    /**
     * Where clause
     */
    public function where($column, $operator = '=', $value = null) {
        if ($value === null) {
            $value = $operator;
            $operator = '=';
        }
        
        $query = "SELECT * FROM {$this->table} WHERE {$column} {$operator} :value";
        $this->db->query($query);
        $this->db->bind(':value', $value);
        
        return $this->db->single();
    }
    
    /**
     * Filter fillable fields
     */
    protected function filterFillable($data) {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_filter($data, fn($key) => in_array($key, $this->fillable), ARRAY_FILTER_USE_KEY);
    }
    
    /**
     * Count records
     */
    public function count() {
        $this->db->query("SELECT COUNT(*) as total FROM {$this->table}");
        $this->db->execute();
        $result = $this->db->single();
        return $result['total'];
    }
}
