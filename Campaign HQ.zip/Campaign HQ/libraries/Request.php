<?php
/**
 * Request Class
 * Handles HTTP request data
 */

class Request {
    private $get;
    private $post;
    private $request;
    private $headers;
    private $files;
    
    public function __construct() {
        $this->get = $_GET;
        $this->post = $_POST;
        $this->request = $_REQUEST;
        $this->headers = getallheaders();
        $this->files = $_FILES;
    }
    
    /**
     * Get GET parameter
     */
    public function get($key = null, $default = null) {
        if ($key === null) {
            return $this->get;
        }
        
        return $this->get[$key] ?? $default;
    }
    
    /**
     * Get POST parameter
     */
    public function post($key = null, $default = null) {
        if ($key === null) {
            return $this->post;
        }
        
        return $this->post[$key] ?? $default;
    }
    
    /**
     * Get REQUEST parameter
     */
    public function input($key = null, $default = null) {
        if ($key === null) {
            return $this->request;
        }
        
        return $this->request[$key] ?? $default;
    }
    
    /**
     * Get JSON input
     */
    public function json() {
        $input = file_get_contents('php://input');
        return json_decode($input, true);
    }
    
    /**
     * Get header
     */
    public function header($key = null) {
        if ($key === null) {
            return $this->headers;
        }
        
        return $this->headers[$key] ?? null;
    }
    
    /**
     * Get uploaded file
     */
    public function file($key = null) {
        if ($key === null) {
            return $this->files;
        }
        
        return $this->files[$key] ?? null;
    }
    
    /**
     * Get request method
     */
    public function method() {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    /**
     * Check if request method is POST
     */
    public function isPost() {
        return $this->method() === 'POST';
    }
    
    /**
     * Check if request method is GET
     */
    public function isGet() {
        return $this->method() === 'GET';
    }
    
    /**
     * Check if request is AJAX
     */
    public function isAjax() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Get request path
     */
    public function path() {
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        return trim(str_replace('/campaignhq', '', $path), '/');
    }
    
    /**
     * Get client IP
     */
    public function ip() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($ips[0]);
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
    
    /**
     * Get user agent
     */
    public function userAgent() {
        return $_SERVER['HTTP_USER_AGENT'] ?? '';
    }
}

/**
 * Response Class
 * Handles HTTP responses
 */

class Response {
    private $statusCode = 200;
    private $headers = [];
    private $body = '';
    
    /**
     * Set status code
     */
    public function status($code) {
        $this->statusCode = $code;
        http_response_code($code);
        return $this;
    }
    
    /**
     * Set header
     */
    public function header($name, $value) {
        $this->headers[$name] = $value;
        header("$name: $value");
        return $this;
    }
    
    /**
     * Send JSON response
     */
    public function json($data, $statusCode = 200) {
        $this->status($statusCode);
        $this->header('Content-Type', 'application/json');
        
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * Send success response
     */
    public function success($message, $data = null, $statusCode = 200) {
        $response = [
            'success' => true,
            'message' => $message,
            'data' => $data
        ];
        
        $this->json($response, $statusCode);
    }
    
    /**
     * Send error response
     */
    public function error($message, $data = null, $statusCode = 400) {
        $response = [
            'success' => false,
            'message' => $message,
            'data' => $data
        ];
        
        $this->json($response, $statusCode);
    }
    
    /**
     * Send HTML
     */
    public function html($content, $statusCode = 200) {
        $this->status($statusCode);
        $this->header('Content-Type', 'text/html; charset=UTF-8');
        
        echo $content;
        exit;
    }
    
    /**
     * Redirect
     */
    public function redirect($url, $statusCode = 302) {
        $this->status($statusCode);
        $this->header('Location', $url);
        exit;
    }
    
    /**
     * Download file
     */
    public function download($file, $filename = null) {
        if (!file_exists($file)) {
            $this->error('File not found', null, 404);
        }
        
        $filename = $filename ?: basename($file);
        
        $this->header('Content-Type', 'application/octet-stream');
        $this->header('Content-Disposition', "attachment; filename=\"$filename\"");
        $this->header('Content-Length', filesize($file));
        
        readfile($file);
        exit;
    }
}
