<?php
/**
 * Router Class
 * Handles routing and request dispatching
 */

class Router {
    private $routes = [];
    private $prefix = '';
    private $middleware = [];
    
    /**
     * Register GET route
     */
    public function get($path, $action, $middleware = []) {
        return $this->register('GET', $path, $action, $middleware);
    }
    
    /**
     * Register POST route
     */
    public function post($path, $action, $middleware = []) {
        return $this->register('POST', $path, $action, $middleware);
    }
    
    /**
     * Register PUT route
     */
    public function put($path, $action, $middleware = []) {
        return $this->register('PUT', $path, $action, $middleware);
    }
    
    /**
     * Register DELETE route
     */
    public function delete($path, $action, $middleware = []) {
        return $this->register('DELETE', $path, $action, $middleware);
    }
    
    /**
     * Register a route
     */
    private function register($method, $path, $action, $middleware = []) {
        $fullPath = $this->prefix . $path;
        $key = "$method:$fullPath";
        
        $this->routes[$key] = [
            'method' => $method,
            'path' => $fullPath,
            'action' => $action,
            'middleware' => array_merge($this->middleware, $middleware),
            'regex' => $this->pathToRegex($fullPath),
            'params' => $this->extractParams($fullPath)
        ];
        
        return $this;
    }
    
    /**
     * Set route prefix
     */
    public function prefix($prefix) {
        $this->prefix = '/' . trim($prefix, '/');
        return $this;
    }
    
    /**
     * Add route group middleware
     */
    public function middleware($middleware) {
        $this->middleware = (array)$middleware;
        return $this;
    }
    
    /**
     * Convert path to regex
     */
    private function pathToRegex($path) {
        $regex = preg_replace_callback(
            '/\{([^}]+)\}/',
            function ($matches) {
                return '(?P<' . $matches[1] . '>[^/]+)';
            },
            $path
        );
        
        return '#^' . $regex . '$#';
    }
    
    /**
     * Extract parameters from path
     */
    private function extractParams($path) {
        $params = [];
        preg_match_all('/\{([^}]+)\}/', $path, $matches);
        
        if (!empty($matches[1])) {
            $params = $matches[1];
        }
        
        return $params;
    }
    
    /**
     * Dispatch request
     */
    public function dispatch($method, $path, $request, $response) {
        $path = '/' . trim($path, '/');
        $routeKey = "$method:$path";
        
        // Check for exact match first
        if (isset($this->routes[$routeKey])) {
            return $this->executeRoute($this->routes[$routeKey], [], $request, $response);
        }
        
        // Check for pattern match
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }
            
            if (preg_match($route['regex'], $path, $matches)) {
                // Extract named parameters
                $params = [];
                foreach ($route['params'] as $param) {
                    if (isset($matches[$param])) {
                        $params[$param] = $matches[$param];
                    }
                }
                
                return $this->executeRoute($route, $params, $request, $response);
            }
        }
        
        // Route not found
        $response->status(404);
        Logger::warning("Route not found: $method $path");
        
        if (file_exists(APP_ROOT . '/app/views/errors/404.php')) {
            include APP_ROOT . '/app/views/errors/404.php';
        } else {
            echo "404 - Route not found: $method $path";
        }
    }
    
    /**
     * Execute route
     */
    private function executeRoute($route, $params, $request, $response) {
        try {
            // Execute middleware
            foreach ($route['middleware'] as $middleware) {
                if (is_callable($middleware)) {
                    $middleware($request, $response);
                }
            }
            
            // Execute action
            if (is_callable($route['action'])) {
                return call_user_func_array($route['action'], [$request, $response, $params]);
            }
            
            // Handle controller@action string
            if (is_string($route['action'])) {
                list($controller, $action) = explode('@', $route['action']);
                
                $controllerClass = 'CampaignHQ\\Controllers\\' . ucfirst($controller) . 'Controller';
                
                if (class_exists($controllerClass)) {
                    $controllerInstance = new $controllerClass($request, $response);
                    
                    if (method_exists($controllerInstance, $action)) {
                        return call_user_func_array(
                            [$controllerInstance, $action],
                            [$params]
                        );
                    } else {
                        throw new Exception("Action $action not found in $controllerClass");
                    }
                } else {
                    throw new Exception("Controller $controllerClass not found");
                }
            }
        } catch (Exception $e) {
            Logger::error("Route execution error: " . $e->getMessage());
            $response->error("An error occurred: " . $e->getMessage(), null, 500);
        }
    }
    
    /**
     * Get all routes
     */
    public function getRoutes() {
        return $this->routes;
    }
}
