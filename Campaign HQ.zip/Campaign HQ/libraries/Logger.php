<?php
/**
 * Logger Class
 * Handles all application logging
 */

class Logger {
    const LOG_INFO = 'INFO';
    const LOG_WARNING = 'WARNING';
    const LOG_ERROR = 'ERROR';
    const LOG_DEBUG = 'DEBUG';
    const LOG_CRITICAL = 'CRITICAL';
    
    private static $logFile = LOG_FILE;
    
    /**
     * Log a message
     */
    private static function write($level, $message, $data = null) {
        // Ensure log directory exists
        if (!file_exists(LOG_DIR)) {
            mkdir(LOG_DIR, 0755, true);
        }
        
        // Rotate log if needed
        self::rotateLog();
        
        // Format message
        $timestamp = date(DATETIME_FORMAT);
        $trace = self::getCallerInfo();
        
        $logMessage = "[$timestamp] [$level] $message";
        if ($trace) {
            $logMessage .= " [$trace]";
        }
        
        if ($data !== null) {
            if (is_array($data) || is_object($data)) {
                $logMessage .= "\n" . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            } else {
                $logMessage .= "\nData: $data";
            }
        }
        
        $logMessage .= "\n";
        
        // Write to file
        error_log($logMessage, 3, self::$logFile);
        
        // Also log to PHP error log in debug mode
        if (APP_DEBUG) {
            error_log($logMessage);
        }
    }
    
    /**
     * Get caller information
     */
    private static function getCallerInfo() {
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 3);
        
        if (isset($trace[2])) {
            $caller = $trace[2];
            $file = basename($caller['file']);
            $line = $caller['line'];
            $function = $caller['function'];
            
            return "$file:$line in $function()";
        }
        
        return null;
    }
    
    /**
     * Rotate log file if needed
     */
    private static function rotateLog() {
        if (!file_exists(self::$logFile)) {
            return;
        }
        
        $filesize = filesize(self::$logFile);
        
        if ($filesize > LOG_MAX_SIZE) {
            $timestamp = date('Y-m-d-H-i-s');
            $rotatedFile = LOG_DIR . "/app.$timestamp.log";
            rename(self::$logFile, $rotatedFile);
            
            // Clean up old logs
            self::cleanOldLogs();
        }
    }
    
    /**
     * Clean up old log files
     */
    private static function cleanOldLogs() {
        $files = glob(LOG_DIR . '/app.*.log');
        $now = time();
        
        foreach ($files as $file) {
            if ($now - filemtime($file) > (LOG_RETENTION_DAYS * 86400)) {
                unlink($file);
            }
        }
    }
    
    /**
     * Log info
     */
    public static function info($message, $data = null) {
        self::write(self::LOG_INFO, $message, $data);
    }
    
    /**
     * Log warning
     */
    public static function warning($message, $data = null) {
        self::write(self::LOG_WARNING, $message, $data);
    }
    
    /**
     * Log error
     */
    public static function error($message, $data = null) {
        self::write(self::LOG_ERROR, $message, $data);
    }
    
    /**
     * Log debug info
     */
    public static function debug($message, $data = null) {
        if (APP_DEBUG) {
            self::write(self::LOG_DEBUG, $message, $data);
        }
    }
    
    /**
     * Log critical error
     */
    public static function critical($message, $data = null) {
        self::write(self::LOG_CRITICAL, $message, $data);
    }
    
    /**
     * Get recent logs
     */
    public static function getRecentLogs($lines = 100) {
        if (!file_exists(self::$logFile)) {
            return [];
        }
        
        $file = new SplFileObject(self::$logFile);
        $file->seek(PHP_INT_MAX);
        $lastLine = $file->key();
        $lines = min($lines, $lastLine);
        $file->seek(max(0, $lastLine - $lines));
        
        $logs = [];
        while (!$file->eof()) {
            $line = $file->fgets();
            if (!empty(trim($line))) {
                $logs[] = $line;
            }
        }
        
        return $logs;
    }
}
