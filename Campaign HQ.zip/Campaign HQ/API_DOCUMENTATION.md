# CampaignHQ API Documentation

## Base URL
```
https://your-domain.com/campaignhq/api
```

## Authentication
All API endpoints require authentication. Authentication is handled via PHP sessions or API tokens.

### Headers Required
```
X-Requested-With: XMLHttpRequest
X-CSRF-Token: {csrf_token}
Content-Type: application/json
```

## Response Format
All responses are in JSON format:

### Success Response
```json
{
  "success": true,
  "message": "Operation successful",
  "data": {}
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description",
  "errors": {}
}
```

## Status Codes
- `200` - OK
- `201` - Created
- `204` - No Content
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Unprocessable Entity (Validation Error)
- `500` - Internal Server Error

---

## Dashboard

### Get Dashboard Statistics
```
GET /api/dashboard/stats
```

Response:
```json
{
  "success": true,
  "data": {
    "total_leads": 1250,
    "won_leads": 150,
    "campaigns_sent": 12,
    "open_rate": 28.5,
    "click_rate": 5.2,
    "pending_followups": 45
  }
}
```

### Get Dashboard Charts
```
GET /api/dashboard/charts
```

Response:
```json
{
  "success": true,
  "data": {
    "lead_sources": [...],
    "lead_status": [...],
    "campaign_performance": [...],
    "email_metrics": [...],
    "top_countries": [...]
  }
}
```

---

## Leads

### List Leads
```
GET /api/leads?page=1&search=query&status_id=1&country_id=1
```

Query Parameters:
- `page` (int) - Page number (default: 1)
- `search` (string) - Search term
- `status_id` (int) - Lead status ID
- `country_id` (int) - Country ID
- `industry_id` (int) - Industry ID
- `lead_source_id` (int) - Lead source ID
- `min_score` (int) - Minimum lead score
- `max_score` (int) - Maximum lead score

Response:
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "fullname": "John Doe",
      "email": "john@example.com",
      "phone": "+1234567890",
      "company": "Example Corp",
      "country": "United States",
      "industry": "Technology",
      "status": "qualified",
      "lead_score": 85,
      "created_at": "2024-01-15T10:00:00Z"
    }
  ],
  "pagination": {
    "current": 1,
    "total": 50,
    "count": 25,
    "total_items": 1250
  }
}
```

### Get Single Lead
```
GET /api/leads/:id
```

Response:
```json
{
  "success": true,
  "data": {
    "id": 1,
    "fullname": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "company": "Example Corp",
    "country": "United States",
    "industry": "Technology",
    "status": "qualified",
    "lead_score": 85,
    "notes": "Sample notes",
    "tags": ["tag1", "tag2"],
    "custom_fields": {
      "field_name": "field_value"
    },
    "created_at": "2024-01-15T10:00:00Z",
    "updated_at": "2024-01-15T10:00:00Z"
  }
}
```

### Create Lead
```
POST /api/leads
Content-Type: application/json

{
  "fullname": "Jane Smith",
  "email": "jane@example.com",
  "phone": "+1234567890",
  "company": "Tech Solutions",
  "country_id": 1,
  "industry_id": 2,
  "lead_source_id": 3,
  "status_id": 1,
  "lead_score": 75,
  "notes": "Interested in webinar"
}
```

Response:
```json
{
  "success": true,
  "message": "Lead created successfully",
  "data": {
    "id": 251,
    "redirect": "/leads/251"
  }
}
```

### Update Lead
```
PUT /api/leads/:id
Content-Type: application/json

{
  "fullname": "Jane Smith",
  "email": "jane.smith@example.com",
  "lead_score": 85,
  "status_id": 2
}
```

### Delete Lead
```
DELETE /api/leads/:id
```

### Export Leads
```
GET /api/leads/export/:format?filters=json
```

Formats: `csv`, `xlsx`, `json`

---

## Lead Notes

### Add Note
```
POST /api/leads/:id/notes
Content-Type: application/json

{
  "note": "Called client, very interested"
}
```

### Get Notes
```
GET /api/leads/:id/notes
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "content": "Called client, very interested",
      "created_by": "John Admin",
      "created_at": "2024-01-15T10:00:00Z"
    }
  ]
}
```

### Get Timeline
```
GET /api/leads/:id/timeline
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "event_type": "created",
      "description": "Lead created",
      "created_at": "2024-01-15T10:00:00Z"
    },
    {
      "id": 2,
      "event_type": "status_changed",
      "description": "Status changed to qualified",
      "created_at": "2024-01-16T10:00:00Z"
    }
  ]
}
```

---

## Campaigns

### List Campaigns
```
GET /api/campaigns?page=1&status=draft&search=query
```

Query Parameters:
- `page` (int) - Page number
- `status` (string) - Campaign status (draft, scheduled, sending, completed)
- `search` (string) - Search term

### Create Campaign
```
POST /api/campaigns
Content-Type: application/json

{
  "name": "Webinar Invitation",
  "campaign_type_id": 1,
  "subject": "Join us for our exclusive webinar",
  "template_id": 5,
  "sender_name": "CampaignHQ",
  "sender_email": "noreply@domain.com",
  "notes": "Q1 Marketing Campaign"
}
```

### Get Campaign Details
```
GET /api/campaigns/:id
```

### Update Campaign
```
PUT /api/campaigns/:id
Content-Type: application/json

{
  "name": "Updated Campaign Name",
  "subject": "Updated subject line"
}
```

### Delete Campaign
```
DELETE /api/campaigns/:id
```

### Add Recipients to Campaign
```
POST /api/campaigns/:id/recipients
Content-Type: application/json

{
  "lead_ids": [1, 2, 3, 4, 5]
}
```

### Send Campaign
```
POST /api/campaigns/:id/send
Content-Type: application/json

{
  "schedule": false
}
```

### Get Campaign Analytics
```
GET /api/campaigns/:id/analytics
```

Response:
```json
{
  "success": true,
  "data": {
    "total_recipients": 1000,
    "delivered": 950,
    "opened": 285,
    "clicked": 52,
    "bounced": 30,
    "unsubscribed": 15,
    "delivery_rate": 95.0,
    "open_rate": 28.5,
    "click_rate": 5.2,
    "bounce_rate": 3.0,
    "unsubscribe_rate": 1.5
  }
}
```

---

## Email Templates

### List Templates
```
GET /api/templates?page=1&type=webinar_invite&search=query
```

### Create Template
```
POST /api/templates
Content-Type: application/json

{
  "name": "Webinar Invitation",
  "template_type": "webinar_invite",
  "subject": "Join us for {{webinar_title}}",
  "body": "<html>...</html>"
}
```

The body supports variable interpolation using `{{variable_name}}` syntax:
- `{{fullname}}`
- `{{email}}`
- `{{company}}`
- `{{phone}}`
- `{{webinar_title}}`
- `{{webinar_date}}`
- `{{webinar_time}}`
- `{{registration_url}}`

### Get Template
```
GET /api/templates/:id
```

### Preview Template
```
GET /api/templates/:id/preview
```

Returns template with sample variable values rendered.

### Update Template
```
PUT /api/templates/:id
Content-Type: application/json

{
  "name": "Updated Template Name",
  "body": "<html>...</html>"
}
```

### Delete Template
```
DELETE /api/templates/:id
```

---

## Follow-ups

### List Follow-ups
```
GET /api/followups?page=1&status=pending&lead_id=1
```

### Create Follow-up
```
POST /api/followups
Content-Type: application/json

{
  "lead_id": 1,
  "campaign_id": 5,
  "task_type": "call",
  "description": "Call to discuss proposal",
  "due_date": "2024-02-15",
  "priority": "high"
}
```

### Update Follow-up
```
PUT /api/followups/:id
Content-Type: application/json

{
  "status": "completed",
  "notes": "Client confirmed interest"
}
```

### Delete Follow-up
```
DELETE /api/followups/:id
```

---

## Analytics

### Campaign Analytics
```
GET /api/analytics/campaign/:id
```

### Lead Analytics
```
GET /api/analytics/leads?date_from=2024-01-01&date_to=2024-01-31
```

### Email Performance
```
GET /api/analytics/email-performance?metric=open_rate&period=daily
```

Parameters:
- `metric` - open_rate, click_rate, delivery_rate, bounce_rate, unsubscribe_rate
- `period` - daily, weekly, monthly

---

## Error Handling

### Validation Errors
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": {
    "email": ["Email is required", "Email format is invalid"],
    "fullname": ["Fullname is required"]
  }
}
```

### Not Found
```json
{
  "success": false,
  "message": "Resource not found"
}
```

### Unauthorized
```json
{
  "success": false,
  "message": "Unauthorized access"
}
```

---

## Rate Limiting

API requests are limited to prevent abuse:
- **Requests**: 100 per hour per IP
- **Response Header**: `X-RateLimit-Remaining: 45`

When rate limit exceeded:
```json
{
  "success": false,
  "message": "Rate limit exceeded"
}
```
HTTP Status: `429 Too Many Requests`

---

## Pagination

Paginated responses include:
```json
{
  "pagination": {
    "current": 1,
    "total": 50,
    "count": 25,
    "total_items": 1250
  }
}
```

---

## Examples

### Using cURL
```bash
# Get leads
curl -X GET "https://domain.com/campaignhq/api/leads?page=1" \
  -H "X-Requested-With: XMLHttpRequest" \
  -H "X-CSRF-Token: {csrf_token}" \
  -H "Cookie: PHPSESSID={session_id}"

# Create lead
curl -X POST "https://domain.com/campaignhq/api/leads" \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: {csrf_token}" \
  -H "Cookie: PHPSESSID={session_id}" \
  -d '{
    "fullname": "John Doe",
    "email": "john@example.com",
    "company": "Example Corp"
  }'
```

### Using JavaScript/jQuery
```javascript
$.ajax({
  url: '/campaignhq/api/leads',
  method: 'GET',
  dataType: 'json',
  success: function(response) {
    if (response.success) {
      console.log(response.data);
    }
  }
});
```

### Using Python
```python
import requests
import json

headers = {
  'X-Requested-With': 'XMLHttpRequest',
  'Content-Type': 'application/json'
}

response = requests.get(
  'https://domain.com/campaignhq/api/leads',
  headers=headers,
  cookies={'PHPSESSID': session_id}
)

data = response.json()
```

---

## Webhooks

SendGrid webhooks are automatically processed at:
```
POST /api/webhooks/sendgrid
```

Supported events:
- `delivered` - Email delivered
- `open` - Email opened
- `click` - Link clicked in email
- `bounce` - Email bounced
- `unsubscribe` - Recipient unsubscribed
- `spam_report` - Marked as spam

---

## Support

For API support:
- Email: api-support@campaignhq.com
- Documentation: https://docs.campaignhq.com/api
- Community: https://community.campaignhq.com
