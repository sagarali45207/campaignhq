# CampaignHQ - Marketing Automation Platform

A comprehensive, production-ready SaaS-style Campaign Management System built with PHP 8.3, MySQL 8, and modern web technologies.

## Features

### 🎯 Lead Management
- **Lead Import**: Support for XLSX, XLS, CSV formats with duplicate detection
- **Lead Database**: Manage 100,000+ leads with advanced filtering and search
- **Custom Fields**: Create dynamic custom lead fields
- **Tags & Notes**: Comprehensive lead tagging and remarks system
- **Lead Timeline**: Track all lead interactions and changes
- **Bulk Actions**: Update multiple leads at once

### 📧 Campaign Management
- **Campaign Types**: Webinar invitations, reminders, follow-ups, nurture sequences
- **Email Templates**: Drag-and-drop builder with dynamic variables
- **Campaign Scheduler**: Schedule emails for optimal delivery times
- **A/B Testing**: Test different templates and subject lines
- **Campaign Analytics**: Real-time performance metrics

### 📊 Email Tracking & Analytics
- **SendGrid Integration**: Full email sending and tracking
- **Email Metrics**: Delivery, open, click, bounce rates
- **Webhook Events**: Real-time event processing
- **Campaign Reports**: Detailed analytics by campaign, date, webinar, country
- **Performance Trends**: Visual charts and graphs

### 👥 User Management
- **Role-Based Access Control**: Admin and Marketing User roles
- **Permission System**: Granular permission management
- **User Audit Logs**: Track all user actions
- **Session Management**: Secure session handling

### 🔧 Admin Features
- **System Settings**: Configure SendGrid, site name, timezone
- **Email Settings**: Manage sender information
- **Audit Logs**: Complete action history
- **Database Backups**: Built-in backup functionality

### 🎨 User Interface
- **Dark Mode Theme**: Modern SaaS-style dark interface
- **Responsive Design**: Works perfectly on desktop, tablet, mobile
- **Glassmorphism Cards**: Modern card designs with transparency effects
- **Interactive Charts**: Real-time performance visualization
- **Smooth Animations**: Polished user experience

## System Requirements

### Server Requirements
- **PHP**: 8.3 or higher
- **MySQL**: 8.0 or higher
- **Web Server**: Apache 2.4+ or Nginx
- **Memory**: Minimum 256MB, recommended 512MB+

### Required PHP Extensions
- `php-pdo` (MySQL database)
- `php-curl` (SendGrid API)
- `php-json` (JSON parsing)
- `php-mbstring` (String handling)
- `php-fileinfo` (File type detection)

### Browser Requirements
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Installation Guide

### Step 1: Download and Extract
```bash
# Navigate to your web root
cd /var/www/html

# Clone or extract the project
git clone https://github.com/yourusername/campaignhq.git
cd campaignhq
```

### Step 2: Create Environment File
```bash
# Copy the example environment file
cp .env.example .env

# Edit configuration
nano .env
```

**.env Configuration:**
```env
APP_ENV=production
APP_DEBUG=false

DB_HOST=localhost
DB_USER=campaignhq_user
DB_PASS=strong_password_here
DB_NAME=campaign_hq
DB_PORT=3306

SENDGRID_API_KEY=your_sendgrid_api_key_here
SENDGRID_SENDER_EMAIL=noreply@yourdomain.com
SENDGRID_SENDER_NAME=CampaignHQ

BASE_URL=https://your-domain.com/campaignhq
SESSION_DOMAIN=your-domain.com
SESSION_SECURE=true
```

### Step 3: Create Database
```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE campaign_hq CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Create user
CREATE USER 'campaignhq_user'@'localhost' IDENTIFIED BY 'strong_password_here';

# Grant permissions
GRANT ALL PRIVILEGES ON campaign_hq.* TO 'campaignhq_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import database schema
mysql -u campaignhq_user -p campaign_hq < database.sql
```

### Step 4: Set File Permissions
```bash
# Set correct permissions
chmod 755 public
chmod 755 public/uploads
chmod 755 logs
chmod 644 public/assets/css/*
chmod 644 public/assets/js/*

# Set ownership
chown -R www-data:www-data /var/www/html/campaignhq
```

### Step 5: Configure Web Server

#### Apache (.htaccess)
```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /campaignhq/
    
    # Remove .php extension
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php?/$1 [QSA,L]
</IfModule>
```

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/html/campaignhq;
    
    location / {
        if (!-e $request_filename) {
            rewrite ^(.*)$ /index.php?/$1 break;
        }
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
    }
    
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### Step 6: Enable HTTPS
```bash
# Install SSL certificate with Let's Encrypt
sudo certbot certonly --webroot -w /var/www/html/campaignhq -d your-domain.com

# Configure in Nginx/Apache
```

### Step 7: Create Admin User
```php
<?php
// Run once to create admin user
require 'config/config.php';

$email = 'admin@example.com';
$password = 'admin123';
$fullname = 'Administrator';

$db = Database::getInstance();
$hashedPassword = Security::hashPassword($password);

$db->query('
    INSERT INTO users (fullname, email, password, role_id, status, created_at)
    VALUES (:fullname, :email, :password, 1, "active", NOW())
');
$db->bind(':fullname', $fullname);
$db->bind(':email', $email);
$db->bind(':password', $hashedPassword);
$db->execute();

echo "Admin user created successfully!";
?>
```

### Step 8: Configure SendGrid Integration
1. Sign up at https://sendgrid.com
2. Create API key from Settings > API Keys
3. Add API key to .env: `SENDGRID_API_KEY=SG.xxxxx`
4. Verify sender email in SendGrid

### Step 9: Test Installation
```bash
# Test database connection
curl https://your-domain.com/campaignhq/api/test-connection

# Test application
https://your-domain.com/campaignhq/login
```

## Project Structure

```
campaignhq/
├── app/
│   ├── controllers/        # Request handlers
│   ├── models/            # Data models
│   ├── views/             # Template files
│   └── middleware/        # Request middleware
├── config/
│   ├── config.php         # Configuration
│   └── autoload.php       # Class autoloader
├── database.sql           # Database schema
├── public/
│   ├── assets/
│   │   ├── css/          # Stylesheets
│   │   ├── js/           # JavaScript
│   │   └── images/       # Images
│   └── uploads/
│       ├── leads/        # Lead imports
│       └── templates/    # Email templates
├── libraries/             # Core classes
├── helpers/               # Helper functions
├── logs/                  # Application logs
├── index.php             # Entry point
└── .env                  # Environment config
```

## Database Schema Overview

### Core Tables
- **users**: User accounts with roles
- **roles**: User roles (admin, marketing_user)
- **permissions**: System permissions
- **role_permissions**: Role-permission mapping

### Lead Management
- **leads**: Lead records with all fields
- **lead_statuses**: Lead status options
- **lead_sources**: Lead source tracking
- **industries**: Industry categories
- **countries**: Country list
- **lead_custom_fields**: Custom field definitions
- **lead_custom_field_values**: Custom field values
- **lead_notes**: Remarks and notes
- **lead_tags**: Custom tags
- **lead_lead_tags**: Lead-tag relationships
- **lead_timeline**: Event history
- **lead_imports**: Import tracking

### Campaign Management
- **campaigns**: Campaign records
- **campaign_types**: Campaign type options
- **campaign_leads**: Campaign-lead relationships
- **email_templates**: Email templates
- **email_logs**: Email delivery tracking
- **sendgrid_events**: SendGrid webhook events

### Follow-ups & Notifications
- **followups**: Follow-up tasks
- **notifications**: System notifications
- **audit_logs**: Action audit trail

## API Endpoints

### Authentication
- `POST /login` - User login
- `POST /forgot-password` - Password reset request
- `POST /reset-password` - Reset password
- `GET /logout` - User logout
- `GET /auth/status` - Check authentication

### Leads
- `GET /api/leads` - List leads (paginated, filtered)
- `POST /api/leads` - Create lead
- `GET /api/leads/:id` - Get single lead
- `PUT /api/leads/:id` - Update lead
- `DELETE /api/leads/:id` - Delete lead
- `GET /api/leads/:id/notes` - Get lead notes
- `POST /api/leads/:id/notes` - Add note
- `GET /api/leads/:id/timeline` - Get lead timeline
- `POST /api/leads/bulk-action` - Bulk operations
- `GET /api/leads/export/:format` - Export leads

### Campaigns
- `GET /api/campaigns` - List campaigns
- `POST /api/campaigns` - Create campaign
- `PUT /api/campaigns/:id` - Update campaign
- `DELETE /api/campaigns/:id` - Delete campaign
- `POST /api/campaigns/:id/send` - Send campaign
- `GET /api/campaigns/:id/analytics` - Campaign analytics

### Templates
- `GET /api/templates` - List templates
- `POST /api/templates` - Create template
- `PUT /api/templates/:id` - Update template
- `DELETE /api/templates/:id` - Delete template

### Analytics
- `GET /api/analytics/campaign/:id` - Campaign metrics
- `GET /api/analytics/leads` - Lead analytics
- `GET /api/analytics/email-performance` - Email metrics

## Configuration Options

### Environment Variables
See `.env.example` for all configuration options.

### Key Settings
- `APP_ENV`: production or development
- `APP_DEBUG`: Enable debug mode (false in production)
- `DB_*`: Database connection details
- `SENDGRID_*`: SendGrid API configuration
- `SESSION_*`: Session security settings
- `RATE_LIMIT_*`: API rate limiting

## Security Features

### Authentication & Authorization
- BCrypt password hashing
- Role-Based Access Control (RBAC)
- Session management with timeout
- Password reset tokens
- Remember me functionality

### Data Protection
- CSRF token validation
- XSS protection via output escaping
- SQL injection prevention with prepared statements
- Password reset token expiration
- Secure cookie handling

### Audit & Monitoring
- Complete audit trail of all actions
- IP address logging
- User agent tracking
- Error logging
- Rate limiting

## Maintenance

### Backup
```bash
# Backup database
mysqldump -u campaignhq_user -p campaign_hq > backup.sql

# Backup files
tar -czf campaignhq_backup.tar.gz /var/www/html/campaignhq
```

### Updates
```bash
# Pull latest changes
git pull origin main

# Run database migrations if any
php artisan migrate

# Clear caches
rm -rf logs/*
```

### Monitoring
- Check error logs: `tail -f logs/error.log`
- Monitor database: `mysql> SHOW PROCESSLIST;`
- Check disk space: `df -h`
- Monitor memory: `free -h`

## Troubleshooting

### Database Connection Issues
```bash
# Test connection
mysql -h localhost -u campaignhq_user -p campaign_hq -e "SELECT 1;"

# Check MySQL service
sudo service mysql status
```

### Permission Errors
```bash
# Fix file permissions
sudo chown -R www-data:www-data /var/www/html/campaignhq
sudo chmod -R 755 /var/www/html/campaignhq
```

### SendGrid Integration
1. Verify API key is correct
2. Check sender email is verified
3. Review SendGrid event webhooks
4. Check spam filters

### Performance Issues
1. Enable database query caching
2. Implement Redis for sessions
3. Optimize database indexes
4. Enable gzip compression
5. Use CDN for static assets

## API Documentation

Full API documentation available at `/docs/api.md`

## Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Submit pull request

## License

Proprietary License - See LICENSE.md

## Support

Email: support@campaignhq.com
Documentation: https://docs.campaignhq.com
Community: https://community.campaignhq.com

## Version History

### v1.0.0 - Initial Release
- Complete lead management system
- Campaign creation and sending
- Email tracking and analytics
- User and permission management
- Audit logging system
- SendGrid integration
- Responsive dark-themed UI

## Credits

Built with:
- PHP 8.3
- MySQL 8.0
- Bootstrap 5
- Chart.js
- DataTables
- jQuery
- Font Awesome
