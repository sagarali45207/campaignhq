<?php
/**
 * CampaignHQ Installation Script
 * Run this script once to set up the application
 * 
 * Usage: php install.php
 */

require_once __DIR__ . '/config/config.php';

echo "==============================================\n";
echo "CampaignHQ Installation Script\n";
echo "==============================================\n\n";

try {
    // Step 1: Verify database connection
    echo "[1/5] Verifying database connection...\n";
    $db = Database::getInstance();
    $db->query('SELECT 1');
    $db->execute();
    echo "✓ Database connection successful\n\n";
    
    // Step 2: Check database tables
    echo "[2/5] Checking database tables...\n";
    $db->query('SHOW TABLES');
    $db->execute();
    $tables = $db->resultSet();
    
    if (count($tables) === 0) {
        echo "✗ No tables found. Please import database.sql first.\n";
        echo "   mysql -u " . DB_USER . " -p " . DB_NAME . " < database.sql\n";
        exit(1);
    }
    
    echo "✓ Found " . count($tables) . " database tables\n\n";
    
    // Step 3: Create uploads directories
    echo "[3/5] Creating upload directories...\n";
    $uploadDirs = [
        APP_ROOT . '/public/uploads',
        APP_ROOT . '/public/uploads/leads',
        APP_ROOT . '/public/uploads/templates',
    ];
    
    foreach ($uploadDirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
            echo "✓ Created: $dir\n";
        } else {
            echo "✓ Already exists: $dir\n";
        }
    }
    echo "\n";
    
    // Step 4: Create logs directory
    echo "[4/5] Setting up logging...\n";
    if (!is_dir(APP_ROOT . '/logs')) {
        mkdir(APP_ROOT . '/logs', 0755, true);
        echo "✓ Created logs directory\n";
    } else {
        echo "✓ Logs directory exists\n";
    }
    echo "\n";
    
    // Step 5: Create or update admin user
    echo "[5/5] Setting up admin user...\n";
    
    // Check if admin exists
    $db->query('SELECT id FROM users WHERE role_id = 1 LIMIT 1');
    $db->execute();
    $adminExists = $db->single();
    
    if ($adminExists) {
        echo "✓ Admin user already exists\n";
        echo "   Email: (existing admin account)\n";
        echo "   To create a new admin, edit create-admin.php\n";
    } else {
        // Create default admin
        $email = 'admin@example.com';
        $password = 'Admin123!Change';
        $fullname = 'Administrator';
        
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        
        $db->query('
            INSERT INTO users (fullname, email, password, role_id, status, created_at, updated_at)
            VALUES (:fullname, :email, :password, 1, "active", NOW(), NOW())
        ');
        $db->bind(':fullname', $fullname);
        $db->bind(':email', $email);
        $db->bind(':password', $hashedPassword);
        $db->execute();
        
        echo "✓ Admin user created successfully\n";
        echo "   Email: $email\n";
        echo "   Password: $password\n";
        echo "   ⚠️  Please change password after first login!\n";
    }
    
    echo "\n";
    echo "==============================================\n";
    echo "✓ Installation completed successfully!\n";
    echo "==============================================\n\n";
    
    echo "Next steps:\n";
    echo "1. Update .env with your SendGrid API key\n";
    echo "2. Configure your web server\n";
    echo "3. Access the application at your configured BASE_URL\n";
    echo "4. Login with your admin credentials\n";
    echo "5. Configure system settings\n";
    
    echo "\nFor more information, see SETUP_GUIDE.md\n";
    
} catch (Exception $e) {
    echo "✗ Installation failed: " . $e->getMessage() . "\n";
    exit(1);
}
