-- CampaignHQ Database Schema
-- MySQL 8.0+
-- Complete SaaS Campaign Management System

SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;
SET COLLATION_CONNECTION=utf8mb4_unicode_ci;

-- =====================================================
-- ROLES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `roles` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) UNIQUE NOT NULL COMMENT 'admin, marketing_user',
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- PERMISSIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(100) UNIQUE NOT NULL,
  `description` TEXT,
  `module` VARCHAR(50),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- ROLE PERMISSIONS JUNCTION
-- =====================================================
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`, `permission_id`),
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE CASCADE,
  INDEX `idx_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- USERS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `fullname` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL COMMENT 'bcrypt hashed',
  `role_id` INT NOT NULL,
  `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  `last_login` DATETIME NULL,
  `password_reset_token` VARCHAR(255) NULL,
  `password_reset_expires` DATETIME NULL,
  `remember_me_token` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD STATUS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_statuses` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) UNIQUE NOT NULL,
  `color` VARCHAR(20),
  `description` TEXT,
  `sort_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD SOURCES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_sources` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(100) UNIQUE NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- INDUSTRIES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `industries` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(100) UNIQUE NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- COUNTRIES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `countries` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(100) UNIQUE NOT NULL,
  `code` VARCHAR(5),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEADS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `leads` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `fullname` VARCHAR(255) NOT NULL,
  `firstname` VARCHAR(255),
  `lastname` VARCHAR(255),
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `secondary_email` VARCHAR(255),
  `company` VARCHAR(255),
  `job_title` VARCHAR(255),
  `department` VARCHAR(255),
  `phone` VARCHAR(20),
  `mobile` VARCHAR(20),
  `country_id` INT,
  `state` VARCHAR(100),
  `city` VARCHAR(100),
  `industry_id` INT,
  `lead_source_id` INT,
  `webinar_interest` VARCHAR(255),
  `lead_score` INT DEFAULT 0,
  `status_id` INT,
  `remarks` LONGTEXT,
  `imported_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`),
  FOREIGN KEY (`industry_id`) REFERENCES `industries`(`id`),
  FOREIGN KEY (`lead_source_id`) REFERENCES `lead_sources`(`id`),
  FOREIGN KEY (`status_id`) REFERENCES `lead_statuses`(`id`),
  FOREIGN KEY (`imported_by`) REFERENCES `users`(`id`),
  INDEX `idx_email_search` (`email`),
  INDEX `idx_company` (`company`),
  INDEX `idx_status_id` (`status_id`),
  INDEX `idx_lead_score` (`lead_score`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_country_id` (`country_id`),
  INDEX `idx_industry_id` (`industry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD CUSTOM FIELDS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_custom_fields` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `field_name` VARCHAR(255) NOT NULL,
  `field_type` ENUM('text', 'number', 'date', 'select', 'textarea', 'checkbox', 'radio') DEFAULT 'text',
  `field_options` JSON,
  `is_required` BOOLEAN DEFAULT FALSE,
  `sort_order` INT DEFAULT 0,
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `idx_field_name` (`field_name`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD CUSTOM FIELD VALUES
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_custom_field_values` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `lead_id` INT NOT NULL,
  `custom_field_id` INT NOT NULL,
  `field_value` LONGTEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `idx_lead_field` (`lead_id`, `custom_field_id`),
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`custom_field_id`) REFERENCES `lead_custom_fields`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD NOTES TABLE (REMARKS SYSTEM)
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_notes` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `lead_id` INT NOT NULL,
  `note_type` ENUM('internal_note', 'remark', 'follow_up_note') DEFAULT 'internal_note',
  `content` LONGTEXT NOT NULL,
  `old_value` TEXT,
  `new_value` TEXT,
  `field_changed` VARCHAR(100),
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_lead_id` (`lead_id`),
  INDEX `idx_note_type` (`note_type`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD TAGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_tags` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(100) UNIQUE NOT NULL,
  `description` TEXT,
  `color` VARCHAR(20),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD TAG JUNCTION
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_lead_tags` (
  `lead_id` INT NOT NULL,
  `tag_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lead_id`, `tag_id`),
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`tag_id`) REFERENCES `lead_tags`(`id`) ON DELETE CASCADE,
  INDEX `idx_tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD IMPORTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_imports` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `filename` VARCHAR(255) NOT NULL,
  `file_size` INT,
  `total_rows` INT,
  `imported_rows` INT,
  `skipped_rows` INT,
  `duplicate_handling` ENUM('skip', 'update', 'duplicate') DEFAULT 'skip',
  `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
  `error_message` TEXT,
  `imported_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `completed_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`imported_by`) REFERENCES `users`(`id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- CAMPAIGN TYPES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `campaign_types` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) UNIQUE NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- CAMPAIGNS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `campaign_type_id` INT NOT NULL,
  `subject` VARCHAR(500) NOT NULL,
  `sender_name` VARCHAR(255),
  `sender_email` VARCHAR(255),
  `template_id` INT,
  `audience_segment_filter` JSON,
  `scheduled_date` DATETIME,
  `scheduled_time` TIME,
  `status` ENUM('draft', 'scheduled', 'sending', 'completed', 'paused', 'failed') DEFAULT 'draft',
  `total_recipients` INT DEFAULT 0,
  `emails_sent` INT DEFAULT 0,
  `emails_delivered` INT DEFAULT 0,
  `emails_opened` INT DEFAULT 0,
  `emails_clicked` INT DEFAULT 0,
  `emails_bounced` INT DEFAULT 0,
  `emails_unsubscribed` INT DEFAULT 0,
  `open_rate` DECIMAL(5, 2) DEFAULT 0,
  `click_rate` DECIMAL(5, 2) DEFAULT 0,
  `bounce_rate` DECIMAL(5, 2) DEFAULT 0,
  `unsubscribe_rate` DECIMAL(5, 2) DEFAULT 0,
  `notes` LONGTEXT,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `started_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`campaign_type_id`) REFERENCES `campaign_types`(`id`),
  FOREIGN KEY (`template_id`) REFERENCES `email_templates`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_scheduled_date` (`scheduled_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- CAMPAIGN LEADS JUNCTION
-- =====================================================
CREATE TABLE IF NOT EXISTS `campaign_leads` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `campaign_id` INT NOT NULL,
  `lead_id` INT NOT NULL,
  `status` ENUM('pending', 'sent', 'delivered', 'opened', 'clicked', 'bounced', 'unsubscribed', 'failed') DEFAULT 'pending',
  `email_sent_at` DATETIME,
  `email_delivered_at` DATETIME,
  `email_opened_at` DATETIME,
  `email_clicked_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `idx_campaign_lead` (`campaign_id`, `lead_id`),
  FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  INDEX `idx_status` (`status`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- EMAIL TEMPLATES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `template_type` VARCHAR(50),
  `subject` VARCHAR(500) NOT NULL,
  `html_content` LONGTEXT NOT NULL,
  `plain_text_content` LONGTEXT,
  `preview_text` TEXT,
  `variables` JSON,
  `is_system_template` BOOLEAN DEFAULT FALSE,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  INDEX `idx_template_type` (`template_type`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- EMAIL LOGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `email_logs` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `campaign_id` INT,
  `lead_id` INT NOT NULL,
  `recipient_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(500),
  `sendgrid_message_id` VARCHAR(255) UNIQUE,
  `status` ENUM('pending', 'queued', 'delivered', 'opened', 'clicked', 'bounced', 'rejected', 'unsubscribed', 'spam_report', 'failed') DEFAULT 'pending',
  `bounce_type` VARCHAR(50),
  `bounce_reason` TEXT,
  `sent_at` DATETIME,
  `delivered_at` DATETIME,
  `opened_at` DATETIME,
  `clicked_at` DATETIME,
  `failed_at` DATETIME,
  `failure_reason` TEXT,
  `click_count` INT DEFAULT 0,
  `open_count` INT DEFAULT 0,
  `user_agent` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sendgrid_message_id` (`sendgrid_message_id`),
  FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  INDEX `idx_recipient_email` (`recipient_email`),
  INDEX `idx_status` (`status`),
  INDEX `idx_sent_at` (`sent_at`),
  INDEX `idx_delivered_at` (`delivered_at`),
  INDEX `idx_opened_at` (`opened_at`),
  INDEX `idx_campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SENDGRID EVENTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `sendgrid_events` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `email_log_id` INT,
  `event_type` VARCHAR(50) NOT NULL COMMENT 'bounce, open, click, unsubscribe, spam_report',
  `sendgrid_event_id` VARCHAR(255),
  `event_data` JSON,
  `ip_address` VARCHAR(45),
  `user_agent` TEXT,
  `received_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`email_log_id`) REFERENCES `email_logs`(`id`) ON DELETE SET NULL,
  INDEX `idx_event_type` (`event_type`),
  INDEX `idx_email_log_id` (`email_log_id`),
  INDEX `idx_received_at` (`received_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- UNSUBSCRIBED EMAILS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `unsubscribed_emails` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `lead_id` INT,
  `reason` VARCHAR(255),
  `unsubscribed_at` DATETIME,
  `unsubscribed_by` INT,
  `is_manual` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`unsubscribed_by`) REFERENCES `users`(`id`),
  INDEX `idx_email` (`email`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- FOLLOW-UPS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `followups` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `lead_id` INT NOT NULL,
  `campaign_id` INT,
  `followup_date` DATE NOT NULL,
  `followup_time` TIME,
  `reminder_notes` LONGTEXT,
  `assigned_to` INT NOT NULL,
  `status` ENUM('pending', 'completed', 'overdue', 'cancelled') DEFAULT 'pending',
  `completed_at` DATETIME,
  `completed_by` INT,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`assigned_to`) REFERENCES `users`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`),
  FOREIGN KEY (`completed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_lead_id` (`lead_id`),
  INDEX `idx_followup_date` (`followup_date`),
  INDEX `idx_status` (`status`),
  INDEX `idx_assigned_to` (`assigned_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAD TIMELINE TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `lead_timeline` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `lead_id` INT NOT NULL,
  `event_type` VARCHAR(50) NOT NULL COMMENT 'imported, email_sent, email_opened, link_clicked, note_added, status_changed, followup_scheduled',
  `event_title` VARCHAR(255),
  `event_description` TEXT,
  `metadata` JSON,
  `triggered_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`triggered_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_lead_id` (`lead_id`),
  INDEX `idx_event_type` (`event_type`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SAVED FILTERS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `saved_filters` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `filter_config` JSON NOT NULL,
  `created_by` INT NOT NULL,
  `is_public` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `idx_filter_name` (`name`, `created_by`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_created_by` (`created_by`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- AUDIT LOGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `action` VARCHAR(255) NOT NULL,
  `module` VARCHAR(100),
  `resource_type` VARCHAR(100),
  `resource_id` INT,
  `old_values` JSON,
  `new_values` JSON,
  `ip_address` VARCHAR(45),
  `user_agent` TEXT,
  `status` ENUM('success', 'failure') DEFAULT 'success',
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_action` (`action`),
  INDEX `idx_module` (`module`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_resource` (`resource_type`, `resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- NOTIFICATIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `notification_type` VARCHAR(100) NOT NULL COMMENT 'import_complete, campaign_sent, lead_assigned, followup_due',
  `title` VARCHAR(255),
  `message` TEXT NOT NULL,
  `related_resource_type` VARCHAR(100),
  `related_resource_id` INT,
  `is_read` BOOLEAN DEFAULT FALSE,
  `read_at` DATETIME,
  `action_url` VARCHAR(500),
  `notification_channel` ENUM('in_app', 'email', 'both') DEFAULT 'in_app',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_is_read` (`is_read`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SETTINGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `setting_key` VARCHAR(255) UNIQUE NOT NULL,
  `setting_value` LONGTEXT,
  `setting_type` ENUM('string', 'number', 'boolean', 'json', 'text') DEFAULT 'string',
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- DEFAULT DATA INSERTION
-- =====================================================

-- Insert default roles
INSERT INTO `roles` (`name`, `description`) VALUES
('admin', 'Administrator - Full access'),
('marketing_user', 'Marketing User - Limited permissions');

-- Insert default permissions
INSERT INTO `permissions` (`name`, `description`, `module`) VALUES
('manage_users', 'Manage system users', 'users'),
('import_leads', 'Import leads from files', 'leads'),
('export_leads', 'Export leads to files', 'leads'),
('view_leads', 'View lead database', 'leads'),
('edit_lead', 'Edit lead information', 'leads'),
('delete_lead', 'Delete leads', 'leads'),
('create_campaign', 'Create new campaigns', 'campaigns'),
('send_email', 'Send emails through campaigns', 'campaigns'),
('view_campaigns', 'View all campaigns', 'campaigns'),
('manage_templates', 'Manage email templates', 'templates'),
('view_analytics', 'View analytics and reports', 'analytics'),
('export_data', 'Export system data', 'data'),
('manage_settings', 'Manage system settings', 'settings'),
('view_audit_logs', 'View audit logs', 'audit');

-- Insert permissions for admin role
INSERT INTO `role_permissions` (`role_id`, `permission_id`) 
SELECT 1, `id` FROM `permissions`;

-- Insert limited permissions for marketing_user
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions` 
WHERE `name` IN ('import_leads', 'export_leads', 'view_leads', 'edit_lead', 'create_campaign', 'send_email', 'view_campaigns', 'manage_templates', 'view_analytics');

-- Insert default lead statuses
INSERT INTO `lead_statuses` (`name`, `color`, `description`, `sort_order`) VALUES
('New', '#0066ff', 'Newly imported lead', 1),
('Contacted', '#00cc99', 'Contact initiated', 2),
('Interested', '#ffaa00', 'Lead showed interest', 3),
('Qualified', '#00dd88', 'Sales qualified lead', 4),
('Proposal Sent', '#6633ff', 'Proposal sent to lead', 5),
('Negotiating', '#ff6600', 'In negotiation stage', 6),
('Won', '#00ff00', 'Successfully converted', 7),
('Lost', '#ff0000', 'Lead lost/rejected', 8),
('Unsubscribed', '#888888', 'Opted out of communications', 9);

-- Insert default lead sources
INSERT INTO `lead_sources` (`name`, `description`) VALUES
('Website', 'Leads from website form submissions'),
('Webinar', 'Leads from webinar registrations'),
('Email Campaign', 'Leads from email campaigns'),
('Social Media', 'Leads from social media advertising'),
('Referral', 'Leads from referrals'),
('Direct Sales', 'Leads from direct sales outreach'),
('Trade Show', 'Leads from trade shows and events'),
('Content Download', 'Leads from content downloads'),
('API Integration', 'Leads from integrated systems'),
('Manual Import', 'Manually imported leads');

-- Insert default industries
INSERT INTO `industries` (`name`, `description`) VALUES
('Technology', 'Software, IT, SaaS companies'),
('Finance', 'Banking, Insurance, Financial Services'),
('Healthcare', 'Medical, Pharmaceuticals, Healthcare'),
('Manufacturing', 'Industrial, Production, Manufacturing'),
('Retail', 'E-commerce, Retail, Consumer Goods'),
('Education', 'Schools, Universities, EdTech'),
('Entertainment', 'Media, Entertainment, Gaming'),
('Telecommunications', 'Telecom, Mobile Services'),
('Energy', 'Oil, Gas, Renewable Energy'),
('Real Estate', 'Property, Real Estate Services');

-- Insert default campaign types
INSERT INTO `campaign_types` (`name`, `description`) VALUES
('Webinar Invitation', 'Invite leads to webinar'),
('Reminder', 'Send reminders to leads'),
('Follow-Up', 'Follow-up communication'),
('Nurture Sequence', 'Multi-step nurture campaign'),
('Announcement', 'General announcements'),
('Re-engagement', 'Re-engage inactive leads');

-- Insert default settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`) VALUES
('site_name', 'CampaignHQ', 'string', 'Application name'),
('site_logo_url', '/assets/images/logo.png', 'string', 'Site logo URL'),
('timezone', 'UTC', 'string', 'Application timezone'),
('date_format', 'Y-m-d', 'string', 'Default date format'),
('time_format', 'H:i', 'string', 'Default time format'),
('sendgrid_api_key', '', 'string', 'SendGrid API Key'),
('sendgrid_sender_email', '', 'string', 'SendGrid sender email'),
('sendgrid_sender_name', 'CampaignHQ', 'string', 'SendGrid sender name'),
('password_min_length', '8', 'number', 'Minimum password length'),
('session_timeout', '3600', 'number', 'Session timeout in seconds'),
('max_import_size', '52428800', 'number', 'Max upload size in bytes (50MB)'),
('items_per_page', '25', 'number', 'Items per page in tables');

-- Insert default countries (sample)
INSERT INTO `countries` (`name`, `code`) VALUES
('United States', 'US'),
('Canada', 'CA'),
('United Kingdom', 'UK'),
('India', 'IN'),
('Germany', 'DE'),
('France', 'FR'),
('Australia', 'AU'),
('Japan', 'JP'),
('Brazil', 'BR'),
('Mexico', 'MX');

SET FOREIGN_KEY_CHECKS=1;
