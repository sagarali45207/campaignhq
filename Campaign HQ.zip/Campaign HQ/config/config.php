<?php
/**
 * CampaignHQ Configuration File
 * PHP 8.3+
 */

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Set default timezone
date_default_timezone_set('UTC');

// Environment
define('ENVIRONMENT', getenv('APP_ENV') ?: 'production');
define('APP_DEBUG', getenv('APP_DEBUG') ?: (ENVIRONMENT === 'development'));

// Application Details
define('APP_NAME', 'CampaignHQ');
define('APP_VERSION', '1.0.0');
define('APP_ROOT', dirname(__DIR__));

// Database Configuration
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'campaign_hq');
define('DB_PORT', getenv('DB_PORT') ?: 3306);
define('DB_CHARSET', 'utf8mb4');

// API and Base URLs
define('BASE_URL', getenv('BASE_URL') ?: 'http://localhost/campaignhq');
define('API_BASE_URL', BASE_URL . '/api');
define('PUBLIC_URL', BASE_URL . '/public');
define('ASSETS_URL', PUBLIC_URL . '/assets');

// Session Configuration
define('SESSION_TIMEOUT', 3600); // 1 hour
define('REMEMBER_ME_DURATION', 2592000); // 30 days
define('SESSION_DOMAIN', getenv('SESSION_DOMAIN') ?: 'localhost');
define('SESSION_SECURE', getenv('SESSION_SECURE') ?: false);
define('SESSION_HTTPONLY', true);
define('SESSION_SAMESITE', 'Lax');

// Security
define('CSRF_TOKEN_LENGTH', 32);
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_HASH_ALGORITHM', PASSWORD_BCRYPT);
define('PASSWORD_HASH_OPTIONS', ['cost' => 12]);

// File Uploads
define('MAX_UPLOAD_SIZE', 52428800); // 50MB
define('ALLOWED_UPLOAD_TYPES', ['xlsx', 'xls', 'csv']);
define('UPLOAD_DIR', APP_ROOT . '/public/uploads');

// SendGrid Configuration
define('SENDGRID_API_KEY', getenv('SENDGRID_API_KEY') ?: '');
define('SENDGRID_SENDER_EMAIL', getenv('SENDGRID_SENDER_EMAIL') ?: 'noreply@campaignhq.com');
define('SENDGRID_SENDER_NAME', getenv('SENDGRID_SENDER_NAME') ?: 'CampaignHQ');

// Pagination
define('ITEMS_PER_PAGE', 25);

// Log Configuration
define('LOG_DIR', APP_ROOT . '/logs');
define('LOG_FILE', LOG_DIR . '/app.log');
define('LOG_MAX_SIZE', 10485760); // 10MB
define('LOG_RETENTION_DAYS', 30);

// CORS Configuration
define('ALLOWED_ORIGINS', getenv('ALLOWED_ORIGINS') ? explode(',', getenv('ALLOWED_ORIGINS')) : ['http://localhost']);

// Email Configuration
define('EMAIL_FROM', SENDGRID_SENDER_EMAIL);
define('EMAIL_FROM_NAME', SENDGRID_SENDER_NAME);
define('EMAIL_BCC', getenv('EMAIL_BCC') ?: '');

// Date and Time Formats
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');
define('DISPLAY_DATE_FORMAT', 'm/d/Y');
define('DISPLAY_DATETIME_FORMAT', 'm/d/Y H:i:s');

// Feature Flags
define('FEATURE_CUSTOM_FIELDS', true);
define('FEATURE_ADVANCED_FILTERS', true);
define('FEATURE_WEBHOOKS', true);
define('FEATURE_API_ACCESS', true);

// Rate Limiting
define('RATE_LIMIT_ENABLED', true);
define('RATE_LIMIT_REQUESTS', 100);
define('RATE_LIMIT_WINDOW', 3600); // per hour

// Timezone Options
define('TIMEZONE_OPTIONS', [
    'UTC' => 'UTC',
    'America/New_York' => 'Eastern Time',
    'America/Chicago' => 'Central Time',
    'America/Denver' => 'Mountain Time',
    'America/Los_Angeles' => 'Pacific Time',
    'Europe/London' => 'London',
    'Europe/Paris' => 'Paris',
    'Asia/Tokyo' => 'Tokyo',
    'Asia/Shanghai' => 'Shanghai',
    'Australia/Sydney' => 'Sydney',
    'India/Kolkata' => 'India'
]);

// Auto-load classes
require_once APP_ROOT . '/config/autoload.php';

// Set error and exception handlers
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (error_reporting() === 0) {
        return;
    }
    Logger::error("PHP Error [$errno]: $errstr in $errfile on line $errline");
    
    if (APP_DEBUG) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    }
});

set_exception_handler(function (Throwable $e) {
    Logger::error("Exception: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    
    if (APP_DEBUG) {
        echo "<pre>";
        echo $e->getMessage() . "\n";
        echo $e->getFile() . ":" . $e->getLine() . "\n";
        echo $e->getTraceAsString();
        echo "</pre>";
    } else {
        http_response_code(500);
        include APP_ROOT . '/app/views/errors/500.php';
    }
});
