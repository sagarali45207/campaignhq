<?php
/**
 * Autoloader for CampaignHQ
 */

spl_autoload_register(function ($class) {
    $prefix = 'CampaignHQ\\';
    
    if (strpos($class, $prefix) === 0) {
        $relative_class = substr($class, strlen($prefix));
        $file = APP_ROOT . '/app/' . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
    
    // Auto-load from libraries
    $libraries = [
        'app/models',
        'app/controllers',
        'helpers',
        'libraries'
    ];
    
    foreach ($libraries as $dir) {
        $file = APP_ROOT . '/' . $dir . '/' . str_replace('\\', '/', $class) . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Load core classes
require_once APP_ROOT . '/libraries/Database.php';
require_once APP_ROOT . '/libraries/Logger.php';
require_once APP_ROOT . '/libraries/Router.php';
require_once APP_ROOT . '/libraries/Response.php';
require_once APP_ROOT . '/libraries/Request.php';
require_once APP_ROOT . '/helpers/Helpers.php';
require_once APP_ROOT . '/helpers/Security.php';
require_once APP_ROOT . '/helpers/Validator.php';
