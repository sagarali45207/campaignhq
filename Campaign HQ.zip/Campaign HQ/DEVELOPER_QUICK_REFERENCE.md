# CampaignHQ - Developer Quick Reference

## First Time Setup (5 minutes)

```bash
# 1. Configure environment
cp .env.example .env
# Edit .env with:
# - DB credentials
# - SendGrid API key (optional for now)

# 2. Import database
mysql -u root -p < database.sql

# 3. Run installation script
php install.php

# 4. Start local server
php -S localhost:8000

# 5. Login
# http://localhost:8000/login
# Email: admin@example.com
# Password: Admin123!Change
```

---

## File Organization

```
📁 app/
   📁 controllers/        ← Request handlers (⭐ edit here for features)
   📁 models/             ← Data access layer
   📁 views/              ← HTML templates
   📁 middleware/         ← Auth, validation, etc.

📁 libraries/             ← Core framework classes
📁 helpers/               ← Utility functions
📁 config/                ← Configuration
📁 public/
   📁 assets/
      📁 css/             ← Stylesheets
      📁 js/              ← JavaScript

🗄️  database.sql          ← Database schema
📄 index.php              ← Entry point
📄 install.php            ← Setup script
📄 .env.example           ← Configuration template
```

---

## Common Tasks

### Add New API Endpoint

1. **Create controller method** (app/controllers/MyController.php):
```php
public function getAction($id) {
    $this->authorize('feature', 'view');
    
    $data = $this->model->find($id);
    
    if (!$data) {
        return Response::json(['success' => false, 'message' => 'Not found'], 404);
    }
    
    return Response::json([
        'success' => true,
        'data' => $data
    ]);
}
```

2. **Add route** (index.php):
```php
$router->get('/api/path/:id', 'mycontroller@getAction', [$authMiddleware]);
```

3. **Test it**:
```bash
curl http://localhost:8000/api/path/1
```

### Add New Database Field

1. **Create migration** (or edit database.sql):
```sql
ALTER TABLE table_name ADD COLUMN new_field VARCHAR(255);
```

2. **Update Model** (app/models/MyModel.php):
```php
protected $fillable = ['existing_field', 'new_field'];
```

3. **Update Form** (app/views/form.php):
```html
<input type="text" name="new_field" class="form-control">
```

### Add New Permission

1. **Add to database.sql**:
```sql
INSERT INTO permissions (name, description) VALUES ('feature', 'View feature');
```

2. **Check in controller**:
```php
$this->authorize('feature', 'view');
```

### Create New Page/View

1. **Create controller** (app/controllers/PageController.php):
```php
class PageController extends Controller {
    public function index() {
        return $this->view('page/index', ['title' => 'My Page']);
    }
}
```

2. **Create template** (app/views/page/index.php):
```php
<?php view('layout', ['title' => $title]) ?>
<h1><?= e($title) ?></h1>
```

3. **Add route** (index.php):
```php
$router->get('/page', 'page@index', [$authMiddleware]);
```

---

## Key Classes & Functions

### Models
```php
// Get all records
$items = $model->all();

// Get paginated
$result = $model->paginate($page = 1, $limit = 25);

// Find by ID
$item = $model->find($id);

// Create
$id = $model->create(['field' => 'value']);

// Update
$model->update($id, ['field' => 'new_value']);

// Delete
$model->delete($id);

// Count
$count = $model->count();
```

### Request/Response
```php
// Get input
$name = Request::get('name');           // $_GET
$data = Request::post('data');          // $_POST
$json = Request::json();                // JSON body
$input = Request::input('field');       // $_GET or $_POST

// Send response
Response::json(['success' => true]);    // JSON
Response::redirect('/path');            // Redirect
Response::status(404);                  // HTTP status
```

### Security
```php
// Hash password
$hashed = Security::hashPassword('password');
Security::verifyPassword('password', $hashed);

// Sanitize input
$safe = Security::sanitize($_POST['input']);

// Generate CSRF token
$token = Security::generateCSRFToken();
Security::verifyCSRFToken();

// Validate email
Security::isValidEmail('test@example.com');

// Generate UUID
$uuid = Security::generateUUID();
```

### Helpers
```php
// Escape HTML
e($string);

// Format date
formatDate($date);
formatDateTime($date);
timeAgo($date);

// Check auth
auth();              // Current user
isAuthenticated();   // Is logged in
canUser('feature');  // Has permission

// View rendering
view('template', $data);
```

### Logging
```php
Logger::info('User logged in', ['user_id' => 1]);
Logger::warning('High memory usage');
Logger::error('Database connection failed');
Logger::debug('Debug information');
Logger::critical('System error', $exception);
```

---

## Database Queries

### Common Patterns

**Single result:**
```php
$db->query('SELECT * FROM users WHERE id = :id');
$db->bind(':id', $id);
$user = $db->single();
```

**Multiple results:**
```php
$db->query('SELECT * FROM leads WHERE status = :status');
$db->bind(':status', 'qualified');
$leads = $db->resultSet();
```

**Insert:**
```php
$db->query('
    INSERT INTO users (name, email, created_at)
    VALUES (:name, :email, NOW())
');
$db->bind(':name', $name);
$db->bind(':email', $email);
$db->execute();
```

**Update:**
```php
$db->query('UPDATE users SET status = :status WHERE id = :id');
$db->bind(':status', 'active');
$db->bind(':id', $id);
$db->execute();
```

**Transaction:**
```php
$db->beginTransaction();
try {
    // ... operations ...
    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    throw $e;
}
```

---

## JavaScript Utilities

### AJAX
```javascript
// GET
CampaignHQ.get('/api/endpoint').done(function(response) {
    console.log(response.data);
});

// POST
CampaignHQ.post('/api/endpoint', {field: 'value'}).done(function(r) {
    CampaignHQ.showSuccess('Done!');
});

// PUT
CampaignHQ.put('/api/endpoint/1', {field: 'new'});

// DELETE
CampaignHQ.delete('/api/endpoint/1');
```

### Alerts
```javascript
CampaignHQ.showSuccess('Operation successful');
CampaignHQ.showError('Something went wrong');
CampaignHQ.showAlert('Custom message', 'info');
```

### Utilities
```javascript
// Format
CampaignHQ.formatCurrency(100, '$', 2);      // $100.00
CampaignHQ.formatPercent(85.5, 2);           // 85.50%
CampaignHQ.timeAgo('2024-01-15T10:00:00');   // 2 days ago
CampaignHQ.formatDate('2024-01-15');         // 01/15/2024

// HTML escape
CampaignHQ.escape('<script>alert("hi")</script>');

// DataTable
CampaignHQ.initDataTable('#table', {
    pageLength: 50,
    order: [[0, 'desc']]
});
```

---

## CSS Classes

### Layout
```html
<!-- Container -->
<div class="container-fluid">
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-md-6">
            <!-- Content -->
        </div>
    </div>
</div>
```

### Cards
```html
<div class="card">
    <div class="card-header">Header</div>
    <div class="card-body">Body</div>
    <div class="card-footer">Footer</div>
</div>
```

### Status Badges
```html
<span class="badge bg-success">Active</span>
<span class="badge bg-warning">Pending</span>
<span class="badge bg-danger">Inactive</span>
<span class="badge bg-info">Info</span>
```

### Buttons
```html
<button class="btn btn-primary">Primary</button>
<button class="btn btn-outline-secondary">Outline</button>
<button class="btn btn-sm">Small</button>
```

---

## Environment Variables

```env
# Database
DB_HOST=localhost
DB_USER=campaignhq_user
DB_PASS=password
DB_NAME=campaign_hq

# SendGrid
SENDGRID_API_KEY=SG.xxx
SENDGRID_SENDER_EMAIL=noreply@domain.com

# URLs
BASE_URL=https://domain.com/campaignhq

# Session
SESSION_TIMEOUT=3600

# Debug
APP_DEBUG=false
APP_ENV=production
```

---

## Debugging

### View Logs
```bash
tail -f logs/error.log
tail -f logs/info.log
```

### Enable Debug Mode
```env
APP_DEBUG=true
```

### Database Debug
```php
Logger::debug('Query', ['sql' => $query, 'params' => $params]);
```

### JavaScript Console
```javascript
console.log('Debug message');
// Open DevTools: F12
```

---

## Testing Commands

```bash
# Test database connection
mysql -u campaignhq_user -p campaign_hq -e "SELECT 1;"

# Check PHP version
php -v

# Verify extensions
php -m | grep -E "pdo|mysql|curl"

# Run install script
php install.php

# Start local server
php -S localhost:8000

# Test API endpoint
curl http://localhost:8000/api/leads
```

---

## Important URLs

| URL | Purpose |
|-----|---------|
| /login | Login page |
| /dashboard | Dashboard |
| /leads | Lead list |
| /campaigns | Campaign list |
| /templates | Email templates |
| /api/leads | Leads API |
| /api/campaigns | Campaigns API |
| /api/templates | Templates API |

---

## Common Issues

### Database Connection Error
- Check .env credentials
- Verify MySQL is running
- Ensure database exists

### Blank Page
- Check logs/error.log
- Enable APP_DEBUG=true
- Verify PHP version is 8.3+

### Permission Denied
- Fix file permissions: `chmod -R 755 .`
- Fix ownership: `chown -R www-data:www-data .`

### CSRF Token Error
- Clear session: `rm /var/lib/php/sessions/*`
- Verify CSRF meta tag in layout

---

## Version Info

- **PHP**: 8.3+
- **MySQL**: 8.0+
- **Bootstrap**: 5.0+
- **jQuery**: 3.6+
- **Chart.js**: 3.0+

---

## Quick Links

- **Full Setup Guide**: SETUP_GUIDE.md
- **API Docs**: API_DOCUMENTATION.md
- **Project Overview**: PROJECT_SUMMARY.md
- **README**: README.md
- **Database Schema**: database.sql

---

## Next Developer: Start Here!

1. Read this file (you're doing it! ✓)
2. Run: `php install.php`
3. Login with admin account
4. Check SETUP_GUIDE.md for web server setup
5. Explore the code structure
6. Pick a task from PROJECT_SUMMARY.md

Good luck! 🚀
