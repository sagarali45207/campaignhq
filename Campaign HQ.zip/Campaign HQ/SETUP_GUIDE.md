# CampaignHQ - Complete Setup Guide

This guide will walk you through the complete installation and configuration of CampaignHQ.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Pre-Installation Checklist](#pre-installation-checklist)
3. [Step-by-Step Installation](#step-by-step-installation)
4. [Configuration Guide](#configuration-guide)
5. [Database Setup](#database-setup)
6. [Web Server Setup](#web-server-setup)
7. [SendGrid Integration](#sendgrid-integration)
8. [Post-Installation](#post-installation)
9. [Troubleshooting](#troubleshooting)

## System Requirements

### Minimum Requirements
- **Operating System**: Linux, Windows Server, or macOS
- **PHP**: 8.3 or higher
- **MySQL**: 8.0 or higher
- **Disk Space**: 500MB minimum
- **Memory**: 256MB minimum RAM (512MB+ recommended)
- **Bandwidth**: Sufficient for email sending

### Recommended Setup
- **PHP**: 8.3 with FPM
- **MySQL**: 8.0 with InnoDB
- **Web Server**: Nginx 1.20+ or Apache 2.4+
- **Disk Space**: 5GB+ (for logs, imports, and growth)
- **Memory**: 1GB+ RAM
- **Processor**: 2+ cores

### Required PHP Extensions
```bash
# Ubuntu/Debian installation
sudo apt-get install php8.3-pdo php8.3-mysql php8.3-curl php8.3-json php8.3-mbstring php8.3-fileinfo

# RHEL/CentOS installation
sudo yum install php-pdo php-mysqlnd php-curl php-json php-mbstring php-fileinfo
```

### Verify PHP Version and Extensions
```bash
php -v
php -m | grep -E "pdo|mysql|curl|json|mbstring|fileinfo"
```

## Pre-Installation Checklist

- [ ] Verify PHP 8.3+ is installed
- [ ] Verify MySQL 8.0+ is running
- [ ] Create a database user and database
- [ ] Obtain SendGrid API key (free tier available)
- [ ] Have domain/subdomain ready (or use localhost)
- [ ] Verify web server is running (Apache/Nginx)
- [ ] SSH/Terminal access to server
- [ ] Git installed (for version control)

## Step-by-Step Installation

### Step 1: Download Project

#### Option A: Using Git
```bash
cd /var/www/html
git clone https://github.com/yourusername/campaignhq.git
cd campaignhq
```

#### Option B: Download ZIP
```bash
cd /var/www/html
wget https://github.com/yourusername/campaignhq/archive/refs/heads/main.zip
unzip main.zip
mv campaignhq-main campaignhq
cd campaignhq
```

### Step 2: Create Environment File

```bash
# Copy example environment file
cp .env.example .env

# Edit with your settings
nano .env
```

### Step 3: Set File Permissions

```bash
# Create necessary directories
mkdir -p logs
mkdir -p public/uploads/leads
mkdir -p public/uploads/templates

# Set permissions
chmod 755 logs
chmod 755 public/uploads
chmod 755 public/uploads/leads
chmod 755 public/uploads/templates
chmod 644 .env

# Set ownership (adjust www-data to your web server user)
sudo chown -R www-data:www-data /var/www/html/campaignhq
sudo chown -R www-data:www-data logs/
sudo chown -R www-data:www-data public/uploads/
```

### Step 4: Create MySQL Database

```bash
# Login to MySQL
mysql -u root -p

# Execute commands
CREATE DATABASE campaign_hq CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'campaignhq_user'@'localhost' IDENTIFIED BY 'YourSecurePassword123!';
GRANT ALL PRIVILEGES ON campaign_hq.* TO 'campaignhq_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import schema
mysql -u campaignhq_user -p campaign_hq < database.sql
```

### Step 5: Configure Environment File

Edit `.env` with your settings:

```env
# Application
APP_NAME=CampaignHQ
APP_ENV=production
APP_DEBUG=false

# Database
DB_HOST=localhost
DB_USER=campaignhq_user
DB_PASS=YourSecurePassword123!
DB_NAME=campaign_hq

# SendGrid
SENDGRID_API_KEY=SG.your_api_key_here
SENDGRID_SENDER_EMAIL=noreply@yourdomain.com
SENDGRID_SENDER_NAME=CampaignHQ

# URLs
BASE_URL=https://your-domain.com/campaignhq
SESSION_DOMAIN=your-domain.com
SESSION_SECURE=true
```

### Step 6: Configure Web Server

#### Apache Configuration

Create `/etc/apache2/sites-available/campaignhq.conf`:

```apache
<VirtualHost *:80>
    ServerName your-domain.com
    ServerAlias www.your-domain.com
    DocumentRoot /var/www/html/campaignhq/public

    <Directory /var/www/html/campaignhq/public>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        
        <IfModule mod_rewrite.c>
            RewriteEngine On
            RewriteBase /campaignhq/
            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteCond %{REQUEST_FILENAME} !-d
            RewriteRule ^(.*)$ index.php?/$1 [QSA,L]
        </IfModule>
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/campaignhq_error.log
    CustomLog ${APACHE_LOG_DIR}/campaignhq_access.log combined
</VirtualHost>
```

Enable site and required modules:
```bash
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod ssl
sudo a2ensite campaignhq.conf
sudo systemctl reload apache2
```

#### Nginx Configuration

Create `/etc/nginx/sites-available/campaignhq`:

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    root /var/www/html/campaignhq/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    error_log /var/log/nginx/campaignhq_error.log;
    access_log /var/log/nginx/campaignhq_access.log;
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/campaignhq /etc/nginx/sites-enabled/
sudo systemctl reload nginx
```

### Step 7: Enable HTTPS (Let's Encrypt)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-apache python3-certbot-nginx

# For Apache
sudo certbot --apache -d your-domain.com -d www.your-domain.com

# For Nginx
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

Auto-renewal:
```bash
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

## Configuration Guide

### Essential .env Settings

```env
# Application Mode
APP_ENV=production              # production or development
APP_DEBUG=false                # Never true in production

# Database Connection
DB_HOST=localhost              # Database host
DB_USER=campaignhq_user        # Database username
DB_PASS=secure_password        # Database password
DB_NAME=campaign_hq            # Database name
DB_PORT=3306                   # Database port

# SendGrid API
SENDGRID_API_KEY=SG.xxx        # Get from SendGrid dashboard
SENDGRID_SENDER_EMAIL=noreply@domain.com
SENDGRID_SENDER_NAME=CampaignHQ

# Application URLs
BASE_URL=https://domain.com/campaignhq
API_BASE_URL=https://domain.com/campaignhq/api

# Session Security
SESSION_TIMEOUT=3600           # 1 hour in seconds
REMEMBER_ME_DURATION=2592000   # 30 days in seconds
SESSION_SECURE=true            # Only with HTTPS
SESSION_HTTPONLY=true          # Prevent JS access
SESSION_SAMESITE=Lax           # CSRF protection

# Security
PASSWORD_MIN_LENGTH=8
PASSWORD_HASH_COST=12

# Upload Settings
MAX_UPLOAD_SIZE=52428800       # 50MB in bytes
ALLOWED_UPLOAD_TYPES=xlsx,xls,csv

# Pagination
ITEMS_PER_PAGE=25

# Logging
LOG_DIR=logs
LOG_MAX_SIZE=10485760          # 10MB in bytes
```

### Optional Settings

```env
# Email BCC (for auditing)
EMAIL_BCC=audit@domain.com

# Time Zone
TIMEZONE=UTC

# Rate Limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=3600

# Feature Flags
FEATURE_CUSTOM_FIELDS=true
FEATURE_WEBHOOKS=true
```

## Database Setup

### Verify Database Import

```bash
# Check tables were created
mysql -u campaignhq_user -p campaign_hq -e "SHOW TABLES;"

# Expected output should show 28 tables
```

### Create Admin User

Run this PHP script once:

```php
<?php
require 'config/config.php';

// Create admin user
$email = 'admin@yourdomain.com';
$password = 'ChangeMe123!';
$fullname = 'Administrator';

try {
    $db = Database::getInstance();
    
    // Check if user exists
    $db->query('SELECT id FROM users WHERE email = :email');
    $db->bind(':email', $email);
    $db->execute();
    
    if ($db->single()) {
        echo "Admin user already exists!";
        exit;
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    
    // Create user
    $db->query('
        INSERT INTO users (fullname, email, password, role_id, status, created_at)
        VALUES (:fullname, :email, :password, 1, "active", NOW())
    ');
    $db->bind(':fullname', $fullname);
    $db->bind(':email', $email);
    $db->bind(':password', $hashedPassword);
    $db->execute();
    
    echo "Admin user created successfully!";
    echo "\nEmail: " . $email;
    echo "\nPassword: " . $password;
    echo "\nPlease change password after first login.";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
```

Run:
```bash
php create-admin.php
```

## SendGrid Integration

### Step 1: Create SendGrid Account

1. Visit https://sendgrid.com
2. Sign up for free tier (500 emails/day)
3. Verify email address

### Step 2: Create API Key

1. Login to SendGrid dashboard
2. Go to Settings → API Keys
3. Click "Create API Key"
4. Name it "CampaignHQ"
5. Select "Full Access"
6. Copy the key (shown only once!)

### Step 3: Configure in CampaignHQ

Update `.env`:
```env
SENDGRID_API_KEY=SG.your_full_api_key_here
SENDGRID_SENDER_EMAIL=noreply@yourdomain.com
SENDGRID_SENDER_NAME=CampaignHQ
```

### Step 4: Verify Sender Email

In SendGrid:
1. Go to Settings → Sender Authentication
2. Add your sender email
3. Verify email or DNS (recommended for production)

### Step 5: Configure Webhooks (Optional but Recommended)

For email event tracking:

1. In SendGrid dashboard, go to Settings → Webhook
2. Click "Add Endpoint"
3. URL: `https://yourdomain.com/campaignhq/api/webhooks/sendgrid`
4. Select events:
   - Delivered
   - Opened
   - Clicked
   - Bounced
   - Unsubscribed
   - Spam Report
5. Save

## Post-Installation

### Test Installation

```bash
# Test database connection
curl https://yourdomain.com/campaignhq/api/test

# Access application
https://yourdomain.com/campaignhq

# Login with admin credentials
Email: admin@yourdomain.com
Password: (from create-admin.php output)
```

### Initial Configuration

1. Change admin password
2. Configure system settings
3. Set up SendGrid API key
4. Create email templates
5. Test email sending

### Backup Strategy

```bash
# Daily database backup
0 2 * * * mysqldump -u campaignhq_user -pYourPassword campaign_hq > /backups/campaign_hq_$(date +\%Y\%m\%d).sql

# Weekly file backup
0 3 * * 0 tar -czf /backups/campaignhq_$(date +\%Y\%m\%d).tar.gz /var/www/html/campaignhq
```

## Troubleshooting

### 500 Internal Server Error

Check error logs:
```bash
tail -f logs/error.log
tail -f /var/log/apache2/campaignhq_error.log  # Apache
tail -f /var/log/nginx/campaignhq_error.log    # Nginx
```

### Database Connection Failed

```bash
# Test MySQL connection
mysql -u campaignhq_user -p campaign_hq -e "SELECT 1;"

# Verify credentials in .env
grep "^DB_" .env
```

### Permission Denied Errors

```bash
# Fix ownership and permissions
sudo chown -R www-data:www-data /var/www/html/campaignhq
sudo chmod -R 755 /var/www/html/campaignhq
sudo chmod -R 777 logs/ public/uploads/
```

### Blank Page

1. Check `APP_DEBUG=true` in .env
2. Check error logs (see above)
3. Verify database tables exist: `mysql -u campaignhq_user -p campaign_hq -e "SHOW TABLES;"`
4. Verify PHP version: `php -v`

### SendGrid Not Sending

1. Verify API key is correct
2. Verify sender email is verified in SendGrid
3. Check SendGrid activity logs
4. Test with SendGrid API directly

### Slow Performance

1. Enable database query cache
2. Add indexes to frequently searched columns
3. Implement Redis for sessions: `SESSION_HANDLER=redis`
4. Enable gzip compression in web server
5. Optimize images and assets

### Memory Limit Exceeded

Increase PHP memory limit in `.env` or php.ini:
```ini
memory_limit = 256M
```

### Session Issues

Clear old sessions:
```bash
rm -rf /var/lib/php/sessions/*
```

## Getting Help

- Check logs: `logs/error.log`
- Review configuration: `.env`
- Test connectivity: `mysql`, database
- Contact support: support@campaignhq.com

## Next Steps

1. Create first campaign
2. Import leads
3. Set up email templates
4. Configure follow-ups
5. Monitor analytics
6. Set up scheduled backups
